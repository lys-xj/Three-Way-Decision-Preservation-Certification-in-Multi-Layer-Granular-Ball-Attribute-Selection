"""Read-only audit of frozen IE v0.4; all new evidence stays in Step 19.

Brute-force member families do not use the production box/closure formulas.
The tree oracle is the separately written frozen Step 3 generator through its
Step 8 adapter. Finite tests supplement, and do not replace, the written proofs.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, product
from collections import Counter
from time import perf_counter
import ast, hashlib, importlib.util, inspect, json, random, sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
S15 = ROOT / '第15步_粗细两级认证与算法定版'
S18 = ROOT / '第18步_最终算法正式实验'
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8'))
RUN = load('final_proof_freeze', S15/'158_冻结版本运行入口.py')
LOCK = RUN.verify()
M = load('final_proof_selected', S15/'162_主算法接口.py')
D = load('final_proof_driver', S18/'198_统一实验驱动.py')
D.verify_lock()
K, API, E = M.K, M.API, M.KERNEL
ALPHA, BETA = F(7, 10), F(3, 10)
COUNTS = Counter()
DETAILS = {}

def subsets(ids):
    return (tuple(i for i, b in zip(ids, bits) if b)
            for bits in product((False, True), repeat=len(ids)))

def brute_family(points, groups, U):
    cores = [tuple(i for i in g if i not in U) for g in groups]
    if min(map(len, cores)) < 2:
        return None
    families, boxes = [], []
    d = len(next(iter(points.values())))
    for core in cores:
        members = [core + Z for Z in subsets(tuple(sorted(U)))]
        means = [tuple(sum((points[i][j] for i in ids), F(0))/len(ids)
                       for j in range(d)) for ids in members]
        families.append(members)
        boxes.append(tuple((min(p[j] for p in means), max(p[j] for p in means))
                           for j in range(d)))
        COUNTS['enumerated_member_sets'] += len(members)
    bad = []
    for g in (0, 1):
        for i in cores[g]:
            upper = max(sum(((x-y)**2 for x,y in zip(points[i], corner)), F(0))
                        for corner in product(*boxes[g]))
            closest = tuple(min(max(x, a), b) for x,(a,b) in zip(points[i],boxes[1-g]))
            lower = sum(((x-y)**2 for x,y in zip(points[i],closest)), F(0))
            assert E.necessary_distances(points[i], boxes[g], boxes[1-g]) == (upper, lower)
            COUNTS['independent_distance_checks'] += 1
            if upper > lower or (g == 1 and upper == lower):
                bad.append(i)
    return dict(cores=cores, boxes=boxes, bad=tuple(bad), families=families)

def geometry_and_completeness():
    rng = random.Random(2026092901)
    for t in range(28):
        n, d = 4+t%5, 1+t%3
        # Alternate separated and overlapping tables; test the local template
        # on arbitrary fixed partitions, a superset of realizable first splits.
        points = {i: tuple(F(rng.randrange(-4, 5)+(18 if t%2 == 0 and i>=n//2 else 0),
                             1+(i+j+t)%3) for j in range(d)) for i in range(n)}
        groups = [tuple(range(n//2)), tuple(range(n//2,n))]
        records, feasible = {}, []
        for U0 in subsets(tuple(points)):
            U = frozenset(U0)
            oracle = brute_family(points, groups, U)
            state = E.EnvelopeState(points, groups)
            # Reverse growth order tests incremental updates without changing U.
            state.grow(tuple(reversed(U0)))
            result = state.inspect('exact')
            COUNTS['optional_sets'] += 1
            assert result['valid_cores'] == (oracle is not None)
            if oracle is None:
                continue
            COUNTS['valid_optional_sets'] += 1
            assert state.n == list(map(len, oracle['cores']))
            assert state.sums == [[sum((points[i][j] for i in core),F(0))
                                   for j in range(d)] for core in oracle['cores']]
            assert result['boxes'] == oracle['boxes']
            assert result['violations'] == oracle['bad']
            coarse = state.coarse_boxes()
            for g in (0,1):
                for j in range(d):
                    a,b = oracle['boxes'][g][j]; c,e = coarse[g][j]
                    assert c <= a <= b <= e
            records[U] = oracle
            if not oracle['bad']:
                feasible.append(U)
        for U, a in records.items():
            for W, b in records.items():
                if not U <= W:
                    continue
                for g in (0,1):
                    assert {frozenset(x) for x in a['families'][g]} <= {frozenset(x) for x in b['families'][g]}
                    for j in range(d):
                        x,y = a['boxes'][g][j]; v,w = b['boxes'][g][j]
                        assert v <= x <= y <= w
                COUNTS['nested_family_pairs'] += 1
        actual = E.least_envelope(points, groups, 'exact')
        U = frozenset()
        trace = []
        while U in records:
            b = records[U]
            trace.append((tuple(sorted(U)), b['bad']))
            if not b['bad']:
                break
            U = U | frozenset(b['bad'])
        assert [(s['optional'],s['violations']) for s in actual['steps']] == trace
        assert actual['final']['optional'] == tuple(sorted(U))
        if feasible:
            assert actual['status'] == 'least_envelope_found' and U in feasible
            assert all(U <= W for W in feasible)
            COUNTS['least_envelopes_found'] += 1
        else:
            assert actual['status'] == 'no_envelope_with_two_core_members'
            COUNTS['no_feasible_envelope'] += 1
        # New proof obligation: least-envelope decision completeness WITHIN the
        # specified template. Enumerate actual proportions, not formula copies.
        labels_list = [dict.fromkeys(points, 0), dict.fromkeys(points, 1),
                       {i:i%2 for i in points}, {i:rng.randrange(2) for i in points}]
        for labels in labels_list:
            all_bounds = {}
            for W in feasible:
                bounds = []
                for g in (0,1):
                    values = [F(sum(labels[i] for i in ids),len(ids)) for ids in records[W]['families'][g]]
                    bound = (min(values),max(values))
                    assert bound == K.ratio_interval([labels[i] for i in records[W]['cores'][g]],
                                                     [labels[i] for i in W])
                    bounds.append(bound)
                all_bounds[W] = bounds
            for alpha,beta in [(ALPHA,BETA),(F(2,3),F(1,3)),(F(4,5),F(1,5))]:
                for q in ('A','D','R'):
                    def cert(W):
                        return all(K.interval_decision(*b,alpha,beta) == q for b in all_bounds[W])
                    any_exists = any(cert(W) for W in feasible)
                    least_pass = bool(feasible) and cert(U)
                    assert any_exists == least_pass
                    COUNTS['template_completeness_queries'] += 1
                    COUNTS['template_certificate_exists'] += int(any_exists)
        COUNTS['geometry_tables'] += 1
    assert COUNTS['least_envelopes_found'] and COUNTS['no_feasible_envelope']

def threshold_and_input_contract():
    cases = [(ALPHA,ALPHA,'A'),(BETA,BETA,'R'),(BETA,ALPHA,None),
             (F(1,2),F(1,2),'D'),(BETA,F(1,2),None),(F(1,2),ALPHA,None),
             (F(0),BETA,'R'),(ALPHA,F(1),'A')]
    for lo,hi,q in cases:
        assert K.interval_decision(lo,hi,ALPHA,BETA) == q
    tied = E.EnvelopeState({i:(F(0),) for i in range(4)},[(0,1),(2,3)]).inspect('exact')
    assert tied['violations'] == (2,3)
    data = {0:(F(0),0),1:(F(1),1)}
    exact = M.FinalEvaluator(data,('a',),(1,2),ALPHA,BETA)
    binary = M.FinalEvaluator(data,('a',),(1,2),0.7,0.3)
    assert exact.decision(F(3,10)) == 'R' and binary.decision(F(3,10)) == 'D'
    rejected = []
    for alpha,beta in [(F(1),BETA),(ALPHA,F(0)),(BETA,BETA)]:
        try:
            M.FinalEvaluator(data,('a',),(1,2),alpha,beta)
        except ValueError:
            rejected.append((alpha,beta))
        else:
            raise AssertionError('Strict threshold-domain contract changed')
    assert exact.T == 20 and exact.minimum_child == 2 and exact.policy == 'exact'
    DETAILS['input_contract'] = dict(endpoint_parameter_sets_rejected=rejected,
        exact_beta=str(exact.beta),float_beta_exact_rational=str(binary.beta),
        decision_at_three_tenths_exact=exact.decision(F(3,10)),
        decision_at_three_tenths_binary_float=binary.decision(F(3,10)),
        formal_experiment_thresholds_are_exact=all(isinstance(x,F) for v in D.SETTINGS.values() for x in v[1:]),
        production_iteration_cap=exact.T,policy=exact.policy)
    COUNTS['threshold_interval_cases'] = len(cases)
    for n in range(2,7):
        for a in range(n+1):
            for u in range(4):
                for v in range(4):
                    ps = [F(a+i,n+i+j) for i in range(u+1) for j in range(v+1)]
                    assert K.ratio_interval([1]*a+[0]*(n-a),[1]*u+[0]*v) == (min(ps),max(ps))
                    COUNTS['ratio_extrema_cases'] += 1

def path(records):
    return [(tuple(r['current']),r['delete'],r['accepted'],r['changed_count']) for r in records]

def independent_search(ref, attrs, order):
    baseline = ref.decisions(ref.generate(attrs))
    A, records = tuple(attrs), []
    while len(A) > 1:
        accepted = False
        for a in order:
            if a not in A: continue
            B = tuple(x for x in A if x != a)
            ds = ref.decisions(ref.generate(B))
            changes = sum(ds[h][i] != baseline[h][i] for h in baseline for i in baseline[h])
            records.append(dict(current=A,delete=a,accepted=changes==0,changed_count=changes))
            if changes == 0:
                A, accepted = B, True
                break
        if not accepted: break
    if len(A) > 1:
        for a in A:
            assert ref.decisions(ref.generate(tuple(x for x in A if x != a))) != baseline
            COUNTS['final_single_deletion_checks'] += 1
    return A, records, baseline

class AuditedEvaluator(M.FinalEvaluator):
    def project_certificate(self,node,*args,**kwargs):
        assert not node.get('abstract'), 'An abstract node entered the exact cache'
        COUNTS['exact_cache_inputs_checked'] += 1
        return super().project_certificate(node,*args,**kwargs)

    def partial_construct(self,attrs,baseline,reference=None,materialize=False):
        old_hash = API.digest(reference) if reference is not None else None
        baseline_hash = API.digest(baseline)
        out = super().partial_construct(attrs,baseline,reference,materialize)
        assert API.digest(baseline) == baseline_hash
        assert reference is None or API.digest(reference) == old_hash
        truth = self.oracle.generate(attrs)
        assert out['decisions'] == self.oracle.decisions(truth)
        COUNTS['candidate_or_materialization_checks'] += 1
        real_nodes = {(x['depth'],tuple(x['ids'])):x for x in truth['nodes']}
        for n in out['nodes']:
            real = real_nodes[n['depth'],tuple(n['ids'])]
            if not n.get('abstract'):
                # Full trace equality includes UNKNOWN fallback and cap branches.
                assert API.signature({'nodes':[n]},True) == API.signature({'nodes':[real]},True)
                COUNTS['exact_node_trace_checks'] += 1
                continue
            proof=n['certificate']; groups=proof['first_groups']
            assert n['depth'] == self.H-1 and 'children' in real
            assert [set(g) for g in groups] == [set(g) for g in real['iterations'][0]['groups']]
            ever=set()
            for rec in real['iterations'][1:]:
                ever.update(set(groups[0]) ^ set(rec['groups'][0]))
            assert ever <= set(proof['uncertain'])
            for g in (0,1):
                assert set(proof['forced'][g]) <= set(real['children'][g])
            assert all(self.oracle.decisions(truth)[self.H][i] == proof['decision'] for i in n['ids'])
            COUNTS['abstract_certificates_replayed'] += 1
            COUNTS['certificates_with_actual_later_movers'] += bool(ever)
        return out

def end_to_end():
    rng=random.Random(2026092902)
    snapshot=K.SNAP
    raw=read(snapshot/'第5步_完整属性约简算法/23_合成输入与固定参数.json')['inputs']
    selected=[x for x in raw if x['name'] in ('既有合成表-12','既有合成表-15') or x['name'].startswith('边界回归-')]
    cases=[(x['name'],{int(i):tuple(F(z) for z in row[:-1])+(row[-1],) for i,row in x['data'].items()},
            tuple(x['attributes']),tuple(x['levels'])) for x in selected]
    cases += [('small',*K.small_case()),('moving_D',*K.chain_case(False)),('unsafe',*K.chain_case(True)),
              ('two_samples',{0:(F(0),F(0),0),1:(F(1),F(0),1)},('a','b'),(1,3)),
              ('coincident',{i:(F(0),F(0),i%2) for i in range(6)},('a','b'),(2,4)),
              ('singleton_attribute',{i:(F(i),i%2) for i in range(5)},('a',),(1,2))]
    for t in range(20):
        C=tuple('abc'[:2+t%2]);n=6+t%5
        data={i:tuple(F(rng.randrange(-5,12),1+(i+t)%3) for _ in C)+(rng.randrange(2),) for i in range(n)}
        data[0]=data[0][:-1]+(0,);data[1]=data[1][:-1]+(1,)
        levels=[(1,2),(1,3),(2,4),(1,2,3)][t%4]
        cases.append(('new_random_%02d'%t,data,C,levels))
    results=[]
    for name,data,C,levels in cases:
        ref=K.AUDIT.Reference(data,C,levels,ALPHA,BETA)
        baseline=ref.decisions(ref.generate(C))
        if name.startswith('new_random'):
            engine=AuditedEvaluator(data,C,levels,ALPHA,BETA);engine.oracle=ref
            for size in range(1,len(C)+1):
                for B in combinations(C,size):
                    engine.partial_construct(B,baseline)
                    COUNTS['all_subset_candidates'] += 1
        for order in dict.fromkeys((C,tuple(reversed(C)))):
            A,records,base=independent_search(ref,C,order)
            engine=AuditedEvaluator(data,C,levels,ALPHA,BETA);engine.oracle=ref
            result=engine.solve_certified(order=order,materialize_final=True)
            assert result['final_attributes'] == A and path(result['attempts']) == path(records)
            assert result['final_decisions'] == base
            truth=ref.generate(A)
            assert API.signature(result['state'],True) == API.signature(truth,True)
            assert engine.final_geometry(result['state']) == ref.geometry(truth)
            assert len(result['attempts']) <= len(C)*(len(C)+1)//2-1
            COUNTS['end_to_end_searches'] += 1
            if order==C and name in ('既有合成表-12','既有合成表-15'):
                DETAILS[name]=dict(final_attributes=A,path=path(records))
            if order==C and name in ('small','moving_D','unsafe','singleton_attribute'):
                setting='deep' if levels==(1,2,3) else 'main'
                assert D.SETTINGS[setting][0]==levels
                exp=D.execute('TC',data,C,setting=setting,audit=True)
                assert exp['final_attributes'] == result['final_attributes']
                assert path(exp['attempts']) == path(result['attempts']), name
                COUNTS['formal_driver_cross_checks'] += 1
                results.append(dict(name=name,attempts=len(records),
                    abstracts_excluded=engine.metrics['abstract_nodes_excluded_from_reuse'],
                    certificate_passes=engine.metrics['certificate_passes'],
                    final_attributes=A,independent_driver_checks=exp['independent_checks']))
    # Check precise existing counterexamples under the final selected version.
    assert [(r[1],r[2]) for r in DETAILS['既有合成表-12']['path']] == [('a',False),('b',True),('a',True)]
    case=next(x for x in cases if x[0]=='既有合成表-15')
    _,data,C,levels=case;ref=K.AUDIT.Reference(data,C,levels,ALPHA,BETA)
    baseline=ref.decisions(ref.generate(C))
    feasible=[B for n in range(1,len(C)+1) for B in combinations(C,n) if ref.decisions(ref.generate(B))==baseline]
    assert feasible == [('a',),('a','b','c')]
    assert DETAILS['既有合成表-15']['final_attributes']==('a','b','c')
    DETAILS['not_inclusion_minimal_witness']=dict(feasible_subsets=feasible,output=C)
    DETAILS['search_examples']=results
    COUNTS['end_to_end_tables']=len(cases)
    # Test-only smaller caps exercise termination BEFORE convergence. This does
    # not assert the data reach the production 20-round cap. Restore immediately.
    data,C,levels=K.chain_case(False)
    for cap in (1,2):
        previous=K.AUDIT.REF.MAX_ITER
        try:
            K.AUDIT.REF.MAX_ITER=cap
            ref=K.AUDIT.Reference(data,C,levels,ALPHA,BETA)
            engine=AuditedEvaluator(data,C,levels,ALPHA,BETA);engine.T=cap;engine.oracle=ref
            result=engine.solve_certified(materialize_final=True)
            truth=ref.generate(result['final_attributes'])
            assert any(n.get('iteration_cap_reached') for n in truth['nodes'])
            assert API.signature(result['state'],True)==API.signature(truth,True)
            COUNTS['test_only_finite_cap_cases'] += 1
        finally:
            K.AUDIT.REF.MAX_ITER=previous
    assert K.AUDIT.REF.MAX_ITER==20

def source_map(before):
    files={}
    sources=[p for p in before if p.suffix=='.py']
    for p in sources:
        tree=ast.parse(p.read_text(encoding='utf-8'))
        functions={}
        def visit(node,prefix=''):
            for child in ast.iter_child_nodes(node):
                if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
                    name=prefix+child.name
                    functions[name]=dict(start=child.lineno,end=child.end_lineno)
                    visit(child,name+'.')
                else: visit(child,prefix)
        visit(tree)
        files[str(p.relative_to(ROOT))]=dict(sha256=sha(p),functions=functions)
    resolution={}
    for name in ('certificate','solve_certified','partial_construct','split_traced','project_certificate','decision'):
        func=getattr(M.FinalEvaluator,name)
        resolution[name]=dict(file=str(Path(inspect.getsourcefile(func)).relative_to(ROOT)),
                              line=inspect.getsourcelines(func)[1],qualname=func.__qualname__)
    return dict(version=M.VERSION,policy=M.FinalEvaluator.policy,files=files,method_resolution=resolution)

def main():
    start=perf_counter()
    paths={ROOT/name for name in LOCK['files']}
    paths |= {S18/name for name in read(S18/'202_正式实验冻结清单.json')['files']}
    paths |= {S15/'159_冻结版本清单.json',S18/'202_正式实验冻结清单.json',
              S18/'209_正式实验汇总.json',S18/'228_事后独立回放账本.json'}
    # Ledger naming is discovered by its unique numeric prefix, not assumed.
    paths={p for p in paths if p.exists()}
    paths |= set(S18.glob('228_*.json'))
    before={p:sha(p) for p in paths}
    threshold_and_input_contract()
    print('Input and threshold boundaries passed.',flush=True)
    geometry_and_completeness()
    print('Exhaustive families, least closure and template completeness passed.',flush=True)
    end_to_end()
    print('Search, fallback, cache, materialization and driver checks passed.',flush=True)
    RUN.verify();D.verify_lock()
    assert all(sha(p)==value for p,value in before.items())
    locations=source_map(before)
    (OUT/'236_源码定位与版本校验.json').write_text(json.dumps(locations,ensure_ascii=False,indent=2),encoding='utf-8')
    result=dict(status='passed',version=M.VERSION,policy=M.FinalEvaluator.policy,
        counts=dict(COUNTS),details=DETAILS,algorithm_lock_files=len(LOCK['files']),
        experiment_lock_files=len(read(S18/'202_正式实验冻结清单.json')['files']),
        unchanged_files_checked=len(before),unchanged_sha256={str(p.relative_to(ROOT)):v for p,v in before.items()},
        elapsed_seconds=perf_counter()-start,test_sha256=sha(__file__),
        qualifications=['Finite checks supplement manual mathematical proofs; no proof assistant was used.',
          'Iteration caps 1 and 2 were test-only controls; the frozen production cap remains 20.',
          'No performance claim or unseen-sample generalization is established.',
          'Exact rational thresholds are required by the audited input contract; bare float thresholds are not rejected by the old constructor.'])
    (OUT/'235_证明边界核验结果.json').write_text(json.dumps(API.encode(result),ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','counts','unchanged_files_checked','elapsed_seconds')},ensure_ascii=False),flush=True)

if __name__=='__main__':
    main()
