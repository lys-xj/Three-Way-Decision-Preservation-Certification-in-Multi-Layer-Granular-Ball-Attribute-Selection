"""Parameter-free least optional-member closure within the same box template.

No completeness claim beyond cores contained in first-round groups, >=2 members,
the SAME independent center boxes/distance tests, and uniform reference decisions.
"""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;S12=OUT.parent/'第12步_成员变化下的决定认证'
s=importlib.util.spec_from_file_location('unchanged_partial',S12/'112_局部复用结合决定认证.py');P=importlib.util.module_from_spec(s);s.loader.exec_module(P)
K=P.K;API=P.API;VERSION='TailCert-L-closure-v0.3-exploratory'

def inspect_envelope(points,first_groups,optional):
 optional=set(optional);cores=[tuple(i for i in g if i not in optional) for g in first_groups]
 if any(len(c)<2 for c in cores):return dict(valid_cores=False,cores=cores,optional=tuple(sorted(optional)))
 U=tuple(sorted(optional));d=len(next(iter(points.values())))
 boxes=[tuple(K.mean_interval([points[i][j] for i in cores[g]],[points[i][j] for i in U]) for j in range(d)) for g in (0,1)]
 violations=[];checks=[]
 for g in (0,1):
  for i in cores[g]:
   own=K.box_distance(points[i],boxes[g])[1];other=K.box_distance(points[i],boxes[1-g])[0]
   checks.append(dict(id=i,group=g,own_upper=own,other_lower=other))
   if not (own<=other if g==0 else own<other):violations.append(i)
 return dict(valid_cores=True,cores=cores,optional=U,boxes=boxes,violations=tuple(violations),checks=checks)

def least_envelope(points,first_groups):
 U=set();steps=[];cost=dict(box_distance_calls=0,box_coordinate_terms=0,mean_box_coordinates=0,mean_box_optional_values_sorted=0);d=len(next(iter(points.values())))
 while True:
  e=inspect_envelope(points,first_groups,U)
  if not e['valid_cores']:return dict(status='no_envelope_with_two_core_members',steps=steps,final=e,cost=cost)
  cost['mean_box_coordinates']+=2*d;cost['mean_box_optional_values_sorted']+=2*d*len(U)
  checks=sum(map(len,e['cores']));cost['box_distance_calls']+=2*checks;cost['box_coordinate_terms']+=2*d*checks
  steps.append(dict(optional=tuple(sorted(U)),violations=e['violations'],core_sizes=list(map(len,e['cores']))))
  if not e['violations']:return dict(status='least_envelope_found',steps=steps,final=e,cost=cost)
  previous=len(U);U.update(e['violations']);assert len(U)>previous

class ClosureEvaluator(P.PartialEvaluator):
 def reset_metrics(self):
  super().reset_metrics();self.metrics.update(closure_passes=0,closure_failed_geometry=0,closure_failed_ratio=0,closure_failed_reference=0,closure_rounds=0)
 def certificate(self,ids,attrs,groups,first_distances,baseline):
  self.metrics['certificate_attempts']+=1;target={baseline[self.H][i] for i in ids}
  if len(target)!=1:
   self.metrics['closure_failed_reference']+=1;self.last_diagnostic=dict(reason='reference_decisions_not_uniform');return None
  target=next(iter(target));points={i:self.point(i,attrs) for i in ids};r=least_envelope(points,groups)
  self.metrics['closure_rounds']+=len(r['steps'])
  for k,v in r['cost'].items():self.metrics[k]+=v
  if r['status']!='least_envelope_found':
   self.metrics['closure_failed_geometry']+=1;self.last_diagnostic=dict(reason=r['status'],closure_rounds=len(r['steps']),steps=r['steps']);return None
  e=r['final'];bounds=[K.ratio_interval([self.data[i][-1] for i in e['cores'][g]],[self.data[i][-1] for i in e['optional']]) for g in (0,1)]
  if any(K.interval_decision(*b,self.alpha,self.beta)!=target for b in bounds):
   self.metrics['closure_failed_ratio']+=1;self.last_diagnostic=dict(reason='least_envelope_ratio_crosses_threshold',bounds=bounds,target=target,optional_count=len(e['optional']),closure_rounds=len(r['steps']));return None
  self.metrics['certificate_passes']+=1;self.metrics['closure_passes']+=1;self.metrics['certified_samples_at_H']+=len(ids)
  self.last_diagnostic=dict(reason='PASS',optional_count=len(e['optional']),closure_rounds=len(r['steps']),bounds=bounds,target=target)
  return dict(kind='least-member-envelope',members=tuple(ids),depth=self.H-1,attrs=attrs,first_groups=groups,forced=e['cores'],uncertain=e['optional'],center_boxes=e['boxes'],core_distance_checks=e['checks'],proportion_bounds=bounds,decision=target,actual_final_children_known=False,closure_steps=r['steps'])
