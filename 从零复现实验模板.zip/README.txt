Start with the file 215 in the Step 18 folder. Run Python without -O. No current-run result ledger is included. Preserve directory layout. All datasets are attributed in file 214.
