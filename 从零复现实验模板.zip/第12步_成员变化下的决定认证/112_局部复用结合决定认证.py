"""TailCert-L-v0.2: truthful exact nodes plus explicitly abstract terminal regions.

The primary output is an attribute subset with certified observed decisions.
Materializing the final exact tree is OPTIONAL and separately charged.
"""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
import importlib.util,sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('tail_kernel',OUT/'102_精确判据原型.py');K=importlib.util.module_from_spec(s);s.loader.exec_module(K)
API=K.API
VERSION='TailCert-L-v0.2'

class PartialEvaluator(K.DecisionEvaluator):
 def reset_metrics(self):
  super().reset_metrics();self.metrics.update(exact_nodes_reused=0,projection_seed_checks=0,projection_assignment_checks=0,abstract_nodes_excluded_from_reuse=0)

 def split_traced(self,ids,attrs,baseline,allow_certificate):
  points={i:self.point(i,attrs) for i in ids};s0=min(ids);q={i:self.distance(points[i],points[s0]) for i in ids};s1=min(ids,key=lambda i:(-q[i],i))
  node=dict(seeds=[s0,s1],seed_distances=q)
  if q[s1]==0:node['stop']='保留坐标全部重合，不能分开';return node
  centers=[points[s0],points[s1]];previous=None;node['iterations']=[]
  for t in range(1,self.T+1):
   groups=[[],[]];rows=[];distances={};self.metrics['lloyd_rounds']+=1
   for i in ids:
    d0=self.distance(points[i],centers[0]);d1=self.distance(points[i],centers[1]);g=0 if d0<=d1 else 1
    groups[g].append(i);rows.append(dict(id=i,d0=d0,d1=d1,group=g));distances[i]=(d0,d1)
   rec=dict(iteration=t,centers=centers,distances=rows,groups=groups);node['iterations'].append(rec)
   if not groups[0] or not groups[1]:node['stop']='出现空子组，取消本节点分裂';return node
   updated=[self.mean(g,attrs) for g in groups];rec['updated_centers']=updated
   if t==1 and allow_certificate:
    certificate=self.certificate(ids,attrs,groups,distances,baseline)
    if certificate is not None:
     # Do not expose a partial trace as a reusable exact node.
     return dict(abstract=True,certificate=certificate)
   if groups==previous:rec['converged']=True;break
   previous=groups;centers=updated
  else:node['iteration_cap_reached']=True
  if any(len(g)<self.minimum_child for g in groups):node['stop']='收敛或达上限后的子组人数小于2，取消分裂'
  else:node['children']=groups
  return node

 def partial_construct(self,attrs,baseline,reference=None,materialize=False):
  attrs=self.ordered(attrs);old={};nodes=[];decisions={h:{} for h in self.levels}
  if reference is not None:
   assert reference['config']==self.config and set(attrs)<=set(reference['attrs'])
   for n in reference['nodes']:
    if n.get('abstract'):
     self.metrics['abstract_nodes_excluded_from_reuse']+=1
    else:old[(n['depth'],tuple(n['ids']))]=n
  def visit(ids,depth,path):
   p=F(sum(self.data[i][-1] for i in ids),len(ids));node=dict(ids=list(ids),depth=depth,path=path,p=p);nodes.append(node)
   if depth in decisions:decisions[depth].update({i:self.decision(p) for i in ids})
   stop=self.basic_stop(ids,depth)
   if stop:node['stop']=stop
   else:
    cached=old.get((depth,tuple(ids)));projected=None
    if cached is not None:
     if attrs==tuple(reference['attrs']):
      projected={k:deepcopy(v) for k,v in cached.items() if k not in ('ids','depth','path','p')}
     else:
      projected,proof=self.project_certificate(cached,reference['attrs'],attrs)
      self.metrics['projection_seed_checks']+=proof['seed_checks'];self.metrics['projection_assignment_checks']+=proof['assignment_checks']
    if projected is not None:self.metrics['exact_nodes_reused']+=1;node.update(projected)
    else:node.update(self.split_traced(ids,attrs,baseline,not materialize and depth==self.H-1))
   if node.get('abstract'):
    decisions[self.H].update({i:node['certificate']['decision'] for i in ids});return
   if 'children' in node:
    for side,group in enumerate(node['children']):visit(tuple(group),depth+1,path+('L' if side==0 else 'R'))
   else:
    for h in self.levels:
     if h>=depth:decisions[h].update({i:self.decision(p) for i in ids})
  visit(self.ids,0,'U')
  assert all(set(d)==set(self.ids) for d in decisions.values())
  has_abstract=any(n.get('abstract') for n in nodes)
  return dict(attrs=attrs,config=self.config,nodes=nodes,decisions=decisions,has_abstract_regions=has_abstract,full_tree_available=not has_abstract)

 def solve_certified(self,order=None,materialize_final=False):
  order=tuple(self.C if order is None else order);assert len(order)==len(self.C) and set(order)==set(self.C)
  self.reset_metrics();state,stats=self.construct(self.C,'F1');self.metrics['lloyd_rounds']+=stats['recomputed_iterations'];baseline=self.decisions(state)
  state.update(decisions=baseline,has_abstract_regions=False,full_tree_available=True);A=self.C;attempts=[]
  while len(A)>1:
   accepted=False
   for a in order:
    if a not in A:continue
    B=tuple(b for b in A if b!=a);candidate=self.partial_construct(B,baseline,state)
    delta=sum(candidate['decisions'][h][i]!=baseline[h][i] for h in self.levels for i in self.ids)
    attempts.append(dict(current=A,delete=a,candidate=B,accepted=delta==0,changed_count=delta,certified_regions=sum(n.get('abstract',False) for n in candidate['nodes'])))
    if delta==0:A=B;state=candidate;accepted=True;break
   if not accepted:break
  before=dict(self.metrics);extra_rounds=0
  if materialize_final and state['has_abstract_regions']:
   state=self.partial_construct(A,baseline,state,materialize=True);extra_rounds=self.metrics['lloyd_rounds']-before['lloyd_rounds']
  assert state['decisions']==baseline
  geom=self.final_geometry(state) if materialize_final else None
  return dict(version=VERSION,final_attributes=A,attempts=attempts,baseline=baseline,final_decisions=state['decisions'],metrics=dict(self.metrics),metrics_before_materialization=before,final_materialization_requested=materialize_final,final_materialization_rounds=extra_rounds,full_tree_available=state['full_tree_available'],final_structure_hash=API.digest(API.signature(state)) if state['full_tree_available'] else None,final_geometry_hash=API.digest(geom) if geom is not None else None,state=state)
