"""TailCert-v0.1: decision certificates for the LAST binary split only.

This is a new research prototype. It never edits Paper-L-v1.0-exact, never
labels an abstract region as a real membership tree, and uses no candidate oracle.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util, sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
FREEZE=OUT.parent/'第9步_论文算法定版与关键证明'
FR=load('tail_freeze',FREEZE/'78_运行冻结版本.py')
LOCK,SNAP=FR.verify_snapshot()
API=load('tail_baseline',SNAP/'第7步_对照实现与真实数据试运行'/'36_统一求值与约简.py')
AUDIT=load('tail_oracle',SNAP/'第8步_核验改进与声呐续跑'/'55_流式独立核验.py')
VERSION='TailCert-v0.1'

def mean_interval(forced,optional):
 """Exact coordinate extrema over F union Z, for arbitrary Z subset optional."""
 assert forced
 values=sorted(optional);s=sum(forced,F(0));n=len(forced)
 lows=[s/n];highs=[s/n];a=b=F(0)
 for k in range(1,len(values)+1):
  a+=values[k-1];b+=values[-k];lows.append((s+a)/(n+k));highs.append((s+b)/(n+k))
 return min(lows),max(highs)

def box_distance(point,box):
 """Exact min/max squared distances over an axis-aligned closed box."""
 lower=upper=F(0)
 for x,(a,b) in zip(point,box):
  near=a-x if x<a else x-b if x>b else F(0)
  lower+=near*near;upper+=max((x-a)**2,(x-b)**2)
 return lower,upper

def ratio_interval(forced_labels,optional_labels):
 a=sum(forced_labels);n=len(forced_labels);u=sum(optional_labels);v=len(optional_labels)-u
 assert n>0
 return F(a,n+v),F(a+u,n+u)

def interval_decision(lower,upper,alpha,beta):
 assert 0<=lower<=upper<=1
 if lower>=alpha:return 'A'
 if upper<=beta:return 'R'
 if lower>beta and upper<alpha:return 'D'
 return None

class DecisionEvaluator(API.Evaluator):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.reset_metrics()
 def reset_metrics(self):
  self.metrics=dict(point_distance_calls=0,point_distance_coordinate_terms=0,mean_coordinate_inputs=0,lloyd_rounds=0,box_distance_calls=0,box_coordinate_terms=0,mean_box_coordinates=0,mean_box_optional_values_sorted=0,certificate_attempts=0,certificate_passes=0,certified_samples_at_H=0)
 def distance(self,v,w):
  self.metrics['point_distance_calls']+=1;self.metrics['point_distance_coordinate_terms']+=len(v)
  return API.CORE.Reducer.distance(v,w)
 def mean(self,ids,attrs):
  self.metrics['mean_coordinate_inputs']+=len(ids)*len(attrs)
  return super().mean(ids,attrs)
 def certificate(self,ids,attrs,groups,first_distances,baseline):
  self.metrics['certificate_attempts']+=1
  target={baseline[self.H][i] for i in ids}
  if len(target)!=1 or any(len(g)<2 for g in groups):return None
  target=next(iter(target));cores=[set(g) for g in groups];uncertain=[]
  # One fixed, label-blind construction rule, not tuned on the examples/results.
  budget=min((len(ids)+4)//5,len(ids)-4)
  owner={i:g for g in (0,1) for i in groups[g]}
  for i in sorted(ids,key=lambda i:(abs(first_distances[i][1]-first_distances[i][0]),i)):
   if len(uncertain)>=budget:break
   g=owner[i]
   if len(cores[g])>2:cores[g].remove(i);uncertain.append(i)
  if not uncertain:return None
  cores=[tuple(sorted(c)) for c in cores];uncertain=tuple(sorted(uncertain))
  points={i:self.point(i,attrs) for i in ids};boxes=[]
  for g in (0,1):
   box=[]
   for j in range(len(attrs)):
    box.append(mean_interval([points[i][j] for i in cores[g]],[points[i][j] for i in uncertain]))
    self.metrics['mean_box_coordinates']+=1;self.metrics['mean_box_optional_values_sorted']+=len(uncertain)
   boxes.append(tuple(box))
  # This geometric invariant is essential: the first assignment alone is NOT a certificate.
  checks=[]
  for g in (0,1):
   for i in cores[g]:
    own=box_distance(points[i],boxes[g])[1];other=box_distance(points[i],boxes[1-g])[0]
    self.metrics['box_distance_calls']+=2;self.metrics['box_coordinate_terms']+=2*len(attrs)
    if not (own<=other if g==0 else own<other):return None
    checks.append(dict(id=i,group=g,own_upper=own,other_lower=other))
  label_bounds=[]
  for g in (0,1):
   bounds=ratio_interval([self.data[i][-1] for i in cores[g]],[self.data[i][-1] for i in uncertain])
   if interval_decision(*bounds,self.alpha,self.beta)!=target:return None
   label_bounds.append(bounds)
  self.metrics['certificate_passes']+=1;self.metrics['certified_samples_at_H']+=len(ids)
  return dict(kind='last-split-decision-certificate',members=tuple(ids),depth=self.H-1,attrs=attrs,first_groups=groups,forced=cores,uncertain=uncertain,center_boxes=boxes,core_distance_checks=checks,proportion_bounds=label_bounds,decision=target,actual_final_children_known=False)

 def split_with_optional_certificate(self,ids,attrs,baseline,enable):
  points={i:self.point(i,attrs) for i in ids};s0=min(ids)
  q={i:self.distance(points[i],points[s0]) for i in ids};s1=min(ids,key=lambda i:(-q[i],i))
  if q[s1]==0:return None,None,'coincident',0
  centers=[points[s0],points[s1]];previous=None
  for t in range(1,self.T+1):
   groups=[[],[]];distances={};self.metrics['lloyd_rounds']+=1
   for i in ids:
    d0=self.distance(points[i],centers[0]);d1=self.distance(points[i],centers[1])
    groups[0 if d0<=d1 else 1].append(i)
    if t==1:distances[i]=(d0,d1)
   if not groups[0] or not groups[1]:return None,None,'empty',t
   updated=[self.mean(g,attrs) for g in groups]
   if t==1 and enable:
    proof=self.certificate(ids,attrs,groups,distances,baseline)
    if proof is not None:return None,proof,'certified_without_final_children',t
   if groups==previous:break
   previous=groups;centers=updated
  if any(len(g)<self.minimum_child for g in groups):return None,None,'undersized',t
  return groups,None,'split',t

 def evaluate(self,attrs,baseline,use_certificate=True):
  attrs=self.ordered(attrs);decisions={h:{} for h in self.levels};proofs=[];actual_nodes=[]
  def visit(ids,depth,path):
   p=F(sum(self.data[i][-1] for i in ids),len(ids));q=self.decision(p)
   node=dict(ids=tuple(ids),depth=depth,path=path,p=p);actual_nodes.append(node)
   if depth in decisions:decisions[depth].update({i:q for i in ids})
   stop=self.basic_stop(ids,depth)
   if stop:groups=proof=None;kind='basic_stop';rounds=0
   else:groups,proof,kind,rounds=self.split_with_optional_certificate(ids,attrs,baseline,use_certificate and depth==self.H-1)
   node.update(result_kind=kind,executed_rounds=rounds)
   if proof is not None:
    proofs.append(proof);decisions[self.H].update({i:proof['decision'] for i in ids});return
   if groups is None:
    for h in self.levels:
     if h>=depth:decisions[h].update({i:q for i in ids})
   else:
    node['children']=[tuple(g) for g in groups]
    for side,g in enumerate(groups):visit(tuple(g),depth+1,path+('L' if side==0 else 'R'))
  visit(self.ids,0,'U')
  assert all(set(d)==set(self.ids) for d in decisions.values())
  return dict(decisions=decisions,certificates=proofs,actual_prefix_nodes=actual_nodes,has_abstract_regions=bool(proofs),full_tree_available=False)

 def solve_decisions(self,order=None,materialize_final=True):
  order=tuple(self.C if order is None else order)
  assert len(order)==len(self.C) and set(order)==set(self.C)
  self.reset_metrics();initial,initial_stats=self.construct(self.C,'F0');baseline=self.decisions(initial)
  # Frozen construction does its own round counting; add it explicitly.
  self.metrics['lloyd_rounds']+=initial_stats['recomputed_iterations']
  A=self.C;attempts=[]
  while len(A)>1:
   accepted=False
   for a in order:
    if a not in A:continue
    B=tuple(x for x in A if x!=a);result=self.evaluate(B,baseline)
    changed=sum(result['decisions'][h][i]!=baseline[h][i] for h in self.levels for i in self.ids)
    safe=changed==0
    attempts.append(dict(current=A,delete=a,candidate=B,accepted=safe,changed_count=changed,certified_regions=len(result['certificates'])))
    if safe:A=B;accepted=True;break
   if not accepted:break
  before_materialization=dict(self.metrics);final_cache=None;geometry=None;final_stats=None
  if materialize_final:
   if A==self.C:final_cache=initial
   else:
    final_cache,final_stats=self.construct(A,'F0');self.metrics['lloyd_rounds']+=final_stats['recomputed_iterations']
   assert self.decisions(final_cache)==baseline
   geometry=self.final_geometry(final_cache)
  return dict(version=VERSION,final_attributes=A,attempts=attempts,baseline=baseline,metrics=dict(self.metrics),metrics_before_final_materialization=before_materialization,final_materialization_included=materialize_final,final_structure_hash=API.digest(API.signature(final_cache)) if final_cache else None,final_geometry_hash=API.digest(geometry) if geometry else None,final_decisions=baseline,cache_state='only attributes and fixed baseline carried between candidates; no abstract region passed as a real cache')

def small_case():
 rows=[(0,0,0),(0,0,1),(4,10,1),(6,0,0),(10,10,0),(10,10,1),(100,0,1),(101,0,1),(1000,0,0),(1001,0,0)]
 return {i+1:tuple(F(x) for x in r[:-1])+(r[-1],) for i,r in enumerate(rows)},('a','b'),(1,2,3)

def chain_case(negative=False):
 rows=[]
 for j in range(20):rows.append((F(0),F(0),int(j<(16 if negative else 10))))
 for j in range(60):rows.append((F(10),F(100),int(j<30)))
 xs=[F(49,10)]*7+[F(j,10) for j in range(51,64)]
 for j,x in enumerate(xs):rows.append((x,F(0 if negative and j<7 else 100),int(j>=7) if negative else int(j<10)))
 for j in range(20):rows.append((F(1000+j),F(0),1))
 for j in range(20):rows.append((F(10000+j),F(0),0))
 return {i+1:(x,z,2*x,3*x,4*x,5*x,y) for i,(x,z,y) in enumerate(rows)},('a','b','c','d','e','f'),(1,2,3)
