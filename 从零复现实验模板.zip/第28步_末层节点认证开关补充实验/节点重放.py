from pathlib import Path
from fractions import Fraction as F
from time import perf_counter,process_time
from datetime import datetime,timezone
from statistics import median
import importlib.util,sys,json,hashlib,argparse,platform,subprocess
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
EXP=HERE.parent/'第18步_最终算法正式实验'
spec=importlib.util.spec_from_file_location('frozen_formal_driver',EXP/'198_统一实验驱动.py')
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def save(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(M.API.encode(obj),f,ensure_ascii=False,indent=2)

def decoded_baseline(raw):return {int(h):{int(i):q for i,q in v.items()} for h,v in raw.items()}

def node_decisions(engine,node,ids):
    if node.get('abstract'):return {i:node['certificate']['decision'] for i in ids}
    groups=node.get('children',[ids])
    return {i:engine.decision(F(sum(engine.data[j][-1] for j in group),len(group))) for group in groups for i in group}

def capture(key):
    lock=M.verify_lock();data,attrs=M.dataset(key);cases=[];baseline_saved=[]
    original=M.SELECTED.FinalEvaluator.certificate
    def wrapped(self,ids,attrs,groups,first_distances,baseline):
        proof=original(self,ids,attrs,groups,first_distances,baseline)
        cases.append(dict(index=len(cases)+1,ids=tuple(ids),attrs=tuple(attrs),first_groups=tuple(tuple(g) for g in groups),
                          passed=proof is not None,reason=self.last_diagnostic['reason']))
        if not baseline_saved:baseline_saved.append(baseline)
        return proof
    M.SELECTED.FinalEvaluator.certificate=wrapped
    try:result=M.execute('TC',data,attrs,'main',False)
    finally:M.SELECTED.FinalEvaluator.certificate=original
    old=json.loads((EXP/'209_正式实验汇总.json').read_text(encoding='utf-8'))
    ref_result=next(x for x in old['main'] if x['key']==key)['methods']['TC']
    assert result['output_fingerprint']==ref_result['fingerprint']
    assert len(cases)==(34 if key=='climate' else 8)
    assert sum(c['passed'] for c in cases)==(4 if key=='climate' else 1)
    levels,alpha,beta=M.SETTINGS['main'];engine=M.SELECTED.FinalEvaluator(data,attrs,levels,alpha,beta)
    ref=M.K.AUDIT.Reference(data,attrs,levels,alpha,beta);trees={}
    for case in cases:
        ids=case['ids'];b=case['attrs']
        if b not in trees:trees[b]=ref.generate(b)
        real=next(n for n in trees[b]['nodes'] if n['depth']==levels[-1]-1 and tuple(n['ids'])==ids)
        off=engine.split_traced(ids,b,baseline_saved[0],False)
        on=engine.split_traced(ids,b,baseline_saved[0],True)
        assert tuple(tuple(g) for g in real['iterations'][0]['groups'])==case['first_groups']
        assert off.get('children')==real.get('children')
        assert len(off['iterations'])==len(real['iterations'])
        for a,z in zip(off['iterations'],real['iterations']):
            assert a['groups']==z['groups']
            assert a['centers']==z['centers']
        assert bool(on.get('abstract'))==case['passed']
        truth=ref.decisions(trees[b])[levels[-1]]
        decisions=node_decisions(engine,off,ids)
        assert decisions=={i:truth[i] for i in ids}==node_decisions(engine,on,ids)
        first=set(case['first_groups'][0]);movers=set()
        for it in off['iterations'][1:]:movers.update(first^set(it['groups'][0]))
        case.update(full_rounds=len(off['iterations']),on_rounds=1 if case['passed'] else len(off['iterations']),
                    mover_count=len(movers),movers=sorted(movers),decision_hash=M.API.digest(decisions),
                    off_children_hash=M.API.digest(off.get('children')),member_count=len(ids),dimension=len(b))
    save(HERE/f'{key}_节点.json',dict(dataset=key,cases=cases,baseline=baseline_saved[0],
         full_output_fingerprint=result['output_fingerprint'],lock_sha256=lock,
         protocol_sha256=sha(HERE/'实验方案.md'),independent_verified=len(cases),
         captured_utc=datetime.now(timezone.utc).isoformat()))
    print(json.dumps(dict(captured=key,cases=len(cases),passed=sum(c['passed'] for c in cases),independent_checks=len(cases)),ensure_ascii=False),flush=True)

def timed(key,method,repeat):
    lock=M.verify_lock();data,attrs=M.dataset(key)
    cases_file=HERE/f'{key}_节点.json';snap=json.loads(cases_file.read_text(encoding='utf-8'))
    baseline=decoded_baseline(snap['baseline']);levels,alpha,beta=M.SETTINGS['main']
    engine=M.SELECTED.FinalEvaluator(data,attrs,levels,alpha,beta)
    records=[]
    for case in snap['cases']:
        ids=tuple(case['ids']);b=tuple(case['attrs'])
        w=perf_counter();c=process_time()
        node=engine.split_traced(ids,b,baseline,method=='ON')
        cpu=process_time()-c;wall=perf_counter()-w
        # Comparison, encoding, output retention, and record construction are outside timing.
        assert M.API.digest(node_decisions(engine,node,ids))==case['decision_hash']
        if method=='ON':assert bool(node.get('abstract'))==case['passed']
        if not node.get('abstract'):assert M.API.digest(node.get('children'))==case['off_children_hash']
        rounds=1 if node.get('abstract') else len(node.get('iterations',[]))
        assert rounds==(case['on_rounds'] if method=='ON' else case['full_rounds'])
        records.append(dict(index=case['index'],passed=case['passed'],wall_seconds=wall,cpu_seconds=cpu,rounds=rounds))
        del node
    name=f'{key}_{method}_{repeat}.json'
    save(HERE/'计时原始记录'/name,dict(dataset=key,method=method,repeat=repeat,records=records,
       lock_sha256=lock,cases_sha256=sha(cases_file),protocol_sha256=sha(HERE/'实验方案.md'),
       driver_sha256=sha(Path(__file__)),python=sys.version,platform=platform.platform(),
       finished_utc=datetime.now(timezone.utc).isoformat(),cpu_affinity='not fixed',cpu_frequency='not fixed'))
    print(json.dumps(dict(dataset=key,method=method,repeat=repeat,seconds=round(sum(x['wall_seconds'] for x in records),4)),ensure_ascii=False),flush=True)

def run():
    # Sequential independent processes: no parallel timing, no replacement of completed records.
    for key in ('climate','blood'):
        if not (HERE/f'{key}_节点.json').exists():
            subprocess.run([sys.executable,str(Path(__file__)),'capture','--dataset',key],check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    for rep in range(6):
        for key in (('climate','blood') if rep%2==0 else ('blood','climate')):
            for method in (('OFF','ON') if rep%2==0 else ('ON','OFF')):
                if not (HERE/'计时原始记录'/f'{key}_{method}_{rep}.json').exists():
                    subprocess.run([sys.executable,str(Path(__file__)),'timed','--dataset',key,'--method',method,'--repeat',str(rep)],check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    report=[]
    for key in ('climate','blood'):
        snap=json.loads((HERE/f'{key}_节点.json').read_text(encoding='utf-8'))
        for subset in ('all','pass'):
            def selected(r):return subset=='all' or r['passed']
            cases=[v for v in snap['cases'] if selected(v)];result=dict(dataset=key,subset=subset,node_calls=len(cases),
                full_rounds=sum(v['full_rounds'] for v in cases),on_rounds=sum(v['on_rounds'] for v in cases),methods={})
            for method in ('OFF','ON'):
                vals=[];cpus=[]
                for rep in range(1,6):
                    records=json.loads((HERE/'计时原始记录'/f'{key}_{method}_{rep}.json').read_text(encoding='utf-8'))['records']
                    vals.append(sum(r['wall_seconds'] for r in records if selected(r)))
                    cpus.append(sum(r['cpu_seconds'] for r in records if selected(r)))
                result['methods'][method]=dict(values=vals,median=median(vals),minimum=min(vals),maximum=max(vals),cpu_values=cpus,cpu_median=median(cpus))
            off,on=result['methods']['OFF'],result['methods']['ON']
            result['ratio']=on['median']/off['median']
            result['ranges_overlap']=max(off['minimum'],on['minimum'])<=min(off['maximum'],on['maximum'])
            report.append(result)
    out=dict(rows=report,protocol_sha256=sha(HERE/'实验方案.md'),driver_sha256=sha(Path(__file__)),
             frozen_verified=M.verify_lock(),raw_hashes={str(p.relative_to(HERE)):sha(p) for p in sorted((HERE/'计时原始记录').glob('*.json'))})
    save(HERE/'补充实验汇总.json',out)
    print(json.dumps(out['rows'],ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['capture','timed','run']);p.add_argument('--dataset');p.add_argument('--method');p.add_argument('--repeat',type=int)
    a=p.parse_args()
    if a.mode=='capture':capture(a.dataset)
    elif a.mode=='timed':timed(a.dataset,a.method,a.repeat)
    else:run()
