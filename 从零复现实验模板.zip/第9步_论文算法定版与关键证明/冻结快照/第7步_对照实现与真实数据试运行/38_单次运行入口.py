"""Fresh-process entry point. Measurement and audit are deliberately separated."""
from pathlib import Path
from fractions import Fraction as F
from time import perf_counter_ns
import argparse
import hashlib
import importlib.util
import json
import os
import platform
import sys
import tracemalloc

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
STEP6 = ROOT / "第6步_实验方案与创新性复核"
spec = importlib.util.spec_from_file_location("exact_adapter", OUT / "36_统一求值与约简.py")
API = importlib.util.module_from_spec(spec)
spec.loader.exec_module(API)


def run(args):
    file = STEP6 / "待实验数据" / (args.dataset + "_exact.json")
    start = perf_counter_ns()
    payload = file.read_bytes()
    raw = json.loads(payload)
    io_ns = perf_counter_ns() - start
    manifest = json.loads((STEP6 / "31_数据清单与核查结果.json").read_text(encoding="utf-8"))
    entry = next(d for d in manifest["datasets"] if d["key"] == args.dataset)
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == entry["prepared_sha256"], "prepared input hash mismatch"
    protocol_file = STEP6 / "33_正式实验固定配置.json"
    protocol = json.loads(protocol_file.read_text(encoding="utf-8"))
    cfg = protocol["main_setting"] if args.setting == "main" else next(
        c for c in protocol["sensitivity_settings"] if c["id"] == args.setting)
    if args.mode == "memory":
        # Track the actual Fraction input, model initialization, caches and output.
        # Raw serialized text/JSON read before tracing is excluded, not process RSS.
        tracemalloc.start()
    setup_start = perf_counter_ns()
    data = {int(i): tuple(F(v) for v in row[:-1]) + (row[-1],)
            for i, row in raw["data"].items()}
    engine = API.Evaluator(data, raw["attributes"], cfg["levels"], F(cfg["alpha"]), F(cfg["beta"]))
    del data, raw, payload
    setup_ns = perf_counter_ns() - setup_start
    start = perf_counter_ns()
    if args.mode == "initial":
        tree, stats = engine.construct(engine.C, args.method)
        geometry = engine.final_geometry(tree)
    else:
        result = engine.solve(args.method)
    elapsed = perf_counter_ns() - start
    peak = None
    if args.mode == "memory":
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    if args.mode == "initial":
        summary = dict(initial_diagnostics=API.diagnostics(engine, tree), initial_stats=stats,
                       initial_structure_hash=API.digest(API.signature(tree)),
                       initial_geometry_hash=API.digest(geometry))
    else:
        summary = API.compact(engine, result)
    return dict(status="completed", scope="step7 pilot, not formal five-repeat benchmark",
                dataset=args.dataset, mode=args.mode, method=args.method, setting=args.setting,
                sample_count=len(engine.ids), attributes_before=len(engine.C),
                input_sha256=digest, protocol_sha256=hashlib.sha256(protocol_file.read_bytes()).hexdigest(),
                adapter_sha256=hashlib.sha256((OUT / "36_统一求值与约简.py").read_bytes()).hexdigest(),
                prior_core_sha256=hashlib.sha256(API.CORE_PATH.read_bytes()).hexdigest(),
                environment=dict(python=sys.version, executable=sys.executable, platform=platform.platform(),
                                 processor=platform.processor(), logical_cpu_count=os.cpu_count(),
                                 process_id=os.getpid(), workers=1),
                settings=cfg, time_ns=elapsed if args.mode == "timing" else None,
                initial_probe_ns=elapsed if args.mode == "initial" else None,
                peak_python_bytes=peak,
                memory_definition="Fraction input + initialization + caches + outputs; raw serialized IO excluded; not RSS",
                file_read_json_parse_ns=io_ns, exact_input_and_configuration_setup_ns=setup_ns,
                postprocessing_outside_timer=True, summary=summary)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["ionosphere", "sonar", "banknote", "climate"])
    ap.add_argument("--method", required=True, choices=["F0", "F1", "W", "L"])
    ap.add_argument("--mode", required=True, choices=["initial", "timing", "memory"])
    ap.add_argument("--setting", default="main", choices=["main", "threshold_wide", "threshold_narrow", "extra_depth"])
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    result = run(args)
    Path(args.output).write_text(json.dumps(API.encode(result), ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(status=result["status"], dataset=args.dataset, method=args.method, mode=args.mode,
                          time_ns=result["time_ns"], peak_python_bytes=result["peak_python_bytes"]),
                     ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
