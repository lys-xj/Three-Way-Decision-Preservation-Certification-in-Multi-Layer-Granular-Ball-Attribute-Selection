"""Exact F0/F1/W/L adapters. Prior research source files remain unchanged."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import importlib.util
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
CORE_PATH = ROOT.parent / "第5步_完整属性约简算法" / "20_完整属性约简算法.py"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


CORE = load_module("unchanged_step5_core", CORE_PATH)
encode, digest = CORE.encode, CORE.digest
STRUCTURE_FIELDS = ("path", "depth", "ids", "p", "seeds", "children", "stop",
                    "iteration_cap_reached")
TRACE_FIELDS = STRUCTURE_FIELDS + ("seed_distances", "iterations")


def signature(cache, history=False):
    fields = TRACE_FIELDS if history else STRUCTURE_FIELDS
    return [{k: n[k] for k in fields if k in n} for n in cache["nodes"]]


def new_stats():
    return dict(reused_split_nodes=0, reused_terminal_nodes=0, recomputed_nodes=0,
                recomputed_iterations=0, rule_stops=0, seed_checks=0,
                assignment_checks=0, whole_tree_fallbacks=0,
                discarded_certified_nodes=0)


def add_stats(total, part):
    for k in total:
        total[k] += part[k]


class CannotCertify(Exception):
    pass


class Evaluator(CORE.Reducer):
    def split(self, ids, attrs, history):
        """Same arithmetic kernel with optional per-round history storage."""
        points = {i: self.point(i, attrs) for i in ids}
        s0 = min(ids)
        q = {i: self.distance(points[i], points[s0]) for i in ids}
        s1 = min(ids, key=lambda i: (-q[i], i))
        node = dict(seeds=[s0, s1])
        if history:
            node["seed_distances"] = q
        if q[s1] == 0:
            node["stop"] = "保留坐标全部重合，不能分开"
            return node, 0
        centers = [points[s0], points[s1]]
        previous = None
        if history:
            node["iterations"] = []
        for t in range(1, self.T + 1):
            groups = [[], []]
            rows = [] if history else None
            for i in ids:
                d0 = self.distance(points[i], centers[0])
                d1 = self.distance(points[i], centers[1])
                group = 0 if d0 <= d1 else 1
                groups[group].append(i)
                if history:
                    rows.append(dict(id=i, d0=d0, d1=d1, group=group))
            if history:
                rec = dict(iteration=t, centers=centers, distances=rows, groups=groups)
                node["iterations"].append(rec)
            if not groups[0] or not groups[1]:
                node["stop"] = "出现空子组，取消本节点分裂"
                return node, t
            updated = [self.mean(g, attrs) for g in groups]
            if history:
                rec["updated_centers"] = updated
            if groups == previous:
                if history:
                    rec["converged"] = True
                break
            previous = groups
            centers = updated
        else:
            node["iteration_cap_reached"] = True
        if any(len(g) < self.minimum_child for g in groups):
            node["stop"] = "收敛或达上限后的子组人数小于2，取消分裂"
        else:
            node["children"] = groups
        return node, t

    def construct(self, attrs, method, reference=None):
        if method not in ("F0", "F1", "W", "L"):
            raise ValueError("unknown evaluator")
        attrs = self.ordered(attrs)
        if reference is not None:
            if reference["config"] != self.config:
                raise ValueError("cache configuration mismatch")
            if not set(attrs) < set(reference["attrs"]):
                raise ValueError("candidate must be a proper subset")
        if method in ("W", "L") and reference is None:
            return self.construct(attrs, "F1")
        old = {} if reference is None else {
            (n["depth"], tuple(n["ids"])): n for n in reference["nodes"]}
        stats, nodes = new_stats(), []

        def visit(ids, depth, path):
            node = dict(ids=list(ids), depth=depth, path=path,
                        p=F(sum(self.data[i][-1] for i in ids), len(ids)))
            nodes.append(node)
            stop = self.basic_stop(ids, depth)
            if stop:
                node["stop"] = stop
                stats["rule_stops"] += 1
                return
            projected = None
            if method in ("W", "L"):
                cached = old.get((depth, tuple(ids)))
                if cached is not None:
                    projected, proof = self.project_certificate(cached, reference["attrs"], attrs)
                    stats["seed_checks"] += proof["seed_checks"]
                    stats["assignment_checks"] += proof["assignment_checks"]
                if projected is None and method == "W":
                    raise CannotCertify()
            if projected is not None:
                node.update(projected)
                key = "reused_split_nodes" if "children" in node else "reused_terminal_nodes"
                stats[key] += 1
            else:
                trace, rounds = self.split(ids, attrs, history=method != "F0")
                node.update(trace)
                stats["recomputed_nodes"] += 1
                stats["recomputed_iterations"] += rounds
            for side, children in enumerate(node.get("children", [])):
                visit(children, depth + 1, path + ("L" if side == 0 else "R"))

        try:
            visit(self.ids, 0, "U")
        except CannotCertify:
            # Do not count projected-but-discarded nodes as successfully reused.
            wasted = stats["reused_split_nodes"] + stats["reused_terminal_nodes"]
            stats["reused_split_nodes"] = stats["reused_terminal_nodes"] = 0
            stats["discarded_certified_nodes"] = wasted
            stats["whole_tree_fallbacks"] = 1
            nodes.clear()
            fresh, fresh_stats = self.construct(attrs, "F1")
            add_stats(stats, fresh_stats)
            return fresh, stats
        return dict(attrs=attrs, config=self.config, nodes=nodes), stats

    def solve(self, method, order=None, audit=None):
        """One search for every method, no initial-cache copy or verbose traces."""
        order = self.C if order is None else tuple(order)
        if len(order) != len(self.C) or set(order) != set(self.C):
            raise ValueError("invalid deletion order")
        cache, initial_stats = self.construct(self.C, method)
        baseline = self.decisions(cache)
        if audit:
            audit("initial", self, None, cache, baseline, None)
        A, attempts, final_failures = self.C, [], []
        totals = new_stats()
        pass_id = 0
        while len(A) > 1:
            pass_id += 1
            accepted = False
            failures = []
            for a in order:
                if a not in A:
                    continue
                B = tuple(b for b in A if b != a)
                candidate, stats = self.construct(B, method,
                    reference=cache if method in ("W", "L") else None)
                decisions = self.decisions(candidate)
                changed_count, witness = 0, None
                for h in self.levels:
                    for i in self.ids:
                        if baseline[h][i] != decisions[h][i]:
                            changed_count += 1
                            if witness is None:
                                witness = dict(depth=h, sample=i, original=baseline[h][i],
                                               candidate=decisions[h][i])
                record = dict(attempt=len(attempts) + 1, pass_id=pass_id, current=A,
                              delete=a, candidate=B, accepted=changed_count == 0,
                              changed_count=changed_count, witness=witness, stats=stats)
                if audit:
                    audit("candidate", self, cache, candidate, baseline, record)
                attempts.append(record)
                add_stats(totals, stats)
                if changed_count == 0:
                    A, cache, accepted = B, candidate, True
                    break
                failures.append(dict(attribute=a, candidate=B, witness=witness))
            if not accepted:
                final_failures = failures
                break
        assert self.decisions(cache) == baseline
        assert len(attempts) <= len(self.C) * (len(self.C) + 1) // 2 - 1
        geometry = self.final_geometry(cache)
        return dict(method=method, initial_attributes=self.C, order=order,
                    final_attributes=A, baseline=baseline, cache=cache,
                    final_geometry=geometry, attempts=attempts, initial_stats=initial_stats,
                    candidate_stats=totals, final_failures=final_failures,
                    final_delta=0, max_accepted_delta=0,
                    stop_reason="nonempty-domain singleton" if len(A) == 1 else "single-deletion irreducible")


def diagnostics(engine, cache):
    levels = {}
    partitions = []
    for h in engine.levels:
        balls = engine.cut(cache, h)
        counts = Counter({d: 0 for d in ("A", "D", "R")})
        for n in balls:
            counts[engine.decision(n["p"])] += len(n["ids"])
        levels[h] = dict(decision_counts=dict(counts), ball_count=len(balls),
                         mixed_balls=sum(0 < n["p"] < 1 for n in balls),
                         ball_sizes=[len(n["ids"]) for n in balls],
                         all_one_decision=sum(v > 0 for v in counts.values()) == 1)
        partitions.append(sorted(tuple(n["ids"]) for n in balls))
    return dict(levels=levels, all_observation_partitions_identical=all(
                p == partitions[0] for p in partitions[1:]))


def compact(engine, result):
    """Outside timing; hashes let independent processes compare exact outputs."""
    path = [(r["current"], r["delete"], r["accepted"], r["changed_count"])
            for r in result["attempts"]]
    return dict(method=result["method"], attributes_before=len(engine.C),
                attributes_after=len(result["final_attributes"]),
                final_attributes=result["final_attributes"],
                retained_fraction=str(F(len(result["final_attributes"]), len(engine.C))),
                candidate_attempts=len(path),
                accepted_deletions=sum(r["accepted"] for r in result["attempts"]),
                final_delta=result["final_delta"], max_accepted_delta=result["max_accepted_delta"],
                initial_stats=result["initial_stats"], candidate_stats=result["candidate_stats"],
                final_failures=result["final_failures"], attempts=result["attempts"],
                stop_reason=result["stop_reason"],
                baseline_hash=digest(result["baseline"]), path_hash=digest(path),
                final_structure_hash=digest(signature(result["cache"])),
                final_trace_hash=None if result["method"] == "F0" else digest(signature(result["cache"], True)),
                final_geometry_hash=digest(result["final_geometry"]),
                final_diagnostics=diagnostics(engine, result["cache"]))
