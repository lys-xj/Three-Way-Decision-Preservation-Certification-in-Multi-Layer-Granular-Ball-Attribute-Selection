"""Exact, deterministic worked example. Standard library only; synthetic data."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
DATA = {
    1: (F(0),F(0),F(0),1),
    2: (F(1),F(0),F(1,10),1),
    3: (F(0),F(2),F(1,10),1),
    4: (F(1),F(2),F(0),0),
    5: (F(6),F(0),F(0),1),
    6: (F(7),F(0),F(1,10),0),
    7: (F(6),F(2),F(1,10),0),
    8: (F(7),F(2),F(0),0),
}
ALPHA, BETA = F(7,10), F(3,10)
MIN_CHILD, MAX_ITER = 2, 20
ATTRS = {'a':0,'b':1,'c':2}

def fmt(v):
    return str(v) if not isinstance(v,F) else (str(v.numerator) if v.denominator==1 else str(v))

def vector(i, attrs, data=DATA): return tuple(data[i][ATTRS[a]] for a in attrs)
def distance2(v,w): return sum((x-y)**2 for x,y in zip(v,w))
def mean(ids, attrs, data=DATA): return tuple(sum(vector(i,attrs,data)[j] for i in ids)/len(ids) for j in range(len(attrs)))
def decision(p): return 'A' if p>=ALPHA else ('R' if p<=BETA else 'D')

def summarize(ids, attrs, data=DATA):
    center=mean(ids,attrs,data)
    p=F(sum(data[i][3] for i in ids),len(ids))
    return dict(ids=list(ids),center=center,radius2=max(distance2(vector(i,attrs,data),center) for i in ids),positive=sum(data[i][3] for i in ids),p=p,purity=max(p,1-p),decision=decision(p))

def generate(attrs, depth_limit, data=DATA):
    nodes=[]; leaves=[]
    def visit(ids, depth, path):
        node=dict(path=path,depth=depth,**summarize(ids,attrs,data))
        nodes.append(node)
        if depth>=depth_limit: reason='达到最大深度'
        elif node['purity']==1: reason='类别已经一致'
        elif len(ids)<2*MIN_CHILD: reason='不足以分出两个至少2人的子球'
        else: reason=None
        if reason:
            node['stop']=reason;leaves.append(node);return
        seed0=min(ids)
        seed1=min(ids,key=lambda i:(-distance2(vector(seed0,attrs,data),vector(i,attrs,data)),i))
        node['seeds']=[seed0,seed1]
        node['seed_distances']={i:distance2(vector(seed0,attrs,data),vector(i,attrs,data)) for i in ids}
        if node['seed_distances'][seed1]==0:
            node['stop']='保留坐标全部重合，不能分开';leaves.append(node);return
        centers=[vector(seed0,attrs,data),vector(seed1,attrs,data)]
        previous=None; iterations=[]
        for t in range(1,MAX_ITER+1):
            groups=[[],[]];rows=[]
            for i in ids:
                d0,d1=distance2(vector(i,attrs,data),centers[0]),distance2(vector(i,attrs,data),centers[1])
                group=0 if d0<=d1 else 1
                groups[group].append(i);rows.append(dict(id=i,d0=d0,d1=d1,group=group))
            rec=dict(iteration=t,centers=centers,distances=rows,groups=groups)
            iterations.append(rec)
            if not groups[0] or not groups[1]:
                node['iterations']=iterations;node['stop']='出现空子组，取消本节点分裂';leaves.append(node);return
            updated=[mean(g,attrs,data) for g in groups]
            rec['updated_centers']=updated
            if groups==previous:
                rec['converged']=True;break
            previous=[list(g) for g in groups];centers=updated
        else:
            node['iteration_cap_reached']=True
        node['iterations']=iterations
        if any(len(g)<MIN_CHILD for g in groups):
            node['stop']='收敛或达上限后的子组人数小于2，取消分裂';leaves.append(node);return
        node['children']=[list(g) for g in groups]
        visit(groups[0],depth+1,path+'L');visit(groups[1],depth+1,path+'R')
    visit(sorted(data),0,'U')
    decisions={i:n['decision'] for n in leaves for i in n['ids']}
    scores={i:n['p'] for n in leaves for i in n['ids']}
    return dict(attrs=''.join(attrs),h=depth_limit,nodes=nodes,leaves=leaves,decisions=decisions,scores=scores)

def serialize(v):
    if isinstance(v,F):return fmt(v)
    if isinstance(v,dict):return {str(k):serialize(w) for k,w in v.items()}
    if isinstance(v,(list,tuple)):return [serialize(w) for w in v]
    return v

def build():
    keys=['abc','ab','ac','bc','a','b','c']
    runs={key:{h:generate(tuple(key),h) for h in (1,2)} for key in keys}
    audit=[]
    for key in keys:
        changes={h:[i for i in DATA if runs[key][h]['decisions'][i]!=runs['abc'][h]['decisions'][i]] for h in (1,2)}
        count=sum(len(v) for v in changes.values())
        audit.append(dict(attrs=key,changed=changes,count=count,delta=F(count,16),feasible=count==0))
        for h in (1,2):
            run=runs[key][h]
            flattened=[i for n in run['leaves'] for i in n['ids']]
            assert sorted(flattened)==sorted(DATA) and len(flattened)==len(set(flattened))
            assert all(len(n['ids'])>=MIN_CHILD for n in run['leaves'])
            assert all(n['depth']<=h for n in run['nodes'])
            assert generate(tuple(key),h)==run, 'Determinism check'
            for n in run['nodes']:
                assert all(distance2(vector(i,tuple(key)),n['center'])<=n['radius2'] for i in n['ids'])
                assert n['p']==F(sum(DATA[i][3] for i in n['ids']),len(n['ids']))
        # Depth2 partition refines depth1 for a fixed feature set, not across feature subsets.
        assert all(any(set(n['ids'])<=set(m['ids']) for m in runs[key][1]['leaves']) for n in runs[key][2]['leaves'])
    assert decision(BETA)=='R' and decision(ALPHA)=='A' and decision(F(1,2))=='D'
    # Independently specified hand-calculated expectations, not copied from algorithm output.
    assert {tuple(n['ids']) for n in runs['abc'][1]['leaves']}=={(1,2,3,4),(5,6,7,8)}
    assert {tuple(n['ids']) for n in runs['abc'][2]['leaves']}=={(1,2),(3,4),(5,6),(7,8)}
    assert {tuple(n['ids']) for n in runs['ac'][2]['leaves']}=={(1,3),(2,4),(5,7),(6,8)}
    assert [x['attrs'] for x in audit if x['feasible']]==['abc','ab']
    assert next(x for x in audit if x['attrs']=='ac')['count']==4
    # Regional counts can agree while individual decisions differ.
    assert sorted(runs['ac'][2]['decisions'].values())==sorted(runs['abc'][2]['decisions'].values())
    # Separate fixed-label input, not a label change during feature deletion.
    extra_labels=[1,1,1,1,1,0,0,1]
    extra_data={i:DATA[i][:3]+(extra_labels[i-1],) for i in DATA}
    extra_runs={key:{h:generate(tuple(key),h,extra_data) for h in (1,2)} for key in ('abc','ac')}
    assert all(extra_runs['abc'][h]['decisions']==extra_runs['ac'][h]['decisions'] for h in (1,2))
    assert {tuple(n['ids']) for n in extra_runs['abc'][2]['leaves']} != {tuple(n['ids']) for n in extra_runs['ac'][2]['leaves']}
    assert set(extra_runs['abc'][2]['decisions'].values())=={'A','D'}
    payload=dict(description='人为构造的8样本主算例A与独立补充算例B，不是实际数据集实验',data={i:dict(zip(['a','b','c','y'],values)) for i,values in DATA.items()},parameters=dict(alpha=ALPHA,beta=BETA,depths=[1,2],minimum_child_size=MIN_CHILD,maximum_lloyd_iterations=MAX_ITER,preprocessing='恒等变换；坐标为预设无量纲值'),runs=runs,subset_audit=audit,supplement=dict(description='独立算例B：用于展示成员变化但决定保持；两次属性比较中标签固定',data={i:dict(zip(['a','b','c','y'],values)) for i,values in extra_data.items()},runs=extra_runs),verification=dict(complete_partition=True,no_singletons=True,exact_arithmetic=True,repeated_run_identical=True,depth_refinement=True,independent_hand_expectations=True,all_seven_nonempty_subsets_enumerated=True,supplement_members_change_decisions_preserved=True))
    (OUT/'08_精确计算结果.json').write_text(json.dumps(serialize(payload),ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(serialize(audit),ensure_ascii=False,indent=2))
    for key in keys:
        for h in (1,2):print(key,h,[(n['ids'],fmt(n['p']),n['decision'],tuple(map(fmt,n['center'])),fmt(n['radius2'])) for n in runs[key][h]['leaves']])
    return payload

if __name__=='__main__':build()
