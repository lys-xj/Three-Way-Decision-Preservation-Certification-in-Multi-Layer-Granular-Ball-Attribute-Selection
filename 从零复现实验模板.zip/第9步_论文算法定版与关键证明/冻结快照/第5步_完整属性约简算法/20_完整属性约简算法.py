"""Exact research prototype: fixed-baseline, restart-on-success reduction.

Standard library only. No oracle, external data, or implicit reference rebuilds.
The cache stores membership and split traces, not all geometric ball radii.
"""
from fractions import Fraction as F
from copy import deepcopy
import hashlib
import json


def encode(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(encode(value), ensure_ascii=False,
                                    sort_keys=True).encode('utf-8')).hexdigest()


class Reducer:
    def __init__(self, data, attributes, levels=(1, 2), alpha=F(7, 10), beta=F(3, 10)):
        self.C = tuple(attributes)
        if not self.C or len(set(self.C)) != len(self.C):
            raise ValueError('属性名必须非空且互不相同')
        if any(not isinstance(a, str) for a in self.C):
            raise ValueError('属性名使用字符串')
        self.col = {a: i for i, a in enumerate(self.C)}
        if not data or any(type(i) is not int for i in data):
            raise ValueError('样本采用唯一整数编号')
        self.data = {}
        for i, row in data.items():
            if len(row) != len(self.C) + 1 or row[-1] not in (0, 1):
                raise ValueError('每行是全部条件属性加一个二元标签')
            if any(isinstance(v, float) for v in row[:-1]):
                raise ValueError('精确版本请使用整数、Fraction或十进制字符串，勿用float')
            self.data[i] = tuple(F(v) for v in row[:-1]) + (int(row[-1]),)
        self.ids = tuple(sorted(self.data))
        if {self.data[i][-1] for i in self.ids} != {0, 1}:
            raise ValueError('本研究要求输入中两类均存在')
        self.levels = tuple(sorted(set(levels)))
        if len(self.levels) < 2 or any(type(h) is not int or h < 1 for h in self.levels):
            raise ValueError('至少两个不同的正整数深度')
        self.H = max(self.levels)
        self.alpha, self.beta = F(alpha), F(beta)
        if not 0 < self.beta < self.alpha < 1:
            raise ValueError('阈值必须满足0 < beta < alpha < 1')
        self.T, self.minimum_child = 20, 2
        self.config = digest(dict(data=self.data, C=self.C, levels=self.levels,
                                  alpha=self.alpha, beta=self.beta,
                                  T=self.T, minimum_child=self.minimum_child,
                                  generator='Gamma0-step3-exact-v1'))

    def ordered(self, attrs):
        attrs = tuple(attrs)
        wanted = set(attrs)
        if not attrs or len(wanted) != len(attrs) or not wanted <= set(self.C):
            raise ValueError('保留属性必须是非空合法子集')
        return tuple(a for a in self.C if a in wanted)

    def point(self, i, attrs):
        return tuple(self.data[i][self.col[a]] for a in attrs)

    def mean(self, ids, attrs):
        return tuple(sum(self.data[i][self.col[a]] for i in ids) / len(ids) for a in attrs)

    @staticmethod
    def distance(v, w):
        return sum((a - b) ** 2 for a, b in zip(v, w))

    def decision(self, p):
        return 'A' if p >= self.alpha else ('R' if p <= self.beta else 'D')

    def basic_stop(self, ids, depth):
        if depth >= self.H:
            return '达到最大深度'
        if len({self.data[i][-1] for i in ids}) == 1:
            return '类别已经一致'
        if len(ids) < 2 * self.minimum_child:
            return '不足以分出两个至少2人的子球'
        return None

    def split_trace(self, ids, attrs):
        """One complete node split, never recursive; returns its full trace."""
        s0 = min(ids)
        q = {i: self.distance(self.point(i, attrs), self.point(s0, attrs)) for i in ids}
        s1 = min(ids, key=lambda i: (-q[i], i))
        node = dict(seeds=[s0, s1], seed_distances=q)
        if q[s1] == 0:
            node['stop'] = '保留坐标全部重合，不能分开'
            return node
        centers = [self.point(s0, attrs), self.point(s1, attrs)]
        previous = None
        iterations = []
        for t in range(1, self.T + 1):
            groups, rows = [[], []], []
            for i in ids:
                d0 = self.distance(self.point(i, attrs), centers[0])
                d1 = self.distance(self.point(i, attrs), centers[1])
                group = 0 if d0 <= d1 else 1
                groups[group].append(i)
                rows.append(dict(id=i, d0=d0, d1=d1, group=group))
            rec = dict(iteration=t, centers=centers, distances=rows, groups=groups)
            iterations.append(rec)
            if not groups[0] or not groups[1]:
                node.update(iterations=iterations, stop='出现空子组，取消本节点分裂')
                return node
            updated = [self.mean(g, attrs) for g in groups]
            rec['updated_centers'] = updated
            if groups == previous:
                rec['converged'] = True
                break
            previous = [list(g) for g in groups]
            centers = updated
        else:
            node['iteration_cap_reached'] = True
        node['iterations'] = iterations
        if any(len(g) < self.minimum_child for g in groups):
            node['stop'] = '收敛或达上限后的子组人数小于2，取消分裂'
        else:
            node['children'] = [list(g) for g in groups]
        return node

    def project_certificate(self, old, A, B):
        """Certify and construct a truthful B trace; never return an A trace as B."""
        old_col = {a: i for i, a in enumerate(A)}
        kept_set = set(B)
        kept = [old_col[a] for a in B]
        removed = [(old_col[a], self.col[a]) for a in A if a not in kept_set]
        s0, s1 = old['seeds']
        q = {i: old['seed_distances'][i] - sum(
            (self.data[i][j] - self.data[s0][j]) ** 2 for _, j in removed)
             for i in old['ids']}
        proof = dict(status='PASS', seed_checks=len(q), assignment_checks=0)
        if old.get('iterations'):
            selected = min(old['ids'], key=lambda i: (-q[i], i))
            if selected != s1 or q[s1] == 0:
                proof.update(status='UNKNOWN', reason='种子未保持', old_seed=s1, new_seed=selected)
                return None, proof
        else:
            # All coordinates coincident in A remain coincident in B.
            assert max(q.values()) == 0
        new = dict(seeds=[s0, s1], seed_distances=q)
        if 'iterations' in old:
            iterations = []
            for rec in old['iterations']:
                rows = []
                for row in rec['distances']:
                    i = row['id']
                    ds = [row[f'd{g}'] - sum(
                        (self.data[i][j] - rec['centers'][g][k]) ** 2
                        for k, j in removed) for g in (0, 1)]
                    assert min(ds) >= 0
                    group = 0 if ds[0] <= ds[1] else 1
                    proof['assignment_checks'] += 1
                    if group != row['group']:
                        proof.update(status='UNKNOWN', reason='逐轮分配未保持',
                                     iteration=rec['iteration'], sample=i)
                        return None, proof
                    rows.append(dict(id=i, d0=ds[0], d1=ds[1], group=group))
                nr = dict(iteration=rec['iteration'],
                          centers=[tuple(c[k] for k in kept) for c in rec['centers']],
                          distances=rows, groups=deepcopy(rec['groups']))
                if 'updated_centers' in rec:
                    nr['updated_centers'] = [tuple(c[k] for k in kept) for c in rec['updated_centers']]
                if 'converged' in rec:
                    nr['converged'] = rec['converged']
                iterations.append(nr)
            new['iterations'] = iterations
        for field in ('stop', 'children', 'iteration_cap_reached'):
            if field in old:
                new[field] = deepcopy(old[field])
        proof['reason'] = '种子和每轮分配均保持；已生成保留坐标的真实记录'
        return new, proof

    def build(self, attrs, reference=None):
        attrs = self.ordered(attrs)
        if reference is not None:
            if reference['config'] != self.config:
                raise ValueError('数据、规则或阈值与缓存版本不一致')
            if not set(attrs) < set(reference['attrs']):
                raise ValueError('缓存试删要求真子集')
        old = {} if reference is None else {
            (n['depth'], tuple(n['ids'])): n for n in reference['nodes']}
        nodes, events = [], []
        stats = dict(reused_split_nodes=0, reused_terminal_nodes=0,
                     recomputed_nodes=0, recomputed_iterations=0,
                     rule_stops=0, seed_checks=0, assignment_checks=0)

        def visit(ids, depth, path):
            node = dict(ids=list(ids), depth=depth, path=path,
                        p=F(sum(self.data[i][-1] for i in ids), len(ids)))
            nodes.append(node)
            stop = self.basic_stop(ids, depth)
            if stop:
                node['stop'] = stop
                stats['rule_stops'] += 1
                return
            cached = old.get((depth, tuple(ids)))
            proof = dict(status='UNKNOWN', reason='没有同成员、同深度的旧节点',
                         seed_checks=0, assignment_checks=0)
            projected = None
            if cached is not None:
                projected, proof = self.project_certificate(cached, reference['attrs'], attrs)
            stats['seed_checks'] += proof['seed_checks']
            stats['assignment_checks'] += proof['assignment_checks']
            if projected is not None:
                node.update(projected)
                stats['reused_split_nodes' if 'children' in projected else 'reused_terminal_nodes'] += 1
                action = '认证并投影记录'
            else:
                trace = self.split_trace(ids, attrs)
                node.update(trace)
                stats['recomputed_nodes'] += 1
                stats['recomputed_iterations'] += len(trace.get('iterations', []))
                action = '重算本节点并记录新轨迹'
            events.append(dict(ids=list(ids), depth=depth, action=action, proof=proof))
            for side, children in enumerate(node.get('children', [])):
                visit(children, depth + 1, path + ('L' if side == 0 else 'R'))

        visit(self.ids, 0, 'U')
        return dict(attrs=attrs, config=self.config, nodes=nodes), events, stats

    @staticmethod
    def cut(cache, h):
        return [n for n in cache['nodes'] if n['depth'] == h or
                ('children' not in n and n['depth'] < h)]

    def decisions(self, cache):
        return {h: {i: self.decision(n['p']) for n in self.cut(cache, h) for i in n['ids']}
                for h in self.levels}

    def changes(self, baseline, cache):
        current = self.decisions(cache)
        return [dict(depth=h, sample=i, original=baseline[h][i], candidate=current[h][i])
                for h in self.levels for i in self.ids if baseline[h][i] != current[h][i]]

    def reduce(self, order=None, audit=None):
        order = self.C if order is None else tuple(order)
        if len(order) != len(self.C) or set(order) != set(self.C):
            raise ValueError('删除顺序必须恰好包含全部属性一次')
        cache, _, initial_stats = self.build(self.C)
        baseline = self.decisions(cache)
        initial_cache = deepcopy(cache)
        A = self.C
        attempts, final_failures = [], []
        pass_id = 0
        while len(A) > 1:
            pass_id += 1
            failures = []
            accepted = False
            for a in order:
                if a not in A:
                    continue
                B = tuple(b for b in A if b != a)
                candidate, events, stats = self.build(B, cache)
                change = self.changes(baseline, candidate)
                record = dict(attempt=len(attempts) + 1, pass_id=pass_id,
                              current=A, delete=a, candidate=B, accepted=not change,
                              changed_count=len(change), witness=change[0] if change else None,
                              all_changes=change, stats=stats, events=events)
                if audit is not None:
                    audit(self, cache, candidate, baseline, record)
                attempts.append(record)
                if not change:
                    A, cache = B, candidate
                    accepted = True
                    break  # Restart; earlier failed deletions refer to a different set.
                failures.append(dict(attribute=a, candidate=B, witness=change[0]))
            if not accepted:
                final_failures = failures
                break
        assert not self.changes(baseline, cache)
        assert len(attempts) <= len(self.C) * (len(self.C) + 1) // 2 - 1
        return dict(initial_attributes=self.C, order=order, final_attributes=A,
                    baseline=baseline, initial_cache=initial_cache, cache=cache,
                    initial_stats=initial_stats, attempts=attempts,
                    final_failures=final_failures,
                    stop_reason='只剩1个属性；空集不在问题范围' if len(A) == 1 else
                                '当前集合下所有单属性删除均经精确核验不保持')

    def final_geometry(self, cache):
        """Explicit additional work: export all requested balls' means and radii²."""
        attrs = cache['attrs']
        result = {}
        for h in self.levels:
            balls = []
            for node in self.cut(cache, h):
                mean = self.mean(node['ids'], attrs)
                balls.append(dict(ids=node['ids'], center=mean,
                                  radius2=max(self.distance(self.point(i, attrs), mean) for i in node['ids']),
                                  p=node['p'], decision=self.decision(node['p'])))
            result[h] = balls
        return result
