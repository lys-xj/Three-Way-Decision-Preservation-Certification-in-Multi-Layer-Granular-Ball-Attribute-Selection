"""Reference-driven exact audit with bounded reference-tree retention and resume."""
from pathlib import Path
from fractions import Fraction as F
from time import perf_counter
import argparse
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
STEP7 = ROOT / "第7步_对照实现与真实数据试运行"
STEP6 = ROOT / "第6步_实验方案与创新性复核"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


API_PATH = STEP7 / "36_统一求值与约简.py"
REF_PATH = ROOT / "第3步_确定规则与手算例子" / "09_复算程序.py"
API = load("unchanged_step7", API_PATH)
REF = load("unchanged_step3", REF_PATH)
METHODS = ("F0", "F1", "W", "L")
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(API.encode(value), f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


class Reference:
    def __init__(self, data, attrs, levels, alpha, beta):
        self.attrs, self.levels = tuple(attrs), tuple(levels)
        self.data = {i: tuple(row[:-1][:3]) + (F(0),) * max(0, 3 - len(attrs)) +
                     (row[-1],) + tuple(row[:-1][3:]) for i, row in data.items()}
        self.alpha, self.beta = F(alpha), F(beta)
        self.calls = 0
        self.seconds = 0.0

    def generate(self, attrs, cached_vectors=True):
        attrs = tuple(attrs)
        previous = REF.ATTRS, REF.ALPHA, REF.BETA, REF.vector
        REF.ATTRS = {a: (j if j < 3 else j + 1) for j, a in enumerate(self.attrs)}
        REF.ALPHA, REF.BETA = self.alpha, self.beta
        original_vector = REF.vector
        start = perf_counter()
        try:
            if cached_vectors:
                # Every value is computed by the original helper itself.
                # During this call the data and selected attrs are immutable.
                vectors = {i: original_vector(i, attrs, self.data) for i in self.data}

                def vector(i, selected, data=REF.DATA):
                    if selected is attrs and data is self.data:
                        return vectors[i]
                    return original_vector(i, selected, data)

                REF.vector = vector
            return REF.generate(attrs, max(self.levels), self.data)
        finally:
            REF.ATTRS, REF.ALPHA, REF.BETA, REF.vector = previous
            self.calls += 1
            self.seconds += perf_counter() - start

    def decisions(self, tree):
        # Deliberately spell out the reference cut and threshold logic.
        return {h: {i: ("A" if n["p"] >= self.alpha else "R" if n["p"] <= self.beta else "D")
                    for n in tree["nodes"]
                    if n["depth"] == h or ("children" not in n and n["depth"] < h)
                    for i in n["ids"]} for h in self.levels}

    def geometry(self, tree):
        return {h: [dict(ids=n["ids"], center=n["center"], radius2=n["radius2"], p=n["p"],
                         decision="A" if n["p"] >= self.alpha else "R" if n["p"] <= self.beta else "D")
                    for n in tree["nodes"]
                    if n["depth"] == h or ("children" not in n and n["depth"] < h)]
                for h in self.levels}


def state_write(path, state):
    if path:
        atomic_json(path, dict(payload=state, payload_sha256=API.digest(state)))


def audit_case(name, data, attrs, levels=(1, 2), alpha=F(7, 10), beta=F(3, 10),
               order=None, checkpoint=None, stop_after=None, seconds=None, progress_every=10):
    """Check each shared proposal against the independent reference before committing."""
    engine = API.Evaluator(data, attrs, levels, alpha, beta)
    order = tuple(engine.C if order is None else order)
    assert len(order) == len(engine.C) and set(order) == set(engine.C)
    ref = Reference(engine.data, engine.C, engine.levels, engine.alpha, engine.beta)
    identity = dict(case=name, config=engine.config, order=order, api_sha256=sha(API_PATH),
                    core_sha256=sha(API.CORE_PATH), ref_sha256=sha(REF_PATH),
                    auditor_sha256=sha(Path(__file__)))
    token = API.digest(identity)
    state = None
    if checkpoint and Path(checkpoint).exists():
        envelope = json.loads(Path(checkpoint).read_text(encoding="utf-8"))
        state = envelope["payload"]
        assert API.digest(state) == envelope["payload_sha256"], "checkpoint integrity failed"
        assert state["identity_token"] == token, "checkpoint input/code identity mismatch"
    start = perf_counter()
    original = ref.generate(engine.C)
    baseline = ref.decisions(original)
    original_diagnostics = API.diagnostics(engine, original)
    if state is None:
        state = dict(identity=identity, identity_token=token, current=list(engine.C), next_index=0,
                     pass_id=1, attempts=[], baseline_hash=API.digest(baseline),
                     completed=False, segments=0, elapsed_audit_seconds=0.0,
                     reference_calls=0, reference_seconds=0.0)
    assert state["baseline_hash"] == API.digest(baseline)
    # Validate saved search progression before trusting a resume position.
    replay = engine.C
    expected_index, expected_pass = 0, 1
    for r in state["attempts"]:
        while expected_index < len(order) and order[expected_index] not in replay:
            expected_index += 1
        assert tuple(r["current"]) == replay and r["delete"] == order[expected_index]
        assert r["pass_id"] == expected_pass
        B = tuple(a for a in replay if a != r["delete"])
        assert tuple(r["candidate"]) == B
        if r["accepted"]:
            replay, expected_index, expected_pass = B, 0, expected_pass + 1
        else:
            expected_index += 1
    assert replay == tuple(state["current"])
    # next_index is saved immediately after a trial; skip-absent happens on next loop.
    assert expected_index == state["next_index"]
    A = replay
    current_ref = original if A == engine.C else ref.generate(A)
    caches = {}
    for method in METHODS:
        cache, _ = engine.construct(A, method)
        assert API.signature(cache, method != "F0") == API.signature(current_ref, method != "F0")
        assert engine.decisions(cache) == baseline
        caches[method] = cache
    del original
    state["segments"] += 1
    completed_this_segment = 0

    def checkpoint_now():
        state["elapsed_audit_seconds"] += perf_counter() - timing_origin[0]
        timing_origin[0] = perf_counter()
        state["reference_calls"] = previous_calls + ref.calls
        state["reference_seconds"] = previous_ref_seconds + ref.seconds
        state_write(checkpoint, state)

    previous_calls, previous_ref_seconds = state["reference_calls"], state["reference_seconds"]
    timing_origin = [start]
    checkpoint_now()
    while not state["completed"]:
        index = state["next_index"]
        while index < len(order) and order[index] not in A:
            index += 1
        if len(A) == 1 or index == len(order):
            state["completed"] = True
            checkpoint_now()
            break
        if ((stop_after is not None and completed_this_segment >= stop_after) or
                (seconds is not None and perf_counter() - start >= seconds)):
            checkpoint_now()
            return dict(status="checkpointed", case=name, attempts=len(state["attempts"]),
                        current=list(A), next_index=state["next_index"],
                        completed_this_segment=completed_this_segment)
        delete = order[index]
        B = tuple(a for a in A if a != delete)
        proposed_ref = ref.generate(B)
        answer = ref.decisions(proposed_ref)
        changed = [(h, i) for h in engine.levels for i in engine.ids if answer[h][i] != baseline[h][i]]
        safe = not changed
        record = dict(attempt=len(state["attempts"]) + 1, pass_id=state["pass_id"], current=A,
                      delete=delete, candidate=B, accepted=safe, changed_count=len(changed),
                      witness=None if safe else dict(depth=changed[0][0], sample=changed[0][1],
                            original=baseline[changed[0][0]][changed[0][1]],
                            candidate=answer[changed[0][0]][changed[0][1]]),
                      method_stats={}, reference_structure_hash=API.digest(API.signature(proposed_ref)),
                      reference_trace_hash=API.digest(API.signature(proposed_ref, True)))
        proposed_caches = {}
        for method in METHODS:
            old = caches[method]
            assert API.signature(old, method != "F0") == API.signature(current_ref, method != "F0")
            candidate, stats = engine.construct(B, method, old if method in ("W", "L") else None)
            assert API.signature(candidate, method != "F0") == API.signature(proposed_ref, method != "F0"), (method, B)
            assert engine.decisions(candidate) == answer
            assert API.signature(old, method != "F0") == API.signature(current_ref, method != "F0"), "old cache mutated"
            if method == "F0":
                assert all("iterations" not in n and "seed_distances" not in n for n in candidate["nodes"])
            record["method_stats"][method] = stats
            if safe:
                proposed_caches[method] = candidate
        # A checkpoint is committed only after ALL four methods have passed.
        state["attempts"].append(record)
        if safe:
            A, current_ref, caches = B, proposed_ref, proposed_caches
            state["current"], state["next_index"] = list(A), 0
            state["pass_id"] += 1
        else:
            state["next_index"] = index + 1
        del candidate, proposed_ref, proposed_caches, old
        completed_this_segment += 1
        checkpoint_now()
        if progress_every and (len(state["attempts"]) % progress_every == 0 or safe):
            print(json.dumps(dict(case=name, checked_attempts=len(state["attempts"]), kept=len(A),
                                  delete=delete, accepted=safe,
                                  segment_seconds=round(perf_counter()-start, 1)), ensure_ascii=False), flush=True)

    attempts = state["attempts"]
    final_failures = [r for r in attempts if tuple(r["current"]) == A]
    if len(A) > 1:
        assert len(final_failures) == len(A)
        assert {r["delete"] for r in final_failures} == set(A)
        assert all(not r["accepted"] and r["changed_count"] > 0 for r in final_failures)
    assert ref.decisions(current_ref) == baseline
    expected_geometry = ref.geometry(current_ref)
    methods = {}
    for method in METHODS:
        assert engine.final_geometry(caches[method]) == expected_geometry
        totals = API.new_stats()
        for r in attempts:
            API.add_stats(totals, r["method_stats"][method])
        path = [(r["current"], r["delete"], r["accepted"], r["changed_count"]) for r in attempts]
        methods[method] = dict(final_attributes=A, attributes_after=len(A), candidate_attempts=len(attempts),
            accepted_deletions=sum(r["accepted"] for r in attempts), candidate_stats=totals,
            baseline_hash=API.digest(baseline), path_hash=API.digest(path),
            final_structure_hash=API.digest(API.signature(caches[method])),
            final_trace_hash=None if method == "F0" else API.digest(API.signature(caches[method], True)),
            final_geometry_hash=API.digest(expected_geometry), final_delta=0)
    common = dict(candidates=len(attempts), safe=sum(r["accepted"] for r in attempts),
                  certified=sum(r["method_stats"]["W"]["whole_tree_fallbacks"] == 0 for r in attempts))
    common["pass_but_unsafe"] = sum(not r["accepted"] and r["method_stats"]["W"]["whole_tree_fallbacks"] == 0 for r in attempts)
    common["unknown_and_safe"] = sum(r["accepted"] and r["method_stats"]["W"]["whole_tree_fallbacks"] != 0 for r in attempts)
    assert common["pass_but_unsafe"] == 0
    assert len(attempts) <= len(engine.C)*(len(engine.C)+1)//2 - 1
    return dict(status="completed", all_passed=True, case=name, sample_count=len(data), attributes=list(engine.C),
                levels=list(engine.levels), settings=dict(alpha=str(engine.alpha), beta=str(engine.beta)),
                methods=methods, attempts=attempts, final_failures=final_failures,
                initial_diagnostics=original_diagnostics, final_diagnostics=API.diagnostics(engine, current_ref),
                candidate_checks=4*len(attempts), mismatches=0, common_candidate_pool=common,
                segments=state["segments"], audit_elapsed_seconds=state["elapsed_audit_seconds"],
                reference_calls=state["reference_calls"], reference_seconds=state["reference_seconds"],
                identity=identity, complete_reference_trees_retained_at_once_at_most=2,
                note="Streaming same-proposal audit; not an algorithm runtime measurement")


def dataset(key):
    file = STEP6 / "待实验数据" / (key + "_exact.json")
    manifest = json.loads((STEP6 / "31_数据清单与核查结果.json").read_text(encoding="utf-8"))
    expected = next(d["prepared_sha256"] for d in manifest["datasets"] if d["key"] == key)
    assert sha(file) == expected
    raw = json.loads(file.read_text(encoding="utf-8"))
    return {int(i): tuple(F(x) for x in row[:-1])+(row[-1],) for i,row in raw["data"].items()}, raw["attributes"]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", required=True, choices=["sonar", "banknote", "ionosphere", "climate"])
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--stop-after", type=int)
    p.add_argument("--seconds", type=float)
    args = p.parse_args()
    data, attrs = dataset(args.dataset)
    result = audit_case(args.dataset, data, attrs, checkpoint=args.checkpoint,
                        stop_after=args.stop_after, seconds=args.seconds)
    atomic_json(args.output, result)
    print(json.dumps({k:v for k,v in result.items() if k in
                     ("status","case","candidate_checks","segments","audit_elapsed_seconds","mismatches","current")},
                     ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
