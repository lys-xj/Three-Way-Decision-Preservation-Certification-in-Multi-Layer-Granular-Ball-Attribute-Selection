"""Check the frozen snapshot before an optional single run. No algorithm changes."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_snapshot(root=OUT):
    root = Path(root)
    lock = json.loads((root / '73_冻结版本清单.json').read_text(encoding='utf-8'))
    snap = (root / lock['snapshot_root']).resolve()
    for name, expected in lock['snapshots'].items():
        path = (snap / name).resolve()
        if not path.is_relative_to(snap) or not path.is_file():
            raise ValueError('Missing or invalid snapshot path: ' + name)
        if sha(path) != expected['sha256']:
            raise ValueError('Frozen source/data changed: ' + name)
    return lock, snap


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--dataset', choices=['banknote', 'sonar', 'ionosphere', 'climate'])
    parser.add_argument('--method', choices=['F0', 'F1', 'W', 'L'])
    parser.add_argument('--mode', choices=['initial', 'timing', 'memory'])
    parser.add_argument('--setting', default='main', choices=['main', 'threshold_wide', 'threshold_narrow', 'extra_depth'])
    parser.add_argument('--output')
    args = parser.parse_args()
    lock, snap = verify_snapshot()
    if args.check_only:
        print(json.dumps(dict(version=lock['version_id'], files_checked=len(lock['snapshots']), unchanged=True)))
        return
    if not all((args.dataset, args.method, args.mode, args.output)):
        parser.error('Use --check-only, or provide --dataset --method --mode --output')
    target = Path(args.output).resolve()
    if target.is_relative_to(snap) or target.exists():
        parser.error('Use a new result file outside the frozen snapshot')
    worker = load_module('paper_frozen_worker', snap / '第7步_对照实现与真实数据试运行' / '38_单次运行入口.py')
    result = worker.run(SimpleNamespace(**vars(args)))
    result['original_worker_scope'] = result['scope']
    result['scope'] = 'Single run of frozen paper version; not a completed formal repetition protocol'
    result['frozen_version'] = lock['version_id']
    result['freeze_manifest_sha256'] = sha(OUT / '73_冻结版本清单.json')
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as f:
        json.dump(worker.API.encode(result), f, ensure_ascii=False, indent=2)
    print(json.dumps(dict(status='completed', version=lock['version_id'], dataset=args.dataset,
                          method=args.method, mode=args.mode, output=str(target)), ensure_ascii=False))


if __name__ == '__main__':
    main()
