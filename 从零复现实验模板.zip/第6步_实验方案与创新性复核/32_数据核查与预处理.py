"""Prepare exact finite-table inputs from preserved official UCI archives.

This script does not run a reduction algorithm or produce performance results.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import csv
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parent
SPECS = [
    dict(key="ionosphere", uci_id=52, n=351, m=34, member="ionosphere.data",
         name="Ionosphere", page="https://archive.ics.uci.edu/dataset/52/ionosphere",
         doi="10.24432/C5W01B", target="g", label_map={"g": 1, "b": 0}),
    dict(key="sonar", uci_id=151, n=208, m=60, member="sonar.all-data",
         name="Connectionist Bench (Sonar, Mines vs. Rocks)",
         page="https://archive.ics.uci.edu/dataset/151/connectionist+bench+sonar+mines+vs+rocks",
         doi="10.24432/C5T01Q", target="M", label_map={"M": 1, "R": 0}),
    dict(key="banknote", uci_id=267, n=1372, m=4, member="data_banknote_authentication.txt",
         name="Banknote Authentication", page="https://archive.ics.uci.edu/dataset/267/banknote+authentication",
         doi="10.24432/C55P57", target="1", label_map={"1": 1, "0": 0}),
    dict(key="climate", uci_id=252, n=540, m=18, member="pop_failures.dat",
         name="Climate Model Simulation Crashes",
         page="https://archive.ics.uci.edu/dataset/252/climate+model+simulation+crashes",
         doi="10.24432/C5HG71", target="0 (failure)", label_map={"0": 1, "1": 0}),
]


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def main():
    records = json.loads((ROOT / "30_下载来源与原始文件校验.json").read_text(encoding="utf-8"))
    prepared = ROOT / "待实验数据"
    prepared.mkdir(exist_ok=True)
    summaries = []
    for spec in SPECS:
        key = spec["key"]
        info = next(r for r in records["results"] if r["name"] == key)
        archive = ROOT / info["file"]
        assert sha(archive.read_bytes()) == info["sha256"]
        with zipfile.ZipFile(archive) as z:
            raw = z.read(spec["member"])  # Read named member only; never extract arbitrary paths.
        lines = [line.strip() for line in raw.decode("utf-8-sig").splitlines() if line.strip()]
        if key == "climate":
            names = lines[0].split()
            assert len(names) == 21 and names[-1] == "outcome"
            rows = [line.split() for line in lines[1:]]
            assert all(len(row) == 21 for row in rows)
            raw_features = [row[2:20] for row in rows]
            source_labels = [row[20] for row in rows]
            original_names = names[2:20]
            source_ids = [row[:2] for row in rows]
            excluded_identifiers = ["Study", "Run"]
        else:
            rows = list(csv.reader(io.StringIO("\n".join(lines))))
            assert all(len(row) == spec["m"] + 1 for row in rows)
            raw_features = [row[:-1] for row in rows]
            source_labels = [row[-1] for row in rows]
            original_names = [f"feature_{j+1:02d}" for j in range(spec["m"])]
            source_ids = None
            excluded_identifiers = []
        assert len(rows) == spec["n"]
        assert not any(v in ("", "?", "NA", "NaN") for row in raw_features for v in row)
        assert set(source_labels) == set(spec["label_map"])
        numeric = [tuple(F(v) for v in row) for row in raw_features]
        labels = [spec["label_map"][v] for v in source_labels]
        lo = [min(row[j] for row in numeric) for j in range(spec["m"])]
        hi = [max(row[j] for row in numeric) for j in range(spec["m"])]
        kept = [j for j in range(spec["m"]) if lo[j] != hi[j]]
        constant = [j for j in range(spec["m"]) if lo[j] == hi[j]]
        attrs = [f"a{j+1:02d}" for j in kept]
        scales = [dict(attribute=f"a{j+1:02d}", source_feature=original_names[j],
                       original_feature_index_1based=j+1, minimum=str(lo[j]), maximum=str(hi[j]))
                  for j in kept]
        normalized = [tuple((row[j] - lo[j]) / (hi[j] - lo[j]) for j in kept) for row in numeric]
        assert all(0 <= v <= 1 for row in normalized for v in row)
        assert all(F(0) == min(row[k] for row in normalized) and F(1) == max(row[k] for row in normalized)
                   for k in range(len(kept)))
        data = {str(i+1): [str(v) for v in row] + [labels[i]] for i, row in enumerate(normalized)}
        duplicate_extras = len(numeric) - len(set(numeric))
        feature_groups = {}
        for row, y in zip(numeric, labels):
            feature_groups.setdefault(row, set()).add(y)
        contradictory_groups = sum(len(ys) > 1 for ys in feature_groups.values())
        output = dict(dataset=key, uci_page=spec["page"], dataset_doi=spec["doi"],
                      source_archive_sha256=info["sha256"], source_member=spec["member"],
                      source_member_sha256=sha(raw), arithmetic="exact rational",
                      label_map=spec["label_map"], attributes=attrs,
                      stable_sample_ids="1..n in original file order; no shuffle; all rows retained",
                      source_identifiers=source_ids, source_identifiers_used_as_features=False,
                      removed_constant_features=[dict(source_feature=original_names[j], index_1based=j+1,
                                                       value=str(lo[j])) for j in constant],
                      preprocessing="min-max once on this finite reference universe; never refit after deletion",
                      scaling_parameters=scales, data=data)
        dest = prepared / (key + "_exact.json")
        dest.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
        summaries.append(dict(**spec, rows_observed=len(rows), features_before=spec["m"],
                              features_in_C=len(kept), removed_constant_features=output["removed_constant_features"],
                              excluded_identifiers=excluded_identifiers,
                              source_label_counts=dict(Counter(source_labels)),
                              binary_label_counts=dict(Counter(labels)),
                              missing_values=0, duplicate_feature_rows_beyond_first=duplicate_extras,
                              feature_groups_with_conflicting_labels=contradictory_groups,
                              all_rows_retained=True, archive_sha256=info["sha256"],
                              member_sha256=sha(raw), prepared_file=str(dest.relative_to(ROOT)),
                              prepared_sha256=sha(dest.read_bytes()),
                              license="CC BY 4.0 as stated on official UCI dataset page"))
    result = dict(date="2026-09-27", scope="data provenance and preprocessing only; no reduction experiments run",
                  datasets=summaries)
    (ROOT / "31_数据清单与核查结果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    for d in summaries:
        print(d["key"], d["rows_observed"], d["features_before"], d["features_in_C"],
              d["source_label_counts"], "constant", d["removed_constant_features"],
              "duplicate_extra_rows", d["duplicate_feature_rows_beyond_first"])


if __name__ == "__main__":
    main()
