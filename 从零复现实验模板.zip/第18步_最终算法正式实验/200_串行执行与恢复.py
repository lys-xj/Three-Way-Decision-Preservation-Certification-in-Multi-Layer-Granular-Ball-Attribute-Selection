"""Sequential predeclared runs; resume only completed verified job identities."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,sys,time,hashlib,os
OUT=Path(__file__).resolve().parent
PY=sys.executable
DATA=['banknote','climate','ionosphere','sonar','wbc','wdbc','haberman','blood']
METHODS=['F0','L','TC']
ledger_path=OUT/'203_执行台账.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(x):
 temp=ledger_path.with_suffix('.tmp');temp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,ledger_path)

def main():
 lock=sha(OUT/'202_正式实验冻结清单.json')
 ledger=json.loads(ledger_path.read_text(encoding='utf-8')) if ledger_path.exists() else dict(lock_sha256=lock,started_utc=datetime.now(timezone.utc).isoformat(),jobs={},active=None,completed=False)
 assert ledger['lock_sha256']==lock
 def run(key,method,setting,phase,rep=0):
  name=f'{key}_{setting}_{method}_{phase}_{rep}'
  if name in ledger['jobs']:return ledger['jobs'][name]['status']
  target=OUT/('独立核验' if phase=='audit' else '原始结果')/(name+'.json')
  log=OUT/'运行日志'/(name+'.log')
  budget=1800 if phase=='audit' else 600
  ledger['active']=dict(name=name,budget_seconds=budget,started_utc=datetime.now(timezone.utc).isoformat());save(ledger)
  print(json.dumps(dict(start=name,budget_seconds=budget)),flush=True)
  start=time.perf_counter()
  cmd=[PY,str(OUT/'199_单次正式实验.py'),'--dataset',key,'--method',method,'--setting',setting,'--phase',phase,'--output',str(target)]
  env=dict(os.environ,PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
  if target.exists():raise RuntimeError('Unledgered existing output '+str(target))
  with log.open('w',encoding='utf-8') as f:
   try:
    done=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=budget,env=env)
    status='complete' if done.returncode==0 and target.exists() else 'error'
   except subprocess.TimeoutExpired:status='timeout'
  row=dict(status=status,wall_process_seconds=time.perf_counter()-start,budget_seconds=budget,dataset=key,method=method,setting=setting,phase=phase,repeat=rep,log=str(log.relative_to(OUT)))
  if status=='complete':
   result=json.loads(target.read_text(encoding='utf-8'));row.update(output=str(target.relative_to(OUT)),sha256=sha(target),fingerprint=result['output_fingerprint'])
  ledger['jobs'][name]=row;ledger['active']=None;save(ledger)
  print(json.dumps(dict(finished=name,status=status,seconds=round(row['wall_process_seconds'],2))),flush=True)
  if status=='error':raise RuntimeError('Experiment error; inspect '+str(log))
  return status
 for key in DATA:
  run(key,'TC','main','audit')
  disabled=set()
  for method in METHODS:
   if run(key,method,'main','warmup')=='timeout':disabled.add(method)
  for rep in range(1,6):
   offset=(rep-1)%3
   for method in METHODS[offset:]+METHODS[:offset]:
    if method in disabled:continue
    if run(key,method,'main','timing',rep)=='timeout':disabled.add(method)
 for key in ['climate','sonar','wdbc','haberman']:
  for setting in ['narrow','wide','deep']:
   for method in METHODS:run(key,method,setting,'sensitivity')
 for key in ['synthetic_D','synthetic_unsafe','synthetic_R','synthetic_A']:
  run(key,'TC','deep','audit')
  for method in METHODS:run(key,method,'deep','mechanism')
 ledger['completed']=True;ledger['finished_utc']=datetime.now(timezone.utc).isoformat();save(ledger)
 print('ALL PREDECLARED JOBS FINISHED',flush=True)
if __name__=='__main__':main()
