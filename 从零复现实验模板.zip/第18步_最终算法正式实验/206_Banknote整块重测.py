"""One explicitly documented replacement block; retain original measurements."""
from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, hashlib, time, os, sys
P=Path(__file__).resolve().parent
ledger_path=P/'207_Banknote补充执行台账.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert json.loads((P/'203_执行台账.json').read_text(encoding='utf-8'))['completed'], 'Complete the primary serial run first'
    ledger=json.loads(ledger_path.read_text(encoding='utf-8')) if ledger_path.exists() else dict(jobs={}, protocol_addendum_sha256=sha(P/'205_中断恢复与计时补充说明.md'), completed=False)
    def save():
        temp=ledger_path.with_suffix('.tmp');temp.write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,ledger_path)
    disabled=set()
    def run(method,phase,rep):
        name=f'banknote_main_{method}_{phase}_{rep}'
        if name in ledger['jobs']:return ledger['jobs'][name]['status']
        output=P/'原始结果'/(name+'.json');log=P/'运行日志'/(name+'.log')
        assert not output.exists(), 'Unledgered output must be checked'
        ledger['active']=name;save();print('START '+name,flush=True)
        start=time.perf_counter()
        cmd=[sys.executable,str(P/'199_单次正式实验.py'),'--dataset','banknote','--method',method,'--setting','main','--phase',phase,'--output',str(output)]
        env=dict(os.environ,PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
        with log.open('w',encoding='utf-8') as f:
            try:
                done=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=600,env=env)
                status='complete' if done.returncode==0 and output.exists() else 'error'
            except subprocess.TimeoutExpired:status='timeout'
        row=dict(status=status,dataset='banknote',method=method,phase=phase,setting='main',repeat=rep,wall_process_seconds=time.perf_counter()-start,budget_seconds=600,log=str(log.relative_to(P)))
        if status=='complete':
            r=json.loads(output.read_text(encoding='utf-8'));row.update(output=str(output.relative_to(P)),sha256=sha(output),fingerprint=r['output_fingerprint'])
        ledger['jobs'][name]=row;ledger['active']=None;save();print('FINISHED '+name+' '+status,flush=True)
        if status=='error':raise RuntimeError(log)
        return status
    methods=['F0','L','TC']
    for m in methods:
        if run(m,'warmup_recovery',0)=='timeout':disabled.add(m)
    for rep in range(1,6):
        offset=(rep-1)%3
        for m in methods[offset:]+methods[:offset]:
            if m not in disabled and run(m,'timing_recovery',rep)=='timeout':disabled.add(m)
    ledger['completed']=True;ledger['finished_utc']=datetime.now(timezone.utc).isoformat();save()
if __name__=='__main__':main()
