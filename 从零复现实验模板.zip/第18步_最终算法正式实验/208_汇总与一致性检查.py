"""Validate all complete raw files and summarize without selecting favorable runs."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
from statistics import median,quantiles
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('summary18driver',P/'198_统一实验驱动.py')
M=importlib.util.module_from_spec(s);s.loader.exec_module(M)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stats(values):
    if not values:return None
    q=quantiles(values,n=4,method='inclusive') if len(values)>1 else values*3
    return dict(n=len(values),median=median(values),q1=q[0],q3=q[2],minimum=min(values),maximum=max(values),values=values)
TIMEFIELDS=['decision_only_seconds','decision_only_cpu_seconds','materialize_geometry_seconds','materialize_geometry_cpu_seconds','total_geometry_seconds','total_geometry_cpu_seconds','certificate_seconds','certificate_failure_seconds']
def summarize_group(runs):
    if not runs:return None
    first=runs[0]
    for r in runs:
        assert r['output_fingerprint']==first['output_fingerprint']
        assert r['metrics']==first['metrics'],('Nondeterministic counters',r['dataset'],r['method'])
    return dict(repeats=len(runs),times={k:stats([r[k] for r in runs]) for k in TIMEFIELDS},
      final_attributes=first['final_attributes'],candidate_count=first['candidate_count'],metrics=first['metrics'],
      fingerprint=first['output_fingerprint'],certificate_reasons=first['certificate_reasons'],pass_decisions=first['pass_decisions'],
      initial_diagnostics=first['initial_diagnostics'],stop_reason=first['stop_reason'])
def main():
    token=M.verify_lock()
    base=json.loads((P/'203_执行台账.json').read_text(encoding='utf-8'))
    recovery=json.loads((P/'207_Banknote补充执行台账.json').read_text(encoding='utf-8'))
    assert base['completed'] and recovery['completed'],'Finish both blocks first'
    records={};jobs={**base['jobs'],**recovery['jobs']}
    for name,j in jobs.items():
        if j['status']!='complete':continue
        p=P/j['output'];assert sha(p)==j['sha256'],name
        r=json.loads(p.read_text(encoding='utf-8'))
        assert r['completed'] and r['lock_sha256']==token
        assert r['output_fingerprint']==j['fingerprint']==M.fingerprint(r)
        for k in ['dataset','method','setting','phase']:assert r[k]==j[k],(name,k)
        assert len(r['attempts'])==len(r['candidate_decision_hashes'])==r['candidate_count']
        assert r['baseline_hash']==r['final_decisions_hash']
        records[name]=r
    groups=defaultdict(list)
    for name,r in records.items():groups[(r['dataset'],r['setting'])].append((name,r))
    consistency=[]
    for key,items in groups.items():
        assert len({r['output_fingerprint'] for name,r in items})==1,('Output mismatch',key)
        consistency.append(dict(dataset=key[0],setting=key[1],complete_files=len(items),methods=sorted({r['method'] for name,r in items}),same_outputs=True))
    datasets=json.loads((P/'197_公共数据清单.json').read_text(encoding='utf-8'))['datasets']
    mainrows=[]
    for d in datasets:
        key=d['key'];phase='timing_recovery' if key=='banknote' else 'timing'
        bymethod={m:summarize_group([r for name,r in records.items() if r['dataset']==key and r['method']==m and r['setting']=='main' and r['phase']==phase]) for m in ['F0','L','TC']}
        audit=records.get(f'{key}_main_TC_audit_0')
        passes=audit['independently_audited_passes'] if audit else []
        if audit:
            assert len(passes)==audit['metrics']['certificate_passes'],('Unaudited PASS',key)
            assert audit['independent_checks']==audit['candidate_count']+2,key
        ratios={}
        for field in ['decision_only_seconds','decision_only_cpu_seconds','total_geometry_seconds','total_geometry_cpu_seconds']:
            ratios[field]={baseline:(bymethod['TC']['times'][field]['median']/bymethod[baseline]['times'][field]['median'] if bymethod['TC'] and bymethod[baseline] else None) for baseline in ['F0','L']}
        mainrows.append(dict(**d,methods=bymethod,tc_to_baseline_ratio=ratios,
          independent_audit_complete=audit is not None,independent_checks=audit['independent_checks'] if audit else None,
          passes=passes,pass_count=len(passes),passes_with_actual_moves=sum(bool(r['actual_ever_movers']) for r in passes),
          skipped_rounds_in_audited_passes=sum(r['skipped_rounds'] for r in passes)))
    sensitivity=[];mechanism=[]
    # Preserve every predeclared row even if all three methods time out.
    for key in ['climate','sonar','wdbc','haberman']:
        for setting in ['narrow','wide','deep']:
            items=groups.get((key,setting),[])
            runs={r['method']:r for name,r in items if r['phase']=='sensitivity'}
            sensitivity.append(dict(dataset=key,setting=setting,runs=runs))
    for key in ['synthetic_D','synthetic_unsafe','synthetic_R','synthetic_A']:
        setting='deep';items=groups.get((key,setting),[])
        runs={r['method']:r for name,r in items if r['phase']=='mechanism'}
        audits=[r for name,r in items if r['phase']=='audit']
        mechanism.append(dict(dataset=key,setting=setting,runs=runs,audit=audits[0] if audits else None))
    exceptional=[dict(name=n,**j) for n,j in jobs.items() if j['status']!='complete']
    planned=[]
    for d in datasets:
        key=d['key'];planned.append(f'{key}_main_TC_audit_0')
        for m in ['F0','L','TC']:
            planned.append(f'{key}_main_{m}_warmup_0')
            planned.extend(f'{key}_main_{m}_timing_{i}' for i in range(1,6))
    for key in ['climate','sonar','wdbc','haberman']:
        for setting in ['narrow','wide','deep']:
            planned.extend(f'{key}_{setting}_{m}_sensitivity_0' for m in ['F0','L','TC'])
    for key in ['synthetic_D','synthetic_unsafe','synthetic_R','synthetic_A']:
        planned.append(f'{key}_deep_TC_audit_0')
        planned.extend(f'{key}_deep_{m}_mechanism_0' for m in ['F0','L','TC'])
    base_planned_count=len(planned)
    for m in ['F0','L','TC']:
        planned.append(f'banknote_main_{m}_warmup_recovery_0')
        planned.extend(f'banknote_main_{m}_timing_recovery_{i}' for i in range(1,6))
    omitted=[n for n in planned if n not in jobs]
    # Only the predeclared timeout stop rule may omit a later timing repeat.
    for name in omitted:
        assert '_timing_' in name,name
        prefix=name.split('_timing_',1)[0]
        phases=['warmup_recovery','timing_recovery'] if '_recovery_' in name else ['warmup','timing']
        assert any(n.startswith(prefix+'_') and j['status']=='timeout' and j['phase'] in phases for n,j in jobs.items()),name
    old_banknote={m:summarize_group([r for n,r in records.items() if r['dataset']=='banknote' and r['phase']=='timing' and r['method']==m]) for m in ['F0','L','TC']}
    reference=[r for r in records.values() if r['audit_only']]
    environment=next(iter(records.values()))
    timing_flags=[]
    for name,r in records.items():
        if r['phase'] in ['timing','timing_recovery']:
            cpu=r['decision_only_cpu_seconds'];wall=r['decision_only_seconds']
            if cpu>=1 and wall/cpu>1.2:
                timing_flags.append(dict(job=name,wall=wall,cpu=cpu,wall_to_cpu=wall/cpu,original_anomalous_banknote_block=r['dataset']=='banknote' and r['phase']=='timing'))
    result=dict(created_utc=datetime.now(timezone.utc).isoformat(),lock_sha256=token,frozen_algorithm_files_checked=len(M.FROZEN['files']),
      base_planned_jobs=base_planned_count,total_planned_jobs=len(planned),base_attempted_jobs=len(base['jobs']),recovery_attempted_jobs=len(recovery['jobs']),
      complete_files=len(records),job_status_counts=dict(Counter(j['status'] for j in jobs.values())),omitted_by_timeout_rule=omitted,
      exceptions=exceptional,comparison_groups=consistency,completed_independent_audits=len(reference),
      total_independent_checks=sum(r['independent_checks'] for r in reference),
      total_independent_candidate_checks=sum(r['candidate_count'] for r in reference),
      observed_mismatches=0,main=mainrows,sensitivity=sensitivity,mechanism=mechanism,
      timing_quality_flags=timing_flags,timing_quality_flag_rule='Descriptive only, not an exclusion rule: CPU >=1 second and wall/CPU >1.2',
      original_banknote_timing_block=old_banknote,python=environment['python'],platform=environment['platform'],
      cpu_affinity_records=[json.loads(x) for x in sorted({json.dumps(r['cpu_affinity'],ensure_ascii=False) for r in records.values()})],
      raw_files_sha256={j['output']:j['sha256'] for j in jobs.values() if j['status']=='complete'})
    (P/'209_正式实验汇总.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['base_planned_jobs','base_attempted_jobs','recovery_attempted_jobs','complete_files','job_status_counts','omitted_by_timeout_rule','completed_independent_audits','total_independent_candidate_checks','observed_mismatches']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
