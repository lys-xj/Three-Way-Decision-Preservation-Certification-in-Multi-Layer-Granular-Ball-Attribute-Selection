from pathlib import Path
import html,re,json
P=Path(__file__).resolve().parent
def inline(s):
    s=html.escape(s)
    s=re.sub(r'!\[([^\]]*)\]\(([^)]+)\)',r'<figure><a href="\2"><img src="\2" alt="\1"></a></figure>',s)
    s=re.sub(r'(?<!!)\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)
    s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
    return s
def convert(text):
    lines=text.splitlines();out=[];nav=[];i=0;section=0
    while i<len(lines):
        line=lines[i]
        if not line.strip():i+=1;continue
        if line.startswith('#'):
            n=len(line)-len(line.lstrip('#'));title=line[n:].strip();section+=1
            out.append(f'<h{n} id="section{section}">{inline(title)}</h{n}>')
            if n==2:nav.append(f'<a href="#section{section}">{inline(title)}</a>')
            i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                rows.append([v.strip() for v in lines[i].strip('|').split('|')]);i+=1
            out.append('<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+inline(v)+'</th>' for v in rows[0])+'</tr></thead><tbody>')
            for row in rows[2:]:out.append('<tr>'+''.join('<td>'+inline(v)+'</td>' for v in row)+'</tr>')
            out.append('</tbody></table></div>');continue
        if line.startswith('- '):
            out.append('<ul>')
            while i<len(lines) and lines[i].startswith('- '):out.append('<li>'+inline(lines[i][2:])+'</li>');i+=1
            out.append('</ul>');continue
        para=[line];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','- ')):
            para.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(para))+'</p>')
    return '\n'.join(out),'\n'.join(nav)
def main():
    content,nav=convert((P/'211_最终算法正式实验完整报告.md').read_text(encoding='utf-8'))
    page='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>最终算法正式实验报告</title>
<style>:root{--font:18px}*{box-sizing:border-box}body{margin:0;color:#183347;background:#eef3f7;font:var(--font)/1.85 "Microsoft YaHei",sans-serif}header{position:sticky;top:0;z-index:2;background:#133e56;color:white;padding:13px 28px;display:flex;align-items:center;gap:15px}header b{margin-right:auto}button{font-size:17px;background:white;color:#163c52;border:0;border-radius:5px;padding:7px 14px;cursor:pointer}main{max-width:1250px;margin:26px auto 70px;padding:25px 38px 50px;background:white;border-radius:12px}h1{font-size:2em;line-height:1.5}h2{margin-top:60px;padding-top:18px;border-top:2px solid #bcd4e2;scroll-margin-top:90px;font-size:1.45em}p{margin:18px 0}strong{color:#8a431a}nav{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:8px;padding:18px;background:#f1f7fa;border-radius:8px}a{color:#126993;text-decoration:none}a:hover{text-decoration:underline}.table-wrap{overflow:auto;margin:25px 0;border:1px solid #cad9e3;border-radius:7px}table{width:100%;border-collapse:collapse;font-size:.85em;line-height:1.7}th{background:#dfebf2;text-align:left;white-space:nowrap}td,th{padding:11px 14px;border-bottom:1px solid #d7e2e9;vertical-align:top}tr:nth-child(even){background:#f6f9fb}td{min-width:65px}figure{margin:24px 0}img{max-width:100%;height:auto;border:1px solid #dde5eb}code{font-family:Consolas,monospace;background:#eef3f6}.hint{padding:15px 18px;background:#fff4df;border-left:5px solid #c88a29}@media(max-width:700px){main{margin:0;padding:20px}header{padding:10px}h1{font-size:1.5em}}@media print{header,nav{display:none}main{max-width:none;padding:0}body{background:white;font-size:10pt}h2{margin-top:24px}table{table-layout:fixed;font-size:7pt;overflow-wrap:anywhere}.table-wrap{overflow:visible}td,th{min-width:0;padding:4px}th{white-space:normal}}</style></head><body>
<header><b>正式实验 · 完整结果与证据</b><button onclick="resize(-1)">字号 −</button><button onclick="resize(1)">字号 ＋</button><button onclick="window.print()">打印 / 保存</button></header>
<main><p class="hint">先看第5节的主表，再看第6节：少做迭代，是否真的省了总时间？所有完整、超时及不利结果均保留。表格较宽时可横向滚动。</p><nav>'''+nav+'</nav>'+content+'''<h2>机制图</h2><figure><a href="图表/正式实验_成员移动与省略轮次.png"><img src="图表/正式实验_成员移动与省略轮次.png" alt="独立核验的成员移动与省略轮次"></a></figure></main><script>let size=18;function resize(d){size=Math.max(14,Math.min(30,size+d));document.documentElement.style.setProperty('--font',size+'px')}</script></body></html>'''
    (P/'打开阅读_正式实验报告.html').write_text(page,encoding='utf-8')
    print('Wrote reading page')
if __name__=='__main__':main()
