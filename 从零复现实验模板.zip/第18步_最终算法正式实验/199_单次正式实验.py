from pathlib import Path
from datetime import datetime,timezone
import argparse,importlib.util,json,sys,os,platform,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('formal18_driver',OUT/'198_统一实验驱动.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)

def main():
 p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--method',choices=['F0','L','TC'],required=True)
 p.add_argument('--setting',default='main');p.add_argument('--phase',required=True);p.add_argument('--output',required=True)
 a=p.parse_args();out=Path(a.output)
 if out.exists():raise RuntimeError('Output already exists')
 token=M.verify_lock();affinity=None
 try:
  import psutil
  proc=psutil.Process();allowed=proc.cpu_affinity();chosen=allowed[min(2,len(allowed)-1)]
  proc.cpu_affinity([chosen]);affinity=proc.cpu_affinity()
 except Exception as e:affinity={'unsupported':str(e)}
 data,attrs=M.dataset(a.dataset)
 def progress(x):print(json.dumps(dict(dataset=a.dataset,phase=a.phase,**x)),flush=True)
 r=M.execute(a.method,data,attrs,a.setting,a.phase=='audit',progress)
 r.update(dataset=a.dataset,phase=a.phase,finished_utc=datetime.now(timezone.utc).isoformat(),
  lock_sha256=token,cpu_affinity=affinity,python=sys.version,platform=platform.platform())
 out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf-8') as f:json.dump(M.API.encode(r),f,ensure_ascii=False,indent=2)
 print(json.dumps(dict(dataset=a.dataset,method=a.method,phase=a.phase,setting=a.setting,
  seconds=round(r['decision_only_seconds'],3),cpu_seconds=round(r['decision_only_cpu_seconds'],3),
  candidates=r['candidate_count'],attributes=len(r['final_attributes']),passes=r['metrics']['certificate_passes'],complete=True)),flush=True)
if __name__=='__main__':main()
