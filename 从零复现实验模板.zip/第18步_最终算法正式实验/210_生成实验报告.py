"""Generate readable research reports and scientific figures from verified data."""
from pathlib import Path
from statistics import median
from collections import Counter
import json, math, sys, platform, os
P=Path(__file__).resolve().parent
NAMES={'banknote':'Banknote','climate':'Climate','ionosphere':'Ionosphere','sonar':'Sonar','wbc':'WBC','wdbc':'WDBC','haberman':'Haberman','blood':'Blood'}
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(map(str,row))+' |' for row in rows])+'\n'
def write(name,text): (P/name).write_text(text,encoding='utf-8')
def fmt(x,d=3):return '未完成' if x is None else f'{x:.{d}f}'
def timecell(m,field='decision_only_seconds'):
    if not m:return '未完成'
    s=m['times'][field];return f"{s['median']:.3f} [{s['q1']:.3f}, {s['q3']:.3f}]；范围{s['minimum']:.3f}–{s['maximum']:.3f}；n={s['n']}"
def main():
    R=json.loads((P/'209_正式实验汇总.json').read_text(encoding='utf-8'))
    D=R['main'];complete=[d for d in D if all(m and m['repeats']==5 for m in d['methods'].values())]
    matched=[d for d in D if all(d['methods'][m] and d['methods'][m]['repeats']==5 for m in ['L','TC'])]
    audits=[d for d in D if d['independent_audit_complete']]
    passes=sum(d['pass_count'] for d in D);movers=sum(d['passes_with_actual_moves'] for d in D)
    attempts_total=sum(d['methods']['TC']['metrics']['certificate_attempts'] for d in D if d['methods']['TC'])
    closure_calls=sum(d['methods']['TC']['metrics']['certificate_attempts']-d['methods']['TC']['metrics']['closure_failed_reference'] for d in D if d['methods']['TC'])
    cand=sum(d['methods']['TC']['candidate_count'] for d in matched)
    speedwins=sum(d['tc_to_baseline_ratio']['decision_only_seconds']['L']<1 for d in matched)
    cpuwins=sum(d['tc_to_baseline_ratio']['decision_only_cpu_seconds']['L']<1 for d in matched)
    pass_types=dict(Counter(p['decision'] for d in D for p in d['passes']))
    net_conclusion=('本轮没有显示新增证书带来的整体时间优势，现阶段不宜把论文定位成普遍加速方法。可以保留并研究的是：在明确前提下，成员实际移动仍可安全提前认证。' if matched and speedwins==0 else '净时间收益以主表逐数据结果为准；局部省轮数不足以推出普遍加速。')
    banknote=next(d for d in D if d['key']=='banknote')
    bank_ratio=banknote['tc_to_baseline_ratio']['decision_only_seconds']['L']
    english_timing_note=''
    if len(matched)==8 and speedwins==1 and bank_ratio is not None and bank_ratio<1 and banknote['pass_count']==0:
        net_conclusion=f'主比较中7套数据的TC更慢；Banknote的TC墙钟中位数仅快{(1-bank_ratio)*100:.2f}%，两方法的重复时间范围重叠，而且该数据没有成功认证、没有省略迭代。这点微小差异不能作为新增证书的加速证据。本轮支持具体节点上的安全提前认证，尚未显示有说服力的整体时间收益。'
        english_timing_note=f'The only lower wall-time median was Banknote ({(1-bank_ratio)*100:.2f}% lower), with overlapping repeat ranges, zero successful certificates, and no iteration savings. This small difference is not evidence of certificate-driven acceleration.'
    posthoc='追加机制核验尚未执行，不能据参数检查输出声称已独立回放了非R认证。'
    english_posthoc=''
    posthoc_path=P/'228_追加核验台账.json'
    if posthoc_path.exists():
        post=json.loads(posthoc_path.read_text(encoding='utf-8'))
        if post['completed']:
            jobs=list(post['jobs'].values());done=[x for x in jobs if x['status']=='complete']
            kinds=Counter(p['decision'] for x in done for p in x['audited_passes'])
            moving_kinds=Counter(p['decision'] for x in done for p in x['audited_passes'] if p['actual_ever_movers'])
            accepted_moving=0
            for job in done:
                raw=json.loads((P/job['output']).read_text(encoding='utf-8'))
                accepted_moving+=sum(bool(p['actual_ever_movers']) and raw['attempts'][p['candidate_index']-1]['accepted'] for p in job['audited_passes'])
            posthoc=f'在观察参数结果后，按226号方案对所有出现A或D认证的设置追加独立回放，共{len(jobs)}组，完成{len(done)}组。审核的PASS类型为{dict(kinds)}，其中确有后续换组的类型为{dict(moving_kinds)}。详见[229号追加核验报告](229_非拒绝认证追加核验报告.md)。这是事后探索性机制检查，未并入8套主实验、222份预设及补充计时输出或重复性能统计；不能把它描述为预先注册的独立泛化证据。'
            posthoc+=f'实际换组且其所属候选整体被接受的节点数为{accepted_moving}，因此这些局部认证也不能直接解释为成功删除了对应属性。'
            english_posthoc=f'Exploratory post-hoc replay audited all {len(jobs)} sensitivity settings containing any non-rejection certificate. Actual later membership changes occurred in {dict(moving_kinds)} certified node events; {accepted_moving} of these belonged to globally accepted candidates. These local mechanism observations are reported separately from the prespecified main experiment and do not establish general performance or successful global deletion for each local PASS.'
    datasettable=table(['数据','原始/实验人数','属性数','正类数','用途','来源与引用'],[
      [NAMES[d['key']],('699 / 683' if d['key']=='wbc' else str(d['n'])),d['d'],d['positive'],'开发时已用' if d['role']=='development_data' else '新增基准',f"[UCI]({d['uci_page']})；{d['dataset_doi']}"] for d in D])
    main_table=table(['数据','保留属性/原属性','候选数','F0秒','L秒','TC秒','TC/L','独立核验'],[
      [NAMES[d['key']],(f"{len(d['methods']['TC']['final_attributes'])}/{d['d']}" if d['methods']['TC'] else '未完成'),d['methods']['TC']['candidate_count'] if d['methods']['TC'] else '—',
       *[fmt(d['methods'][m]['times']['decision_only_seconds']['median']) if d['methods'][m] else '未完成' for m in ['F0','L','TC']],
       fmt(d['tc_to_baseline_ratio']['decision_only_seconds']['L']), '完成、零不一致' if d['independent_audit_complete'] else '未完成'] for d in D])
    paper_table=table(['Dataset','N / d','Selected','Candidates','PASS / calls','F0 (s)','L (s)','TC (s)'],[
      [NAMES[d['key']],f"{d['n']} / {d['d']}",len(d['methods']['TC']['final_attributes']) if d['methods']['TC'] else 'Incomplete',
       d['methods']['TC']['candidate_count'] if d['methods']['TC'] else '—',
       f"{d['methods']['TC']['metrics']['certificate_passes']} / {d['methods']['TC']['metrics']['certificate_attempts']}" if d['methods']['TC'] else '—',
       *[fmt(d['methods'][m]['times']['decision_only_seconds']['median']) if d['methods'][m] else 'Incomplete' for m in ['F0','L','TC']]] for d in D])
    repeat_table=table(['数据','方法','墙钟秒：中位数 [Q1,Q3]','CPU秒：中位数 [Q1,Q3]','含最终几何的墙钟秒'],[
      [NAMES[d['key']],m,timecell(d['methods'][m]),timecell(d['methods'][m],'decision_only_cpu_seconds'),timecell(d['methods'][m],'total_geometry_seconds')] for d in D for m in ['F0','L','TC']])
    mechanisms=table(['数据','尝试/PASS','PASS中确有换组','省略后续轮数','L→TC实际Lloyd轮数','认证耗时秒','失败认证耗时秒'],[
      [NAMES[d['key']],f"{d['methods']['TC']['metrics']['certificate_attempts']}/{d['methods']['TC']['metrics']['certificate_passes']}" if d['methods']['TC'] else '—',
       d['passes_with_actual_moves'] if d['independent_audit_complete'] else '未审核',d['skipped_rounds_in_audited_passes'] if d['independent_audit_complete'] else '未审核',
       f"{d['methods']['L']['metrics']['lloyd_rounds']} → {d['methods']['TC']['metrics']['lloyd_rounds']}" if d['methods']['L'] and d['methods']['TC'] else '—',
       fmt(d['methods']['TC']['times']['certificate_seconds']['median']) if d['methods']['TC'] else '—',
       fmt(d['methods']['TC']['times']['certificate_failure_seconds']['median']) if d['methods']['TC'] else '—'] for d in D])
    pass_rows=[]
    for d in D:
        for r in d['passes']:
            pass_rows.append([NAMES[d['key']],r['candidate_index'],r['path'],r['member_count'],r['decision'],r['optional_count'],len(r['actual_ever_movers']),len(r['actual_final_movers']),r['skipped_rounds'],str(r['bounds'])])
    pass_table=table(['数据','候选序号','节点','人数','决定','可变名单人数','实际曾换组','最终换组','省略轮数','两子组正类比例界'],pass_rows) if pass_rows else '没有取得完整审核的PASS节点。\n'
    reason_table=table(['数据','认证结果及次数'],[[NAMES[d['key']],str(d['methods']['TC']['certificate_reasons']) if d['methods']['TC'] else '未完成'] for d in D])
    sensitive=[]
    for x in R['sensitivity']:
        tc=x['runs'].get('TC');l=x['runs'].get('L');f=x['runs'].get('F0')
        sensitive.append([NAMES[x['dataset']],x['setting'],len(tc['final_attributes']) if tc else '未完成',tc['candidate_count'] if tc else '—',
          f"{tc['metrics']['certificate_passes']}/{tc['metrics']['certificate_attempts']}" if tc else '—',
          fmt(f['decision_only_seconds']) if f else '未完成',fmt(l['decision_only_seconds']) if l else '未完成',fmt(tc['decision_only_seconds']) if tc else '未完成',
          '三者完整且一致' if len(x['runs'])==3 else '仅比较已完成项'])
    sens_table=table(['数据','设置','保留属性','候选数','PASS/尝试','F0秒','L秒','TC秒','结果比较'],sensitive)
    synthetic=[]
    for x in R['mechanism']:
        tc=x['runs'].get('TC');a=x['audit'];pr=a['independently_audited_passes'] if a else []
        synthetic.append([x['dataset'],tc['candidate_count'] if tc else '—',len(tc['final_attributes']) if tc else '—',tc['pass_decisions'] if tc else '—',
          sum(bool(p['actual_ever_movers']) for p in pr),sum(p['skipped_rounds'] for p in pr),'完成' if a else '未完成'])
    syn_table=table(['构造例','候选数','保留属性','PASS决定','PASS中确有换组','省略轮数','独立审核'],synthetic)
    diagrows=[]
    for d in D:
        tc=d['methods']['TC']
        if tc:
            for h,v in tc['initial_diagnostics']['levels'].items():
                q=v['decision_counts'];diagrows.append([NAMES[d['key']],h,v['ball_count'],q['A'],q['D'],q['R'],v['all_one_decision']])
    diagnostics=table(['数据','层','粒球数','接受A人数','暂缓D人数','拒绝R人数','全体同一决定'],diagrows)
    issue_table=table(['任务','状态','上限秒','日志'],[[j['name'],j['status'],j['budget_seconds'],j['log']] for j in R['exceptions']]) if R['exceptions'] else '没有错误或超时任务。'
    timing_flags=table(['原始任务','墙钟秒','CPU秒','比值','属于已单独保留的原Banknote块'],[[x['job'],fmt(x['wall']),fmt(x['cpu']),fmt(x['wall_to_cpu']),x['original_anomalous_banknote_block']] for x in R['timing_quality_flags']]) if R['timing_quality_flags'] else '未发现达到这项描述性提示条件的记录。'
    report=f'''# 最终算法正式实验：完整报告

本报告由209号汇总文件自动生成。算法版本：TailCert-L-IE-v0.4。原始结果、异常记录、数据来源及程序均保留。生成时间（UTC）：{R['created_utc']}。

## 先看实验真正回答了什么

我们检验的是：**在相同数据、相同粒球生成规则、相同删属性顺序下，加入新证书之后，能否少做部分重构，同时得到与完整重构完全相同的三支决定和属性集？**

可以把F0想成“每道题都从头算”，L想成“能够证明不变的旧步骤直接复用”，TC想成“在L基础上，再证明某些尚未算完的换组过程不会改变答案”。比较TC与L，才能知道新增证书究竟带来了什么。

- 预设主数据集8套，已取得三方法完整计时结果{len(complete)}套，完成独立逐候选审核{len(audits)}套。
- TC与L完整主比较包含{cand}个候选删除步骤；这里的候选数按数据集的单条搜索路径计数，不把重复计时当作新样本。
- 已完成的主实验独立审核记录{passes}个PASS节点，其中{movers}个在完整重构的后续迭代中确实发生过成员换组。
- 主实验PASS对应的决定类型为{pass_types}。这项分布必须披露，不能把一种决定下的成功写成三种决定均已在真实数据上取得成功。
- 主搜索路径累计调用证书{attempts_total}次，其中{closure_calls}次通过基准决定一致性筛选并进入包络过程。这里是节点调用次数，不是互相独立的随机试验，也不是唯一节点数。
- 以各自中位数比较，TC墙钟时间短于L的有{speedwins}/{len(matched)}套，CPU时间短于L的有{cpuwins}/{len(matched)}套。小幅差异不能当作显著优势。
- 所有已完成、可比较的输出记录发现的不一致为0。有限实验支持实现正确性，但不能替代一般性的数学证明。

**“能够提前证明结果不变”和“整体跑得更快”是两个分别需要证据的结论。省略若干迭代不必然抵消证书计算成本。**

{net_conclusion}

## 1. 参考了哪些论文，如何借鉴

Qian等（2017，DOI：10.1016/j.ijar.2017.03.009）采用UCI数据并检查约简、决定区域及分类等指标。Chen等（2025卷期，DOI：10.1016/j.ins.2024.121691）使用UCI/scikit-feature基准，比较约简、运行时间及分类效果。Sang等（2026，DOI：10.1016/j.fss.2026.110032）使用多数据集、多分类器、消融和噪声实验，且说明特征选择在训练折内完成。全文依据见第17步188号逐项核查报告。

我们借鉴公开基准、统一条件比较、消融及参数敏感性检查。WBC可衔接前两篇论文使用的乳腺癌数据类型；WDBC参考Sang的数据名称，但其表中规模与UCI标准版不一致，不声称复现了它的同一处理版本。

这些论文的约简目标与本工作的确定性粒球重构决定保持不同。因此本轮不把它们的运行秒数或分类准确率拿来直接比大小，也不声称优于这三篇方法。本轮主比较是共享生成器的F0/L/TC。

## 2. 数据从哪里来，怎样处理

{datasettable}

全部来自UCI官方公开仓储；上述数据页面标注CC BY 4.0，使用时保留来源、DOI与处理说明。原始ZIP及SHA-256校验值存档。前4套参与过开发，不叫“未见数据”；后4套是在最终算法锁定后加入的基准。正类只指程序中y=1，绝不统一解释成医学“患病”。

WBC去掉16条含缺失值的行，699变683；WBC/WDBC的ID不作属性。Climate的study/run两列不作属性；失败标签原0映射为1。Ionosphere移除一列常数，34变33。其他样本按原顺序保留，不去重，不截取有利子集。所有列在固定样本表上用精确有理数min-max缩放一次，之后删属性不重估缩放。

本任务比较同一有限表的决定是否保持，没有把这批对象当作未知测试集，因此不设训练/测试拆分，也不报告预测泛化准确率。如果以后讨论分类能力，必须另做训练折内预处理和选属性的交叉验证，不能把本报告的零决定差异当作100%分类准确率。

## 3. 三种方法，怎样保证公平

| 方法 | 做什么 | 用来检验什么 |
|---|---|---|
| F0 | 每个候选属性集从头完整构造粒球 | 完整重构的参照答案与成本 |
| L | 允许已证明精确不变的局部结构复用，关闭新证书 | 控制已有局部复用，隔离新增证书作用 |
| TC | 使用相同局部流程，加入冻结的成员变化证书 | 新证书是否安全，能否省轮次，净成本如何 |

F0、L、TC是三种计算办法；A、D、R是样本得到的三种决定，两组缩写表示的不是同一件事。

三者共享样本、确定性种子、距离、最多20轮、平局归组0、子组至少2人、属性删除顺序与停止规则。主设置为观察层{{1,2}}，alpha=0.7，beta=0.3；p≥alpha为A，p≤beta为R，其间为D。所有数值判断采用精确有理数，避免浮点误差改变平局。

方法初始树及复用历史的建立计入时间。读数据、写结果与独立核验不计入算法计时。最后若要求真实树和几何，还要付出额外物化成本，因此同时报告“仅决定/属性”和“含最终几何”两种口径。这里“仅决定/属性”仍包含整个约简搜索，不是只算最后一条决定。

## 4. 实验一：逐个候选对答案

每套数据单独运行一次TC审核。对每个候选属性集，另一个完整重构程序独立生成真实树与每个观察层的逐样本决定，逐项比较；末态再核对真实结构和几何。每次正式计时还保留候选决定摘要、接受/拒绝路径、最终属性与几何摘要。

预设任务及Banknote补充计时合计{R['complete_files']}份完整输出，{len(R['comparison_groups'])}组同输入比较；已完成独立审核{R['completed_independent_audits']}项，独立候选核验{R['total_independent_candidate_checks']}次（不含初始和末态附加检查），总独立检查{R['total_independent_checks']}次。发现不一致0。原敏感性方案只有单次三方法比较，其证据强度须与主实验独立逐候选审核区分；事后追加核验另见第7节。

执行前另用13个小例检查实验驱动与冻结求解入口一致，见核查记录201。已完成文件全部重新检查哈希，冻结算法{R['frozen_algorithm_files_checked']}个依赖文件未改变。核验的是当前有限输入与实现，不证明对任意输入一定正确；一般保证来自定理及其前提。

## 5. 实验二：完整搜索的时间与约简结果

各方法每数据预热1次，再以新进程串行重复5次，顺序循环轮换。下表是墙钟中位数，TC/L小于1表示TC更快，大于1表示更慢。

{main_table}

重复运行只估计本机时间波动，不等于新增独立数据集。不对5次重复作伪独立显著性检验，不把轻微快慢差异归因于算法。

最终保留属性数较少只能说明满足本论文特定决定保持约束，不能直接说明预测准确率更好；停止时是非空单属性集或按规定顺序单删除不可约，不是求得全局最小属性集。

![新增证书的净时间成本](图表/正式实验_TC相对L耗时.png)

读图方法：虚线1代表TC与L耗时一样；横条超过1表示TC更慢，短于1表示TC更快。蓝色为墙钟时间，橙色为处理器CPU时间。这里比较的是时间，不是分类准确率。

## 6. 实验三：省在哪里，成本花在哪里

{mechanisms}

认证尝试包括很快被前提筛掉的节点。“省略后续轮数”来自每个PASS对应的独立真实重构；不等于L与TC总轮次差一定完全相同，因为抽象节点会影响之后能否复用精确结构。要判断实际工作量，还须看整条搜索的Lloyd轮数和总时间。

尝试次数是实际执行搜索中调用证书的节点事件数；已经通过精确复用而跳过的节点不在这个分母内。同一节点在不同候选中被反复遇到会重复计数，PASS/尝试不是“所有可能属性子集上的成功概率”。

可以用记账方式理解：TC净变化 = 认证计算开销 + 因抽象状态影响后续复用的开销 − 被省略的真实迭代成本。认证失败也要付费，这些成本全部计入了主表。

{reason_table}

结果代码用简单的话解释：`reference_decisions_not_uniform`表示这个节点原本就有不同的三支决定，不能用本证书的“整个节点同一决定”条件；`no_envelope_with_two_core_members`表示可变名单扩大后，某组剩下不足2个可确保不动的核心成员，达不到本证书前提；`least_envelope_ratio_crosses_threshold`表示几何包络找到了，但可能的类别比例仍跨过决定阈值，不能断言决定一定不变。它们都是“证书不知道”，不是“删除一定错误”；程序随后继续真实重构。

各PASS的实际换组证据：

{pass_table}

“可变名单”是证书允许可能移动的样本集合；“实际曾换组”是独立重构后看到的真实过程，两者不能混称。样本可以在不同候选中多次出现，这里按节点事件计数，不能把人数简单累加成不重复对象总数。

**一个可以直接核对的真实例子。** Climate第17个候选、节点UR，剩余属性a18。节点270人，可变名单36人（正类4人、负类32人）；两组固定核心分别为135人/8个正类、99人/9个正类。按比例界公式，两组范围分别为[8/(135+32), (8+4)/(135+4)]=[8/167,12/139]和[9/(99+32),(9+4)/(99+4)]=[9/131,13/103]。两个上界约为0.0863和0.1262，都小于拒绝阈值0.3。因此在已经通过几何闭包检查的前提下，无论可变成员怎样在允许范围内移动，两组都还是R。独立真实重构确认后续确有36人换组，证书省略了7轮。这不是凭直觉认为“应该不变”，而是有数值界和真实轨迹对应的具体事件；它仍属于全体R的较简单情形。

**新增基准中的例子。** Blood主设置的第2层包含57个D和691个R。第4个候选的节点UR有633人，证书允许3个可变成员，独立重构确认这3人后续确实换组；两组比例界分别是[134/629,67/313]和[0,0]，均保持R，省略2轮迭代。不过该候选整体仍被拒绝，最终4个属性全部保留。局部PASS只证明这一节点的末层决定安全，其他节点或较浅层仍可能改变，不能把局部PASS写成“这个属性已经可以删除”。

## 7. 实验四：改变阈值或观察层

预先指定Climate、Sonar、WDBC、Haberman，分别测试narrow=(0.6,0.4)，wide=(0.8,0.2)，deep=层{{1,2,3}}且阈值(0.7,0.3)。narrow/wide指暂缓区间宽窄。每格只运行1次，用来检查输出一致和证书适用范围，不能支持稳定性能排序。

{sens_table}

参数实验的时间尤其需要谨慎解释：2026-09-28的原始记录中，WDBC-wide的F0与主设置F0第1次具有相同候选数79、搜索路径摘要、最终几何摘要和点距离调用次数，但CPU时间分别为369.094秒和97.281秒。原因未确定，不能归因于“阈值使候选数增多”。相关原始值保留，详见[224号运行解释补充](224_参数实验耗时解释补充.md)。这些单次时间不用于推断参数改变带来的因果性能影响；复现者应另据自己的运行记录解释时间，不能照抄原始秒数。

同一原始WDBC-wide比较中，L和TC都执行2493轮、1781703次点距离计算，TC的PASS为0，但L墙钟453.239秒、TC仅109.858秒。这个表面的约4.1倍差异没有证书省轮次作为依据，**不能写成新证书实现了4.1倍加速**。它说明单次顺序计时可能受到明显运行环境波动影响。

### 单独标明的事后机制核验

{posthoc}

## 8. 实验五：可控构造例

沿用已有140点反馈链、已有不安全反例，补充预先规定的稀少正类R及标签互换A版本。它们用于检查机制，不能混入8套真实数据求平均。构造例名字表示设计意图，实际取得何种PASS以表中结果为准。

{syn_table}

不安全例应通过回退到原重构保持正确；不能因为某处另有安全PASS就把整个例子误说成“认证了不安全变化”。逐候选接受/拒绝及节点认证原因在原始文件中保留。

## 9. 初始决定分布：防止把简单情况当作普遍效果

{diagnostics}

Climate主设置两层都是全体R，属于较简单的决定保持情形。其他数据若也有全体同一决定，须一并披露。三支决定不等于原标签，数据标签含两个类别也不保证A/D/R同时出现。不能靠保留属性少或单一决定下的PASS概括所有情形。

## 10. 异常、运行环境和完成范围

环境：{R['platform']}；{R['python']}；本机处理器读取为Intel Core i9-14900HX。使用单进程串行运行，但没有成功锁定CPU亲和性（psutil不可用，程序如实记录）；未控制处理器频率，不能宣称操作系统背景负载完全受控。

初始Banknote计时块出现墙钟时间与CPU时间严重失配，205号说明在补充运行前固定了处理办法：保留全部旧值，对三方法整块重新预热和各重复5次，主表统一使用新块，不按方法或单次挑选。原块与新块都在209号JSON及原始目录中。用户出行造成的Climate不完整审核前缀另外存档，恢复后从该项起完整重跑。

预设基本任务{R['base_planned_jobs']}项，实际尝试{R['base_attempted_jobs']}项，另补充Banknote {R['recovery_attempted_jobs']}项。状态：{R['job_status_counts']}。按超时规则省略的后续重复数：{len(R['omitted_by_timeout_rule'])}。

{issue_table}

所有超时任务不报告最终属性集，不以中途结果代替完整结果。详细任务名单及原始日志见203、207、209。

另列运行质量的描述性检查：对CPU时间至少1秒的记录，标出墙钟/CPU超过1.2的情况。这是汇总时增加的提示规则，不是删数据规则、显著性检验或因果判断；除了205号预先说明的整块Banknote重测，所有值继续原样保留。

{timing_flags}

## 11. 这些实验能够和不能够支撑什么

| 论文说法 | 对应证据 | 可以写到什么程度 |
|---|---|---|
| 当前实现保持完整参照决定 | 逐候选独立审核、完整输出比较 | 对已完成设置零不一致；一般结论另依赖定理 |
| 成员实际变化仍可提前认证 | PASS节点的完整真实轨迹 | 对实际观察到的节点成立；不是假定成员不变 |
| 新证书能减少某些后续迭代 | 每个PASS省略轮数 | 必须同时报告失败及认证成本 |
| 新证书普遍加速 | TC与匹配L的重复总耗时 | 只有数据支持时才可写，不能由省轮次直接推出 |
| 对参数变化同样可靠 | 预设敏感性结果 | 只覆盖列出的设置，不能宣称对所有阈值充分验证 |
| 比近邻特征选择方法预测更准 | 本轮未做这种任务的同协议对比 | 本轮不支持 |
| 适用于大规模数据、任意种子和随机粒球 | 本轮是小型基准、固定确定性生成器 | 本轮不支持 |

## 12. 全部重复时间与额外输出成本

中位数后方括号是第25%、75%分位数；n表示完成重复数。CPU时间反映处理器实际执行时间，墙钟时间包含等待或系统调度干扰，二者一起看。

{repeat_table}

完整逐次数据保存在209号JSON及原始结果文件中；主表没有丢弃最慢一次或取最好一次。

## 13. 一条待验证的改进线索

针对失败认证成本，另有[222号单点改进建议](222_实验后可考虑的单点改进_尚未实施.md)：利用比例区间随可变名单扩大只会变宽的关系，在闭包中提前识别无法通过比例条件的情况。这是尚未实施、尚未计时的方案，不属于本轮算法或已证实的实验收益。若采用，应建立新版本、验证输出等价，再重新比较净成本。
'''
    write('211_最终算法正式实验完整报告.md',report)
    # Draft paragraphs deliberately expose limitations instead of selling an acceleration claim.
    english=f'''# Four-page paper: experiment material to select from

This is an experimental subsection draft, not a claim that the full paper is ready for submission. Dataset citations and near-neighbor citations must remain in the final bibliography.

## Experimental setup

We evaluated the frozen TailCert-L-IE-v0.4 implementation on eight public UCI benchmarks. Banknote, Climate, Ionosphere, and Sonar were used during development; WBC, WDBC, Haberman, and Blood were added after implementation selection. We removed 16 incomplete WBC records and excluded identifiers and constant features. Each fixed universe was normalized once using exact rational min–max scaling. The task is preservation of decisions on this finite universe, rather than prediction on unseen samples.

F0 reconstructs every candidate hierarchy, L reuses only certified exact structures, and TC adds the proposed terminal-level membership certificate to the same local-reuse implementation. All methods share the deterministic generator, tie-breaking rules, deletion order, stopping rule, and observation levels. The main setting uses levels 1 and 2 with thresholds (alpha,beta)=(0.7,0.3). Each method received one warm-up and five separate-process runs in cyclic order. Reported times include initialization, unsuccessful certification, and the complete reduction search; final geometry materialization is reported separately in the supplement. CPU affinity was unavailable, and frequency and background load were not controlled; both wall and process CPU times are retained. Timing results describe this execution environment and do not establish universal performance.

## Verification and results

Independent reconstruction was completed for {len(audits)} of the eight main datasets. Across completed main comparisons, the three methods produced identical candidate decisions, acceptance paths, final feature sets, and materialized final geometry. No mismatch was observed. This validates tested executions and does not replace the correctness theorem.

The main audits recorded {passes} successful node certificates, of which {movers} involved actual membership changes in subsequent reference iterations. These observations support certification without requiring fixed memberships. However, certificate overhead must be included: TC had a lower median wall time than matched L on {speedwins} of {len(matched)} complete datasets (CPU time: {cpuwins} of {len(matched)}). Thus iteration savings alone do not establish a general speedup. The all-rejection reference decisions on Climate further limit the diversity of this evidence.

{english_timing_note}

The successful main-audit node decisions were {pass_types}. This distribution limits claims about coverage of the three decision regions on real data. A local PASS is not sufficient to accept an attribute deletion: all nodes and observation levels must preserve their reference decisions. In Blood, a safe local PASS occurred in a globally rejected candidate.

{english_posthoc}

## Main table (wall-time medians, seconds)

{paper_table}

N and d denote sample and input-feature counts. Selected is the final feature count; Candidates counts attempted deletions once per search path. PASS/calls counts node events, not distinct samples. Completion status and the number of repetitions must be carried over from the full report when formatting the final table. These are instrumented exact-rational Python research implementations, not optimized production implementations.

## What belongs in the four-page version

Use one compact main table containing size, final dimension, F0/L/TC time, and certificate PASS count; one small figure may show an actual-moving PASS and its bound. Keep one sentence reporting sensitivity and its limits. Put all repeated values, audit traces, preprocessing details, interruption records, and code hashes in an accompanying reproducibility package if the venue permits. Do not omit negative timing results to make room.

The remaining manuscript must state the assumptions, the feedback-closed certificate and its proof, and its relation to prior methods. Do not write “state of the art,” “universally faster,” or “improved classification accuracy” based on these experiments.
'''
    write('212_四页论文可用实验段落与主表.md',english)
    evidence=table(['实验','小学生式理解','对论文的支撑'],[
      ['独立正确性核验','省步骤之后，逐个检查答案有没有变','检查当前实现是否保持决定'],
      ['F0/L/TC消融','把新功能关掉，再打开，对照看差别','分开已有复用与新增证书的作用'],
      ['重复计时','同一办法完整跑5次，不能只拿最快那次','估计本机净成本及波动'],
      ['真实换组轨迹','允许同学换组，检查最后的三种决定是否仍一样','验证成员变化这一核心情形'],
      ['改变阈值和层数','换几套预先规定的判分规则','看结论的适用范围和限制'],
      ['构造例与不安全例','用知道发生什么的例子检验，再放入不该通过的例子','检查证书与回退机制']])
    write('213_先读这里_实验做了什么与得到什么.md',f'''# 先读这里：正式实验

正式实验使用8套公开数据；当前完整主比较{len(complete)}套、完整独立主核验{len(audits)}套。全部已完成比较发现决定不一致0；独立主核验发现{passes}个安全提前停止节点，其中{movers}个在后续真实重构中确有成员移动。

成功节点的决定类型统计为{pass_types}，其中R表示“拒绝”。真实数据上观察到了哪些类型，就只能据此说明哪些类型的成功；构造例要另外看，不能混在一起扩大结论。

**要分开看两件事：答案保持了没有，实际省时间了没有。** 当前TC比L墙钟中位数更短的有{speedwins}/{len(matched)}套，不能只凭“少做几轮”就写“算法普遍更快”。

{net_conclusion}

{evidence}

建议先看[完整报告的主表与机制解释](211_最终算法正式实验完整报告.md)，再看[四页论文可用实验材料](212_四页论文可用实验段落与主表.md)。全部原始结果、失败和超时记录均保留。

这是正式实验材料，不等于已经完成投稿；还需要按实际结果决定论文主张，并完成正文、证明压缩和会议模板适配。
''')
    print('Wrote 211, 212, 213')
    makefigures(R)
def makefigures(R):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    D=R['main'];fig,ax=plt.subplots(figsize=(8.8,5.5),layout='constrained')
    y=list(range(len(D)))
    for offset,field,color,label in [(-.17,'decision_only_seconds','#2368a0','Wall time'),(.17,'decision_only_cpu_seconds','#df8735','Process CPU time')]:
        for i,d in enumerate(D):
            v=d['tc_to_baseline_ratio'][field]['L']
            if v is not None:
                bars=ax.barh(i+offset,v,height=.29,color=color,label=label if i==0 else None)
                ax.bar_label(bars,labels=[f'{v:.2f}'],padding=3,fontsize=8)
            else:ax.text(.03,i+offset,'Incomplete',va='center',fontsize=8)
    ax.axvline(1,color='#777777',ls='--',lw=1)
    ax.set_yticks(y,[NAMES[d['key']] for d in D]);ax.invert_yaxis()
    ax.set_xlabel('Median TC time / median matched-L time\nBelow 1: TC faster; above 1: TC slower')
    fig.suptitle('Net cost of adding the membership certificate')
    ax.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncol=2);ax.spines[['top','right']].set_visible(False)
    vmax=max([d['tc_to_baseline_ratio'][k]['L'] or 0 for d in D for k in ['decision_only_seconds','decision_only_cpu_seconds']])
    if vmax>8:ax.set_xscale('log');ax.set_xlim(.5,vmax*1.3)
    else:ax.set_xlim(0,max(1.25,vmax*1.12))
    for suffix in ['png','svg']:fig.savefig(P/'图表'/('正式实验_TC相对L耗时.'+suffix),dpi=220)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10.5,4.5),layout='constrained')
    labels=[NAMES[d['key']] for d in D]
    axes[0].barh(y,[d['pass_count'] for d in D],color='#b9d3e6',label='Audited PASS nodes')
    axes[0].barh(y,[d['passes_with_actual_moves'] for d in D],color='#27678e',label='With actual later moves')
    savings=axes[1].barh(y,[d['skipped_rounds_in_audited_passes'] for d in D],color='#56865d')
    axes[1].bar_label(savings,padding=3)
    for i,d in enumerate(D):axes[0].text(d['pass_count']+.08,i,str(d['pass_count']),va='center',fontsize=9)
    for ax in axes:ax.margins(x=.18)
    for ax in axes:
        ax.set_yticks(y,labels);ax.invert_yaxis();ax.spines[['top','right']].set_visible(False)
    axes[0].set_title('Successful certificates');axes[0].set_xlabel('Node events (not unique samples)');axes[0].legend(fontsize=8)
    axes[1].set_title('Reference iterations omitted after PASS');axes[1].set_xlabel('Sum over independently audited PASS nodes')
    for i,d in enumerate(D):
        if not d['independent_audit_complete']:
            for ax in axes:ax.text(.05,i,'Audit incomplete',fontsize=8,va='center',color='#a14428')
    for suffix in ['png','svg']:fig.savefig(P/'图表'/('正式实验_成员移动与省略轮次.'+suffix),dpi=220)
    plt.close(fig)
if __name__=='__main__':main()
