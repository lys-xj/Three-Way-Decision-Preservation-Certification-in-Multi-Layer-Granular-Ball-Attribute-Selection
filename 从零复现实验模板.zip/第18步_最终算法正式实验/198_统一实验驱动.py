"""Matched F0/L/TC evaluation; frozen mathematical kernels are never edited."""
from pathlib import Path
from fractions import Fraction as F
from time import perf_counter, process_time
from collections import Counter
import importlib.util, hashlib, json, sys
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
FREEZE=load('formal18_verify',OUT.parent/'第15步_粗细两级认证与算法定版/158_冻结版本运行入口.py')
FROZEN=FREEZE.verify()
SELECTED=load('formal18_selected',OUT.parent/'第15步_粗细两级认证与算法定版/162_主算法接口.py')
K=SELECTED.K;API=SELECTED.API
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
SETTINGS={'main':((1,2),F(7,10),F(3,10)),
 'narrow':((1,2),F(6,10),F(4,10)),
 'wide':((1,2),F(8,10),F(2,10)),
 'deep':((1,2,3),F(7,10),F(3,10))}

def dataset(key):
 if key.startswith('synthetic_'):
  if key=='synthetic_D':return K.chain_case(False)[:2]
  if key=='synthetic_unsafe':return K.chain_case(True)[:2]
  data,attrs,_=K.chain_case(False)
  data={i:row[:-1]+((int(i%10==0) if key=='synthetic_R' else 1-int(i%10==0)),) for i,row in data.items()}
  return data,attrs
 manifest=json.loads((OUT/'197_公共数据清单.json').read_text(encoding='utf-8'))
 entry=next(x for x in manifest['datasets'] if x['key']==key)
 p=OUT/'待实验数据'/(key+'_exact.json');assert sha(p)==entry['prepared_sha256']
 raw=json.loads(p.read_text(encoding='utf-8'))
 return {int(i):tuple(F(v) for v in row[:-1])+(row[-1],) for i,row in raw['data'].items()},tuple(raw['attributes'])

def fingerprint(result):
 fields=('final_attributes','candidate_count','baseline_hash','decision_path_hash','search_path_hash','final_decisions_hash','final_structure_hash','final_geometry_hash')
 return API.digest({k:result[k] for k in fields})

def execute(method,data,attrs,setting='main',audit=False,progress=None):
 levels,alpha,beta=SETTINGS[setting];events=[];audited_passes=[];checks=0
 class Trial(SELECTED.FinalEvaluator):
  def certificate(self,*args):
   if method=='L':return None
   t=perf_counter();p=super().certificate(*args);duration=perf_counter()-t
   d=dict(self.last_diagnostic)
   events.append(dict(seconds=duration,reason=d['reason'],target=d.get('target'),
      optional_count=d.get('optional_count'),closure_rounds=d.get('closure_rounds',0)))
   return p
 engine=Trial(data,attrs,levels,alpha,beta)
 reference=K.AUDIT.Reference(data,attrs,levels,alpha,beta) if audit else None
 verification_wall=verification_cpu=0.0
 wall=perf_counter();cpu=process_time()
 state,stats=engine.construct(engine.C,'F0' if method=='F0' else 'F1')
 engine.metrics['lloyd_rounds']+=stats['recomputed_iterations']
 baseline=engine.decisions(state)
 state.update(decisions=baseline,has_abstract_regions=False,full_tree_available=True)
 initial_diagnostics=API.diagnostics(engine,state)
 if audit:
  w=perf_counter();c=process_time();original=reference.generate(engine.C)
  assert baseline==reference.decisions(original),'Initial decisions mismatch'
  assert API.signature(state)==API.signature(original),'Initial structure mismatch'
  checks+=1;verification_wall+=perf_counter()-w;verification_cpu+=process_time()-c
 A=engine.C;attempts=[];decision_records=[]
 while len(A)>1:
  accepted=False
  for a in engine.C:
   if a not in A:continue
   B=tuple(b for b in A if b!=a)
   if method=='F0':
    candidate,stats=engine.construct(B,'F0');engine.metrics['lloyd_rounds']+=stats['recomputed_iterations']
    candidate.update(decisions=engine.decisions(candidate),has_abstract_regions=False,full_tree_available=True)
   else:candidate=engine.partial_construct(B,baseline,state)
   decisions=candidate['decisions']
   delta=sum(decisions[h][i]!=baseline[h][i] for h in levels for i in engine.ids)
   attempts.append(dict(current=A,delete=a,candidate=B,accepted=delta==0,changed_count=delta,
     certified_regions=sum(n.get('abstract',False) for n in candidate['nodes'])))
   decision_records.append(decisions)
   if audit:
    w=perf_counter();c=process_time();truth=reference.generate(B)
    assert decisions==reference.decisions(truth),('Candidate decisions mismatch',A,a)
    checks+=1
    nodes={(n['depth'],tuple(n['ids'])):n for n in truth['nodes']}
    for node in candidate['nodes']:
     if not node.get('abstract'):continue
     proof=node['certificate'];real=nodes[(node['depth'],tuple(node['ids']))]
     assert 'children' in real,'Certified split was cancelled in reference'
     first=[set(g) for g in proof['first_groups']]
     assert first==[set(g) for g in real['iterations'][0]['groups']]
     later=real['iterations'][1:];ever=set()
     for it in later:ever.update(first[0]^set(it['groups'][0]))
     final_movers=first[0]^set(real['children'][0])
     assert set(ever)<=set(proof['uncertain'])
     assert all(reference.decisions(truth)[levels[-1]][i]==proof['decision'] for i in node['ids'])
     audited_passes.append(dict(candidate_index=len(attempts),attrs=B,path=node['path'],member_count=len(node['ids']),
       decision=proof['decision'],optional_count=len(proof['uncertain']),optional=list(proof['uncertain']),
       actual_ever_movers=sorted(ever),actual_final_movers=sorted(final_movers),
       actual_full_rounds=len(real['iterations']),skipped_rounds=len(later),
       bounds=proof['proportion_bounds']))
    verification_wall+=perf_counter()-w;verification_cpu+=process_time()-c
    if progress and len(attempts)%10==0:progress(dict(candidates=len(attempts),remaining_attributes=len(A),checks=checks))
   if delta==0:state=candidate;A=B;accepted=True;break
  if not accepted:break
 duration=perf_counter()-wall;cpu_duration=process_time()-cpu
 before=dict(engine.metrics);final_decisions=state['decisions']
 wall=perf_counter();cpu=process_time()
 if state['has_abstract_regions']:state=engine.partial_construct(A,baseline,state,materialize=True)
 geometry=engine.final_geometry(state)
 extra_wall=perf_counter()-wall;extra_cpu=process_time()-cpu
 assert state['decisions']==baseline==final_decisions
 if audit:
  independent=reference.generate(A)
  assert API.signature(state)==API.signature(independent),'Final structure mismatch'
  assert geometry==reference.geometry(independent),'Final geometry mismatch'
  checks+=1
 search=[(r['current'],r['delete'],r['accepted'],r['changed_count']) for r in attempts]
 result=dict(method=method,setting=setting,completed=True,version=SELECTED.VERSION,
   sample_count=len(data),attributes_before=len(attrs),final_attributes=A,candidate_count=len(attempts),
   accepted_deletions=sum(r['accepted'] for r in attempts),attempts=attempts,
   baseline_hash=API.digest(baseline),final_decisions_hash=API.digest(final_decisions),
   candidate_decision_hashes=[API.digest(d) for d in decision_records],decision_path_hash=API.digest(decision_records),
   search_path_hash=API.digest(search),final_structure_hash=API.digest(API.signature(state)),
   final_geometry_hash=API.digest(geometry),decision_only_seconds=duration-verification_wall,
   decision_only_cpu_seconds=cpu_duration-verification_cpu,materialize_geometry_seconds=extra_wall,
   materialize_geometry_cpu_seconds=extra_cpu,total_geometry_seconds=duration-verification_wall+extra_wall,
   total_geometry_cpu_seconds=cpu_duration-verification_cpu+extra_cpu,metrics=before,
   metrics_after_materialization=dict(engine.metrics),certificate_seconds=sum(e['seconds'] for e in events),
   certificate_failure_seconds=sum(e['seconds'] for e in events if e['reason']!='PASS'),
   certificate_reasons=dict(Counter(e['reason'] for e in events)),
   pass_decisions=dict(Counter(e['target'] for e in events if e['reason']=='PASS')),
   events=events,initial_diagnostics=initial_diagnostics,audit_only=audit,
   independent_checks=checks,independently_audited_passes=audited_passes,
   independent_reference_seconds=reference.seconds if audit else None,
   stop_reason='nonempty_singleton' if len(A)==1 else 'single_deletion_irreducible')
 result['output_fingerprint']=fingerprint(result)
 return result

def verify_lock():
 p=OUT/'202_正式实验冻结清单.json'
 if not p.exists():raise RuntimeError('Formal experiment lock missing')
 lock=json.loads(p.read_text(encoding='utf-8'))
 for relative,expected in lock['files'].items():
  q=(OUT/relative).resolve()
  if not q.is_relative_to(OUT) or sha(q)!=expected:raise RuntimeError('Changed experiment dependency '+relative)
 return sha(p)
