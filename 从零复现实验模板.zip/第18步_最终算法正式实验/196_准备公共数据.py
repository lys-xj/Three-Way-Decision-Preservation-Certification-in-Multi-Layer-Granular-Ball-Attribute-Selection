from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import csv, io, json, hashlib, zipfile, urllib.request, shutil

OUT=Path(__file__).resolve().parent
OLD=OUT.parent/'第6步_实验方案与创新性复核'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
NEW={
 'wbc':dict(id=15,slug='breast+cancer+wisconsin+original',member='breast-cancer-wisconsin.data',doi='10.24432/C5HP4Z',n=699,label_map={'2':0,'4':1}),
 'wdbc':dict(id=17,slug='breast+cancer+wisconsin+diagnostic',member='wdbc.data',doi='10.24432/C5DW2B',n=569,label_map={'B':0,'M':1}),
 'haberman':dict(id=43,slug='haberman+s+survival',member='haberman.data',doi='10.24432/C5XK51',n=306,label_map={'1':0,'2':1}),
 'blood':dict(id=176,slug='blood+transfusion+service+center',member='transfusion.data',doi='10.24432/C5GS39',n=748,label_map={'0':0,'1':1})}

def write(p,x):
 text=json.dumps(x,ensure_ascii=False,indent=2)
 if p.exists():
  if p.read_text(encoding='utf-8')!=text:raise RuntimeError('Refusing changed prepared data '+str(p))
 else:p.write_text(text,encoding='utf-8')

def main():
 for name in ['原始数据','待实验数据','核查记录','原始结果','运行日志','独立核验','图表']:(OUT/name).mkdir(exist_ok=True)
 records=[]
 for key in ['banknote','climate','ionosphere','sonar']:
  source=OLD/'待实验数据'/(key+'_exact.json');dest=OUT/'待实验数据'/source.name
  if not dest.exists():shutil.copy2(source,dest)
  assert sha(source)==sha(dest)
  raw=json.loads(dest.read_text(encoding='utf-8'))
  records.append(dict(key=key,n=len(raw['data']),d=len(raw['attributes']),positive=sum(row[-1] for row in raw['data'].values()),role='development_data',prepared_sha256=sha(dest),uci_page=raw['uci_page'],dataset_doi=raw['dataset_doi'],source_archive_sha256=raw['source_archive_sha256']))
 for key,spec in NEW.items():
  url=f"https://archive.ics.uci.edu/static/public/{spec['id']}/{spec['slug']}.zip"
  archive=OUT/'原始数据'/(key+'.zip')
  if not archive.exists():
   req=urllib.request.Request(url,headers={'User-Agent':'Academic research dataset download'})
   with urllib.request.urlopen(req,timeout=60) as r:payload=r.read()
   with archive.open('xb') as f:f.write(payload)
  with zipfile.ZipFile(archive) as z:
   member=next(name for name in z.namelist() if name.split('/')[-1]==spec['member'])
   content=z.read(member)
  rows=list(csv.reader(io.StringIO(content.decode('utf-8-sig'))))
  rows=[r for r in rows if r and any(c.strip() for c in r)]
  if key=='blood':header=rows.pop(0)
  assert len(rows)==spec['n'],(key,len(rows))
  clean=[];dropped=[];ids=[]
  for line,r in enumerate(rows,1):
   r=[x.strip() for x in r]
   if '?' in r or '' in r:dropped.append(line);continue
   if key=='wbc':xs,y,identifier=r[1:-1],r[-1],r[0]
   elif key=='wdbc':xs,y,identifier=r[2:],r[1],r[0]
   else:xs,y,identifier=r[:-1],r[-1],None
   clean.append(([F(x) for x in xs],spec['label_map'][y]));ids.append(dict(source_line=line,source_id=identifier))
  d=len(clean[0][0]);mins=[min(x[j] for x,y in clean) for j in range(d)];maxs=[max(x[j] for x,y in clean) for j in range(d)]
  keep=[j for j in range(d) if maxs[j]>mins[j]];attrs=[f'a{j+1:02d}' for j in keep]
  data={str(i+1):[str((x[j]-mins[j])/(maxs[j]-mins[j])) for j in keep]+[y] for i,(x,y) in enumerate(clean)}
  raw=dict(dataset=key,uci_page=f"https://archive.ics.uci.edu/dataset/{spec['id']}/{spec['slug']}",dataset_doi=spec['doi'],license='CC BY 4.0',source_url=url,source_archive_sha256=sha(archive),source_member=member,source_member_sha256=hashlib.sha256(content).hexdigest(),label_map=spec['label_map'],raw_sample_count=len(rows),dropped_missing_source_lines=dropped,source_identifiers=ids,source_identifiers_used_as_features=False,attributes=attrs,removed_constant_features=[j+1 for j in range(d) if j not in keep],scaling_parameters=[dict(attribute=f'a{j+1:02d}',minimum=str(mins[j]),maximum=str(maxs[j])) for j in keep],preprocessing='exact rational min-max once on fixed complete-case universe; original order; no deduplication',data=data)
  dest=OUT/'待实验数据'/(key+'_exact.json');write(dest,raw)
  records.append(dict(key=key,n=len(data),d=len(attrs),positive=sum(y for x,y in clean),role='new_external_benchmark',dropped_missing=len(dropped),prepared_sha256=sha(dest),uci_page=raw['uci_page'],dataset_doi=raw['dataset_doi'],source_archive_sha256=sha(archive)))
 manifest=dict(datasets=records,data_selection_precedes_new_algorithm_runs=True)
 write(OUT/'197_公共数据清单.json',manifest)
 print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
