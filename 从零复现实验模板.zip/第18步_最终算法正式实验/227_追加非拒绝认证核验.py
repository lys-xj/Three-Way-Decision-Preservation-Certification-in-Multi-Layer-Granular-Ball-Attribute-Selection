"""Post-hoc, transparently selected mechanism audits; no performance claims."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,subprocess,sys,os,hashlib,time
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    original=json.loads((P/'209_正式实验汇总.json').read_text(encoding='utf-8'))
    chosen=[x for x in original['sensitivity'] if any(x['runs'].get('TC',{}).get('pass_decisions',{}).get(q,0)>0 for q in ['A','D'])]
    lp=P/'228_追加核验台账.json'
    ledger=json.loads(lp.read_text(encoding='utf-8')) if lp.exists() else dict(post_hoc=True,
      created_utc=datetime.now(timezone.utc).isoformat(),selection_rule='All completed sensitivity settings with any TC PASS in A or D, before examining actual later movements',
      plan_sha256=sha(P/'226_非拒绝认证的追加核验方案.md'),original_summary_sha256=sha(P/'209_正式实验汇总.json'),
      selected=[(x['dataset'],x['setting']) for x in chosen],jobs={},completed=False)
    assert ledger['plan_sha256']==sha(P/'226_非拒绝认证的追加核验方案.md')
    assert ledger['original_summary_sha256']==sha(P/'209_正式实验汇总.json')
    assert ledger['selected']==[[x['dataset'],x['setting']] for x in chosen] or ledger['selected']==[(x['dataset'],x['setting']) for x in chosen]
    (P/'补充核验').mkdir(exist_ok=True)
    for item in chosen:
        key=item['dataset'];setting=item['setting'];name=f'{key}_{setting}_TC_posthoc_audit'
        if name in ledger['jobs']:continue
        out=P/'补充核验'/(name+'.json');log=P/'运行日志'/(name+'.log')
        assert not out.exists()
        ledger['active']=name;save(lp,ledger);print('START '+name,flush=True)
        cmd=[sys.executable,str(P/'199_单次正式实验.py'),'--dataset',key,'--method','TC','--setting',setting,'--phase','audit','--output',str(out)]
        with log.open('w',encoding='utf-8') as f:
            try:
                done=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1800,env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1'))
                status='complete' if done.returncode==0 and out.exists() else 'error'
            except subprocess.TimeoutExpired:status='timeout'
        row=dict(status=status,dataset=key,setting=setting,log=str(log.relative_to(P)),budget_seconds=1800)
        if status=='complete':
            r=json.loads(out.read_text(encoding='utf-8'))
            assert r['audit_only'] and r['output_fingerprint']==item['runs']['TC']['output_fingerprint']
            assert len(r['independently_audited_passes'])==r['metrics']['certificate_passes']
            row.update(output=str(out.relative_to(P)),sha256=sha(out),same_as_original=True,
              candidate_count=r['candidate_count'],independent_checks=r['independent_checks'],
              pass_decisions=r['pass_decisions'],audited_passes=r['independently_audited_passes'],
              initial_diagnostics=r['initial_diagnostics'])
        ledger['jobs'][name]=row;ledger['active']=None;save(lp,ledger)
        print('FINISHED '+name+' '+status,flush=True)
        if status=='error':raise RuntimeError(log)
    ledger['completed']=True;ledger['finished_utc']=datetime.now(timezone.utc).isoformat();save(lp,ledger)
    rows=[];details=[];classes=Counter();moving=Counter();moving_accepted=0
    for job in ledger['jobs'].values():
        if job['status']!='complete':
            rows.append(f"| {job['dataset']} | {job['setting']} | {job['status']} | — | — | — | — |");continue
        assert sha(P/job['output'])==job['sha256']
        raw=json.loads((P/job['output']).read_text(encoding='utf-8'))
        ps=job['audited_passes'];classes.update(p['decision'] for p in ps);moving.update(p['decision'] for p in ps if p['actual_ever_movers'])
        rows.append(f"| {job['dataset']} | {job['setting']} | 完成且一致 | {job['candidate_count']} | {job['pass_decisions']} | {sum(bool(p['actual_ever_movers']) for p in ps)} | {sum(p['skipped_rounds'] for p in ps)} |")
        for p in ps:
            accepted=raw['attempts'][p['candidate_index']-1]['accepted']
            moving_accepted+=bool(p['actual_ever_movers']) and accepted
            details.append(f"| {job['dataset']}-{job['setting']} | {p['candidate_index']} | {p['path']} | {p['decision']} | {p['member_count']} | {p['optional_count']} | {len(p['actual_ever_movers'])} | {len(p['actual_final_movers'])} | {p['skipped_rounds']} | {'接受' if accepted else '拒绝'} | {p['bounds']} |")
    report='''# 非拒绝认证的追加机制核验

这是观察预设参数实验后追加的探索性核验。选取所有出现A或D认证的敏感性设置；没有根据实际换组人数或运行速度再筛选。主实验及原222份输出不变。本表不报告性能收益。

| 数据 | 参数设置 | 独立审核 | 候选数 | PASS类别 | 实际曾换组的PASS数 | 省略轮数 |
|---|---|---|---|---|---|---|
'''+ '\n'.join(rows)+f'\n\n全部被审核PASS的类别为{dict(classes)}；其中实际发生后续成员换组的类别为{dict(moving)}。这些是节点事件数，不是不重复样本数。实际发生换组且其所属候选整体被接受的节点数为{moving_accepted}；不能把局部安全认证写成已成功删除该属性。\n\n'+'''| 设置 | 候选序号 | 节点 | 决定 | 节点人数 | 可变名单人数 | 实际曾换组人数 | 最终换组人数 | 省略轮数 | 候选整体 | 比例界 |
|---|---|---|---|---|---|---|---|---|---|---|
'''+ '\n'.join(details)+'''

R=拒绝，D=暂缓，A=接受。实际曾换组为0的成功也完整保留。单个节点PASS不等于整个候选属性可删除。每个候选仍须在所有观察层与完整重构一致。

该结果可以支持已观察到的具体机制事件；它不是预注册的独立泛化检验，也不能证明普遍加速。初始各层决定分布、所有样本内部编号、真实轨迹与候选接受/拒绝路径见228号台账及补充核验目录中的原始结果。具体选择规则见226号方案。
'''
    (P/'229_非拒绝认证追加核验报告.md').write_text(report,encoding='utf-8')
    print(json.dumps(dict(post_hoc=True,settings=len(chosen),pass_decisions=dict(classes),actual_moving_pass_decisions=dict(moving)),ensure_ascii=False))
if __name__=='__main__':main()
