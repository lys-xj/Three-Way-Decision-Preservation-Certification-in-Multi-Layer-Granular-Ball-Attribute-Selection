from pathlib import Path
import importlib.util,sys,json,hashlib,random
from fractions import Fraction as F
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('driver_smoke',OUT/'198_统一实验驱动.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)

def main():
 if (OUT/'202_正式实验冻结清单.json').exists():raise RuntimeError('Already locked')
 cases=[M.K.small_case()[:2]]
 rng=random.Random(20260928)
 for _ in range(12):
  data={i+1:tuple(F(rng.randrange(12)) for j in range(3))+(rng.randrange(2),) for i in range(12)}
  cases.append((data,('a','b','c')))
 rows=[]
 for index,(data,attrs) in enumerate(cases):
  results=[M.execute(method,data,attrs,'deep',audit=True) for method in ['F0','L','TC']]
  assert len({r['output_fingerprint'] for r in results})==1,('Cross-method mismatch',index)
  e=M.SELECTED.FinalEvaluator(data,attrs,(1,2,3),F(7,10),F(3,10));frozen=e.solve_certified(materialize_final=True)
  r=results[2]
  assert tuple(r['final_attributes'])==tuple(frozen['final_attributes'])
  assert r['baseline_hash']==M.API.digest(frozen['baseline'])
  assert r['final_geometry_hash']==frozen['final_geometry_hash']
  assert r['final_structure_hash']==frozen['final_structure_hash']
  got=[(a['current'],a['delete'],a['accepted'],a['changed_count']) for a in r['attempts']]
  expected=[(a['current'],a['delete'],a['accepted'],a['changed_count']) for a in frozen['attempts']]
  assert got==expected
  old=M.API.Evaluator(data,attrs,(1,2,3),F(7,10),F(3,10)).solve('L')
  assert M.API.digest([(a['current'],a['delete'],a['accepted'],a['changed_count']) for a in old['attempts']])==r['search_path_hash']
  rows.append(dict(case=index,candidates=r['candidate_count'],passed=True))
 record=dict(cases=rows,all_passed=True,frozen_files_unchanged=len(M.FROZEN['files']))
 (OUT/'核查记录/201_驱动核验结果.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
 files=[OUT/name for name in ['195_正式实验预设方案.md','196_准备公共数据.py','197_公共数据清单.json','198_统一实验驱动.py','199_单次正式实验.py','200_串行执行与恢复.py','201_驱动核验与锁定.py']]+list((OUT/'待实验数据').glob('*.json'))
 lock=dict(version=M.SELECTED.VERSION,protocol='8 UCI; 3 methods; 1 warmup+5 repeats; 12 sensitivity settings; 4 synthetic controls',files={str(p.relative_to(OUT)):M.sha(p) for p in files})
 (OUT/'202_正式实验冻结清单.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(record,ensure_ascii=False))
if __name__=='__main__':main()
