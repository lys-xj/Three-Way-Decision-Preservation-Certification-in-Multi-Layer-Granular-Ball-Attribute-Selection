"""Bounded, serial pilot. No validation or disk I/O in the algorithm timer.

One untimed audit, one warm-up/method, then three cyclic-order paired repeats.
Sonar is capped at the SAME first 20 candidates as the previous exploration.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from time import perf_counter
from statistics import median
from unittest.mock import patch
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('pilot_cf', OUT/'151_粗细两级认证算法.py')
M = importlib.util.module_from_spec(s); s.loader.exec_module(M)
K, API, BASE = M.K, M.API, M.BASE
METHODS = dict(v03=BASE.ClosureEvaluator, incremental_exact=M.IncrementalExactEvaluator,
               coarse_fine=M.CoarseFineEvaluator)
KEYS = ('banknote', 'climate', 'ionosphere', 'sonar')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, value):
    p.write_text(json.dumps(API.encode(value), ensure_ascii=False, indent=2), encoding='utf-8')


def execute(method, data, attrs, cap=0, verify_each=False, prior=None):
    events = []
    class Probe(METHODS[method]):
        def certificate(self, *args):
            t = perf_counter()
            result = super().certificate(*args)
            events.append(dict(seconds=perf_counter()-t, **self.last_diagnostic))
            return result
    e = Probe(data, attrs, (1, 2), F(7, 10), F(3, 10))
    ref = K.AUDIT.Reference(data, attrs, e.levels, e.alpha, e.beta) if verify_each else None
    start = perf_counter()
    state, stats = e.construct(e.C, 'F1')
    e.metrics['lloyd_rounds'] += stats['recomputed_iterations']
    baseline = e.decisions(state)
    state.update(decisions=baseline, has_abstract_regions=False, full_tree_available=True)
    A = e.C; attempts = []; stopped = False; verification_seconds = 0
    while len(A) > 1:
        accepted = False
        for a in e.C:
            if a not in A:
                continue
            if cap and len(attempts) >= cap:
                stopped = True
                break
            B = tuple(b for b in A if b != a)
            candidate = e.partial_construct(B, baseline, state)
            delta = sum(candidate['decisions'][h][i] != baseline[h][i] for h in e.levels for i in e.ids)
            attempts.append(dict(current=A, delete=a, candidate=B, accepted=delta == 0,
                changed_count=delta, certified_regions=sum(n.get('abstract', False) for n in candidate['nodes'])))
            if verify_each:
                check_start = perf_counter()
                expected = prior['attempts'][len(attempts)-1]
                assert tuple(expected['current']) == A and expected['delete'] == a
                assert delta == expected['changed_count'] and (delta == 0) == expected['accepted']
                if candidate['has_abstract_regions']:
                    independent = ref.generate(B)
                    assert candidate['decisions'] == ref.decisions(independent)
                else:
                    assert API.digest(API.signature(candidate, True)) == expected['reference_trace_hash']
                verification_seconds += perf_counter()-check_start
            if delta == 0:
                state, A, accepted = candidate, B, True
                break
        if stopped or not accepted:
            break
    duration = perf_counter()-start
    # Only non-audit executions are used for timing. Audit timings are discarded.
    before = dict(e.metrics)
    decisions = state['decisions']
    t = perf_counter()
    if state['has_abstract_regions']:
        state = e.partial_construct(A, baseline, state, materialize=True)
    geometry = e.final_geometry(state)
    materialize_and_geometry = perf_counter()-t
    assert decisions == baseline == state['decisions']
    result = dict(method=method, candidate_count=len(attempts), completed=not stopped,
        current_attributes=A, attempts=attempts, baseline_hash=API.digest(baseline),
        final_decisions_hash=API.digest(decisions), final_trace_hash=API.digest(API.signature(state, True)),
        final_geometry_hash=API.digest(geometry), decision_only_seconds=duration,
        materialization_and_geometry_seconds=materialize_and_geometry,
        total_with_geometry_seconds=duration+materialize_and_geometry,
        certificate_seconds=sum(x['seconds'] for x in events),
        certificate_reasons=dict(Counter(x['reason'] for x in events)),
        metrics=before, metrics_after_materialization=dict(e.metrics),
        audit_only=verify_each, excluded_audit_seconds=verification_seconds)
    # Checks below are OUTSIDE all timing regions.
    if prior:
        assert result['baseline_hash'] == prior['methods']['L']['baseline_hash']
        for got, expected in zip(attempts, prior['attempts']):
            assert (got['current'], got['delete'], got['accepted'], got['changed_count']) == (
                tuple(expected['current']), expected['delete'], expected['accepted'], expected['changed_count'])
        if not stopped:
            assert len(attempts) == len(prior['attempts'])
            assert tuple(prior['methods']['L']['final_attributes']) == A
            assert result['final_trace_hash'] == prior['methods']['L']['final_trace_hash']
            assert result['final_geometry_hash'] == prior['methods']['L']['final_geometry_hash']
        elif verify_each:
            independent = ref.generate(A)
            assert API.signature(state, True) == API.signature(independent, True)
    return result


def fingerprint(r):
    return API.digest({k:r[k] for k in ('candidate_count', 'completed', 'current_attributes', 'attempts',
        'baseline_hash', 'final_decisions_hash', 'final_trace_hash', 'final_geometry_hash', 'certificate_reasons')})


def one_dataset(key):
    data, attrs = K.AUDIT.dataset(key)
    cap = 20 if key == 'sonar' else 0
    prior_path = OUT.parent/'第11步_正式实验'/'独立核验'/(key+'_audit.json')
    prior = json.loads(prior_path.read_text(encoding='utf-8'))
    assert prior['all_passed'] and prior['mismatches'] == 0
    for field, path in [('api_sha256', K.AUDIT.API_PATH), ('core_sha256', K.AUDIT.API.CORE_PATH), ('ref_sha256', K.AUDIT.REF_PATH)]:
        assert sha(path) == prior['identity'][field]
    records = []; original = BASE.least_envelope
    def checked_closure(points, groups):
        old = original(points, groups)
        cf = M.least_envelope(points, groups)
        exact = M.least_envelope(points, groups, 'exact')
        for r in (cf, exact):
            assert r['steps'] == old['steps'] and r['status'] == old['status']
            assert r['final']['optional'] == old['final']['optional']
        records.append(dict(member_count=len(points), attributes=len(next(iter(points.values()))),
            rounds=len(old['steps']), status=old['status'], optional_count=len(old['final']['optional']),
            steps_hash=API.digest(old['steps']), cf_cost=cf['cost']))
        return old
    with patch.object(BASE, 'least_envelope', checked_closure):
        audited = execute('v03', data, attrs, cap, verify_each=True, prior=prior)
    expected = fingerprint(audited)
    print(json.dumps(dict(dataset=key, phase='audit_passed', candidates=audited['candidate_count'],
                          closure_calls=len(records))), flush=True)
    warmups = []
    for method in METHODS:
        row = execute(method, data, attrs, cap, prior=prior)
        assert fingerprint(row) == expected
        warmups.append(row)
        print(json.dumps(dict(dataset=key, phase='warmup', method=method,
                              seconds=round(row['decision_only_seconds'], 4))), flush=True)
    runs = []
    names = list(METHODS)
    for repeat in range(3):
        order = names[repeat:] + names[:repeat]
        for method in order:
            row = execute(method, data, attrs, cap, prior=prior)
            assert fingerprint(row) == expected
            row.update(repeat=repeat+1, order=order)
            runs.append(row)
            print(json.dumps(dict(dataset=key, repeat=repeat+1, method=method,
                                  seconds=round(row['decision_only_seconds'], 4))), flush=True)
    summary = {}
    for method in names:
        rows = [r for r in runs if r['method'] == method]
        summary[method] = {field:dict(median=median(r[field] for r in rows), minimum=min(r[field] for r in rows),
                                    maximum=max(r[field] for r in rows))
            for field in ('decision_only_seconds', 'materialization_and_geometry_seconds',
                          'total_with_geometry_seconds', 'certificate_seconds')}
        summary[method]['metrics'] = rows[0]['metrics']
        assert all(r['metrics'] == rows[0]['metrics'] for r in rows)
    value = dict(dataset=key, version=M.VERSION, timestamp_utc=datetime.now(timezone.utc).isoformat(),
        all_passed=True, mismatches=0, capped_candidates=cap or None, complete_reduction=not cap,
        candidate_count=audited['candidate_count'], current_attributes=audited['current_attributes'],
        sample_count=len(data), attribute_count=len(attrs), all_output_fingerprints=expected,
        config=dict(levels=[1, 2], alpha='7/10', beta='3/10'),
        prior_audit_sha256=sha(prior_path),
        prepared_data_sha256=sha(K.AUDIT.STEP6/'待实验数据'/(key+'_exact.json')),
        source_sha256=sha(OUT/'151_粗细两级认证算法.py'),
        driver_sha256=sha(Path(__file__)), protocol_sha256=sha(OUT/'150_本轮实施与验证方案.md'),
        closure_equivalence_records=records, audit=audited, warmups=warmups, runs=runs, summary=summary,
        limitation='Single-machine pilot, three repetitions; Sonar is a 20-candidate prefix; not a formal speedup claim.')
    target = OUT/'真实数据结果'; target.mkdir(exist_ok=True)
    save(target/(key+'_pilot.json'), value)
    return dict(dataset=key, candidates=audited['candidate_count'], all_passed=True,
                decision_seconds={k:summary[k]['decision_only_seconds']['median'] for k in names})


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--dataset', choices=KEYS); a = p.parse_args()
    for key in ((a.dataset,) if a.dataset else KEYS):
        print(json.dumps(one_dataset(key)), flush=True)
