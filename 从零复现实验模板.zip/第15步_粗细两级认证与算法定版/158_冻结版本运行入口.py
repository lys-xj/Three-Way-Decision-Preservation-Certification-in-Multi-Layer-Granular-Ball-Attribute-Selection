"""Verify every locked source/data/evidence hash before loading this version.

Default: verification only. A new research run needs --dataset and --output.
Do not run with python -O: this research implementation uses assertions.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent


def verify():
    if not __debug__:
        raise RuntimeError('Run without -O so all research checks remain enabled.')
    lock = json.loads((OUT/'159_冻结版本清单.json').read_text(encoding='utf-8'))
    for name, expected in lock['files'].items():
        p = (ROOT/name).resolve()
        if not p.is_relative_to(ROOT.resolve()) or not p.is_file():
            raise ValueError('Missing or invalid dependency: '+name)
        if hashlib.sha256(p.read_bytes()).hexdigest() != expected['sha256']:
            raise ValueError('Frozen file changed: '+name)
    return lock


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset', choices=('banknote', 'climate', 'ionosphere', 'sonar'))
    p.add_argument('--method', choices=('final', 'coarse_fine', 'v03'), default='final')
    p.add_argument('--materialize-final', action='store_true')
    p.add_argument('--output')
    a = p.parse_args()
    lock = verify()
    if not a.dataset:
        print(json.dumps(dict(version=lock['version'], unchanged=True, files_checked=len(lock['files']))))
        return
    if not a.output:
        p.error('--dataset requires a NEW --output file; Sonar full reduction may take a long time.')
    target = Path(a.output).resolve()
    if target.exists():
        p.error('Output already exists. Choose a new filename.')
    s = importlib.util.spec_from_file_location('frozen_selected', OUT/'162_主算法接口.py')
    selected = importlib.util.module_from_spec(s); s.loader.exec_module(selected)
    m = selected.KERNEL
    from fractions import Fraction as F
    data, attrs = m.K.AUDIT.dataset(a.dataset)
    cls = dict(final=selected.FinalEvaluator, coarse_fine=m.CoarseFineEvaluator,
               v03=m.BASE.ClosureEvaluator)[a.method]
    result = cls(data, attrs, (1, 2), F(7, 10), F(3, 10)).solve_certified(materialize_final=a.materialize_final)
    if a.method == 'v03':
        result['version'] = m.BASE.VERSION
    result.update(method=a.method, source_version=lock['version'], dataset=a.dataset,
        frozen_manifest_sha256=hashlib.sha256((OUT/'159_冻结版本清单.json').read_bytes()).hexdigest())
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8') as f:
        json.dump(m.API.encode(result), f, ensure_ascii=False, indent=2)
    print(json.dumps(dict(completed=True, method=a.method, final_attributes=result['final_attributes'],
                          output=str(target)), ensure_ascii=False))


if __name__ == '__main__':
    main()
