"""Publication-candidate interface for the unchanged incremental exact kernel.

Selection is documented after the declared three-way pilot, not represented as
an a-priori experimental choice. Only evidence/version labels change here.
"""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('selected_v04_kernel', OUT/'151_粗细两级认证算法.py')
KERNEL = importlib.util.module_from_spec(spec)
spec.loader.exec_module(KERNEL)
API, K = KERNEL.API, KERNEL.K
VERSION = 'TailCert-L-IE-v0.4'


class FinalEvaluator(KERNEL.IncrementalExactEvaluator):
    """Fixed exact policy; does not switch policy after seeing a dataset."""
    def certificate(self, *args, **kwargs):
        proof = super().certificate(*args, **kwargs)
        if proof is not None:
            proof.update(version=VERSION, kind='least-member-envelope-incremental-exact',
                         implementation_policy='incremental_exact')
        return proof

    def solve_certified(self, *args, **kwargs):
        result = super().solve_certified(*args, **kwargs)
        result.update(version=VERSION, implementation_policy='incremental_exact')
        return result
