"""Exact-arithmetic, output-equivalent acceleration of the v0.3 closure.

CF is the fixed production policy; exact is an ablation, not data-dependent tuning.
Only the last split is abstracted. A failed coarse test ALWAYS falls back to the
original exact box test before the optional set can grow.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
BASE_PATH = OUT.parent / '第13步_真实数据可用性核验' / '126_最小成员包络.py'
spec = importlib.util.spec_from_file_location('cf_v03_baseline', BASE_PATH)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
K, API = BASE.K, BASE.API
VERSION = 'TailCert-L-CF-v0.4'


def counters():
    return dict(box_distance_calls=0, box_coordinate_terms=0,
                mean_box_coordinates=0, mean_box_optional_values_sorted=0,
                cf_initial_sum_inputs=0, cf_incremental_sum_inputs=0,
                cf_coarse_box_coordinates=0, cf_exact_box_builds=0,
                cf_coarse_checks=0, cf_coarse_passes=0,
                cf_exact_checks=0, cf_refinements=0,
                cf_refinement_rescues=0, cf_singleton_box_checks=0)


def necessary_distances(point, own_box, other_box):
    """Only max squared distance to own box and min to the other are needed."""
    upper = lower = F(0)
    for x, (a, b), (c, d) in zip(point, own_box, other_box):
        far = max(abs(x - a), abs(x - b))
        near = c - x if x < c else x - d if x > d else F(0)
        upper += far * far
        lower += near * near
    return upper, lower


def passes(group, upper, lower):
    # Assignment ties belong to group 0. Group 1 needs a strict inequality.
    return upper <= lower if group == 0 else upper < lower


class EnvelopeState:
    def __init__(self, points, groups):
        self.points = points
        self.groups = tuple(tuple(g) for g in groups)
        assert len(self.groups) == 2 and points
        flat = [i for g in self.groups for i in g]
        assert len(flat) == len(set(flat)) and set(flat) == set(points)
        self.d = len(next(iter(points.values())))
        assert self.d > 0 and all(len(p) == self.d for p in points.values())
        # Reject silently inexact inputs instead of promising a false certificate.
        assert all(isinstance(x, (int, F)) for p in points.values() for x in p)
        self.owner = {i: g for g in (0, 1) for i in self.groups[g]}
        self.U = set()
        self.n = list(map(len, self.groups))
        self.sums = [[sum((points[i][j] for i in self.groups[g]), F(0))
                      for j in range(self.d)] for g in (0, 1)]
        self.values = [[] for _ in range(self.d)]
        self.minimum = [None] * self.d
        self.maximum = [None] * self.d
        self.cost = counters()
        self.cost['cf_initial_sum_inputs'] = len(points) * self.d

    def grow(self, ids):
        for i in ids:
            assert i not in self.U
            g = self.owner[i]
            self.n[g] -= 1
            for j, x in enumerate(self.points[i]):
                self.sums[g][j] -= x
                self.values[j].append(x)
                self.minimum[j] = x if self.minimum[j] is None else min(self.minimum[j], x)
                self.maximum[j] = x if self.maximum[j] is None else max(self.maximum[j], x)
                self.cost['cf_incremental_sum_inputs'] += 1
            self.U.add(i)

    def coarse_boxes(self):
        m = len(self.U)
        result = []
        for g in (0, 1):
            n = self.n[g]
            box = []
            for j, s in enumerate(self.sums[g]):
                mean = s / n
                if m:
                    lo = min(mean, (s + m * self.minimum[j]) / (n + m))
                    hi = max(mean, (s + m * self.maximum[j]) / (n + m))
                else:
                    lo = hi = mean
                box.append((lo, hi))
            result.append(tuple(box))
        self.cost['cf_coarse_box_coordinates'] += 2 * self.d
        return result

    def exact_boxes(self):
        result = [[], []]
        m = len(self.U)
        for j in range(self.d):
            z = sorted(self.values[j])
            prefix_low = [F(0)]
            prefix_high = [F(0)]
            for k in range(m):
                prefix_low.append(prefix_low[-1] + z[k])
                prefix_high.append(prefix_high[-1] + z[m - 1 - k])
            for g in (0, 1):
                n, s = self.n[g], self.sums[g][j]
                lo = min((s + prefix_low[k]) / (n + k) for k in range(m + 1))
                hi = max((s + prefix_high[k]) / (n + k) for k in range(m + 1))
                result[g].append((lo, hi))
        self.cost['cf_exact_box_builds'] += 1
        self.cost['mean_box_coordinates'] += 2 * self.d
        self.cost['mean_box_optional_values_sorted'] += self.d * m
        return [tuple(b) for b in result]

    def inspect(self, policy='cf'):
        assert policy in ('cf', 'exact')
        cores = [tuple(i for i in g if i not in self.U) for g in self.groups]
        result = dict(valid_cores=min(self.n) >= 2, cores=cores,
                      optional=tuple(sorted(self.U)))
        if not result['valid_cores']:
            return result
        coarse = self.coarse_boxes() if policy == 'cf' else None
        exact = self.exact_boxes() if policy == 'exact' else None
        if policy == 'cf' and not self.U:
            exact = coarse  # Identical singleton boxes: do not do the check twice.
        checks, violations = [], []
        for g in (0, 1):
            for i in cores[g]:
                source = 'exact'
                if policy == 'cf':
                    upper, lower = necessary_distances(self.points[i], coarse[g], coarse[1-g])
                    self.cost['cf_coarse_checks'] += 1
                    source = 'coarse'
                    ok = passes(g, upper, lower)
                    if not self.U:
                        self.cost['cf_singleton_box_checks'] += 1
                        source = 'singleton_exact'
                    if ok:
                        self.cost['cf_coarse_passes'] += 1
                    elif self.U:
                        if exact is None:
                            exact = self.exact_boxes()
                        upper, lower = necessary_distances(self.points[i], exact[g], exact[1-g])
                        self.cost['cf_refinements'] += 1
                        self.cost['cf_exact_checks'] += 1
                        ok = passes(g, upper, lower)
                        self.cost['cf_refinement_rescues'] += int(ok)
                        source = 'exact'
                else:
                    upper, lower = necessary_distances(self.points[i], exact[g], exact[1-g])
                    self.cost['cf_exact_checks'] += 1
                    ok = passes(g, upper, lower)
                checks.append(dict(id=i, group=g, own_upper=upper,
                                   other_lower=lower, bound_source=source))
                if not ok:
                    violations.append(i)
        total_checks = self.cost['cf_coarse_checks'] + self.cost['cf_exact_checks']
        # These count bound evaluations. v0.3 calculates unused bounds as well;
        # identical counter names therefore do not imply identical arithmetic cost.
        self.cost['box_distance_calls'] = 2 * total_checks
        self.cost['box_coordinate_terms'] = 2 * self.d * total_checks
        result.update(boxes=exact if exact is not None else coarse,
                      box_kind='exact' if exact is not None else 'coarse_outer',
                      screening_boxes=coarse, violations=tuple(violations), checks=checks)
        return result


def least_envelope(points, first_groups, policy='cf'):
    state = EnvelopeState(points, first_groups)
    steps = []
    while True:
        e = state.inspect(policy)
        if not e['valid_cores']:
            return dict(status='no_envelope_with_two_core_members', steps=steps,
                        final=e, cost=state.cost)
        steps.append(dict(optional=e['optional'], violations=e['violations'],
                          core_sizes=list(map(len, e['cores']))))
        if not e['violations']:
            return dict(status='least_envelope_found', steps=steps, final=e, cost=state.cost)
        state.grow(e['violations'])  # Synchronous update after all exact fallbacks.


class CoarseFineEvaluator(BASE.ClosureEvaluator):
    policy = 'cf'

    def reset_metrics(self):
        super().reset_metrics()
        self.metrics.update(counters())

    def certificate(self, ids, attrs, groups, first_distances, baseline):
        self.metrics['certificate_attempts'] += 1
        targets = {baseline[self.H][i] for i in ids}
        if len(targets) != 1:
            self.metrics['closure_failed_reference'] += 1
            self.last_diagnostic = dict(reason='reference_decisions_not_uniform')
            return None
        target = next(iter(targets))
        points = {i: self.point(i, attrs) for i in ids}
        r = least_envelope(points, groups, self.policy)
        self.metrics['closure_rounds'] += len(r['steps'])
        for k, v in r['cost'].items():
            self.metrics[k] += v
        if r['status'] != 'least_envelope_found':
            self.metrics['closure_failed_geometry'] += 1
            self.last_diagnostic = dict(reason=r['status'], closure_rounds=len(r['steps']), steps=r['steps'])
            return None
        e = r['final']
        bounds = [K.ratio_interval([self.data[i][-1] for i in e['cores'][g]],
                                  [self.data[i][-1] for i in e['optional']]) for g in (0, 1)]
        if any(K.interval_decision(*b, self.alpha, self.beta) != target for b in bounds):
            self.metrics['closure_failed_ratio'] += 1
            self.last_diagnostic = dict(reason='least_envelope_ratio_crosses_threshold',
                bounds=bounds, target=target, optional_count=len(e['optional']), closure_rounds=len(r['steps']))
            return None
        self.metrics['certificate_passes'] += 1
        self.metrics['closure_passes'] += 1
        self.metrics['certified_samples_at_H'] += len(ids)
        self.last_diagnostic = dict(reason='PASS', optional_count=len(e['optional']),
                                    closure_rounds=len(r['steps']), bounds=bounds, target=target)
        return dict(kind='least-member-envelope-cf', version=VERSION,
                    members=tuple(ids), depth=self.H-1, attrs=attrs,
                    first_groups=groups, forced=e['cores'], uncertain=e['optional'],
                    center_boxes=e['boxes'], box_kind=e['box_kind'],
                    screening_boxes=e['screening_boxes'], core_distance_checks=e['checks'],
                    proportion_bounds=bounds, decision=target,
                    actual_final_children_known=False, closure_steps=r['steps'])

    def solve_certified(self, *args, **kwargs):
        result = super().solve_certified(*args, **kwargs)
        result['version'] = VERSION if self.policy == 'cf' else VERSION + '-exact-ablation'
        return result


class IncrementalExactEvaluator(CoarseFineEvaluator):
    """Fixed ablation: same maintained sums and distance code, no coarse screen."""
    policy = 'exact'
