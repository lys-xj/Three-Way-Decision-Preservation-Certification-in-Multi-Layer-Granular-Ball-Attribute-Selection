"""Check the final public interface against its already-tested, unchanged kernel."""
from pathlib import Path
from fractions import Fraction as F
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('final_interface', OUT/'162_主算法接口.py')
M = importlib.util.module_from_spec(s); s.loader.exec_module(M)
rows = []
for name, (data, attrs, levels) in [('small', M.K.small_case()), ('positive', M.K.chain_case()), ('negative', M.K.chain_case(True))]:
    old = M.KERNEL.IncrementalExactEvaluator(data, attrs, levels, F(7,10), F(3,10)).solve_certified()
    new = M.FinalEvaluator(data, attrs, levels, F(7,10), F(3,10)).solve_certified()
    assert new['version'] == M.VERSION and new['implementation_policy'] == 'incremental_exact'
    for k in ('final_attributes','attempts','baseline','final_decisions','metrics'):
        assert old[k] == new[k]
    assert new['metrics']['cf_coarse_checks'] == 0
    assert new['metrics']['cf_refinements'] == 0
    for node in new['state']['nodes']:
        if node.get('abstract'):
            assert node['certificate']['version'] == M.VERSION
            assert node['certificate']['box_kind'] == 'exact'
    rows.append(dict(case=name, passes=new['metrics']['certificate_passes'], final_attributes=new['final_attributes']))
assert sum(r['passes'] for r in rows) > 0
result = dict(all_passed=True, mismatches=0, version=M.VERSION, cases=rows,
    interface_sha256=hashlib.sha256((OUT/'162_主算法接口.py').read_bytes()).hexdigest(),
    kernel_sha256=hashlib.sha256((OUT/'151_粗细两级认证算法.py').read_bytes()).hexdigest(),
    test_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'163_定版接口核验结果.json').write_text(json.dumps(M.API.encode(result),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(all_passed=True, cases=len(rows), version=M.VERSION)))
