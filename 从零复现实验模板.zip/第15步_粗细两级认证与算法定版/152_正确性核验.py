"""Brute-force box checks, closure equivalence, and independent tree verification."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product, combinations
from time import perf_counter
import importlib.util
import hashlib
import json
import random
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
s = importlib.util.spec_from_file_location('cf_algorithm', OUT/'151_粗细两级认证算法.py')
M = importlib.util.module_from_spec(s); s.loader.exec_module(M)
K, API, BASE = M.K, M.API, M.BASE
ALPHA, BETA = F(7, 10), F(3, 10)


def subsets(ids):
    return (tuple(i for i, b in zip(ids, bits) if b) for bits in product((0, 1), repeat=len(ids)))


def path(r):
    return [(x['current'], x['delete'], x['accepted'], x['changed_count'], x['certified_regions'])
            for x in r['attempts']]


def main():
    start = perf_counter()
    rng = random.Random(2026092804)
    counts = dict(geometric_tables=0, optional_sets=0, valid_core_sets=0,
                  enumerated_real_means=0, coarse_pass_implications=0,
                  refinement_rescues=0, closure_comparisons=0,
                  complete_algorithm_cases=0, random_subset_checks=0)
    rescue_witness = None
    # Enumerate genuine member subsets without using either box construction helper.
    for t in range(32):
        n, d = 4+t%5, 1+t%3
        points = {i: tuple(F(rng.randrange(-7, 11), 1+(i+j+t)%3) for j in range(d)) for i in range(n)}
        groups = [tuple(range(n//2)), tuple(range(n//2, n))]
        all_valid = []
        for U in subsets(tuple(points)):
            st = M.EnvelopeState(points, groups); st.grow(U)
            e = st.inspect()
            old = BASE.inspect_envelope(points, groups, U)
            counts['optional_sets'] += 1
            assert e['valid_cores'] == old['valid_cores']
            if not e['valid_cores']:
                continue
            counts['valid_core_sets'] += 1
            assert e['violations'] == old['violations']
            if not e['violations']:
                all_valid.append(set(U))
            exact, coarse = st.exact_boxes(), st.coarse_boxes()
            assert exact == old['boxes']
            for g in (0, 1):
                means = []
                for chosen in subsets(U):
                    ids = e['cores'][g] + chosen
                    means.append(tuple(sum((points[i][j] for i in ids), F(0))/len(ids) for j in range(d)))
                    counts['enumerated_real_means'] += 1
                for j in range(d):
                    assert exact[g][j] == (min(c[j] for c in means), max(c[j] for c in means))
                    assert coarse[g][j][0] <= exact[g][j][0] <= exact[g][j][1] <= coarse[g][j][1]
                for i in e['cores'][g]:
                    upper, lower = M.necessary_distances(points[i], coarse[g], coarse[1-g])
                    eu, el = M.necessary_distances(points[i], exact[g], exact[1-g])
                    # Upper bound independently checked by all corners of the box.
                    corners = product(*exact[g])
                    brute_upper = max(sum(((x-y)**2 for x, y in zip(points[i], c)), F(0)) for c in corners)
                    projected = tuple(min(max(x, a), b) for x, (a, b) in zip(points[i], exact[1-g]))
                    brute_lower = sum(((x-y)**2 for x, y in zip(points[i], projected)), F(0))
                    assert (eu, el) == (brute_upper, brute_lower)
                    assert upper >= eu and lower <= el
                    if M.passes(g, upper, lower):
                        assert M.passes(g, eu, el)
                        counts['coarse_pass_implications'] += 1
                    elif M.passes(g, eu, el):
                        counts['refinement_rescues'] += 1
                        if rescue_witness is None:
                            rescue_witness = dict(points=points, groups=groups, optional=U, id=i,
                                group=g, coarse=(upper, lower), exact=(eu, el))
        old = BASE.least_envelope(points, groups)
        for policy in ('cf', 'exact'):
            new = M.least_envelope(points, groups, policy)
            assert (new['status'], new['steps'], new['final']['optional']) == (old['status'], old['steps'], old['final']['optional'])
            counts['closure_comparisons'] += 1
        if all_valid:
            assert old['status'] == 'least_envelope_found'
            assert all(set(old['final']['optional']) <= U for U in all_valid)
        else:
            assert old['status'] == 'no_envelope_with_two_core_members'
        counts['geometric_tables'] += 1
    assert counts['refinement_rescues'] > 0, 'Must exercise coarse failure followed by exact success'
    print('Exhaustive mean/box/tie checks passed', flush=True)

    # Equality is safe only for group 0, including degenerate coincident boxes.
    tied = {i: (F(0),) for i in range(4)}
    e = M.EnvelopeState(tied, [(0, 1), (2, 3)]).inspect()
    assert e['violations'] == (2, 3)
    assert M.least_envelope(tied, [(0, 1), (2, 3)])['status'] == 'no_envelope_with_two_core_members'
    assert K.interval_decision(ALPHA, ALPHA, ALPHA, BETA) == 'A'
    assert K.interval_decision(BETA, BETA, ALPHA, BETA) == 'R'
    assert K.interval_decision(BETA, ALPHA, ALPHA, BETA) is None
    try:
        M.EnvelopeState({i: (0.1,) for i in range(4)}, [(0, 1), (2, 3)])
    except AssertionError:
        pass
    else:
        raise AssertionError('Float inputs must not silently enter the certificate')

    # Growth invalidates checks: compare every round on a wider fractional corpus.
    for t in range(160):
        n, d = 4+t%15, 1+t%4
        points = {i: tuple(F(rng.randrange(-20, 25), rng.randrange(1, 8)) for _ in range(d)) for i in range(n)}
        groups = [tuple(range(n//2)), tuple(range(n//2, n))]
        old = BASE.least_envelope(points, groups)
        for policy in ('cf', 'exact'):
            new = M.least_envelope(points, groups, policy)
            assert new['steps'] == old['steps'] and new['status'] == old['status']
            assert new['final']['optional'] == old['final']['optional']
            counts['closure_comparisons'] += 1

    examples = [('small', K.small_case()), ('positive', K.chain_case()), ('negative', K.chain_case(True))]
    for t in range(36):
        n, d = 6+t%6, 2+t%2
        C = tuple('abc'[:d]); levels = (1, 2, 3)
        data = {i: tuple(F(rng.randrange(-4, 10), 1+t%3) for _ in C)+(rng.randrange(2),) for i in range(n)}
        data[0] = data[0][:-1]+(0,); data[1] = data[1][:-1]+(1,)
        examples.append(('random_%02d' % t, (data, C, levels)))
    details = []
    for name, (data, C, levels) in examples:
        ref = K.AUDIT.Reference(data, C, levels, ALPHA, BETA)
        baseline = ref.decisions(ref.generate(C))
        if name.startswith('random'):
            for size in range(1, len(C)+1):
                for B in combinations(C, size):
                    e = M.CoarseFineEvaluator(data, C, levels, ALPHA, BETA)
                    candidate = e.partial_construct(B, baseline)
                    assert candidate['decisions'] == ref.decisions(ref.generate(B))
                    counts['random_subset_checks'] += 1
        old = BASE.ClosureEvaluator(data, C, levels, ALPHA, BETA).solve_certified(materialize_final=True)
        new = M.CoarseFineEvaluator(data, C, levels, ALPHA, BETA).solve_certified(materialize_final=True)
        exact = M.IncrementalExactEvaluator(data, C, levels, ALPHA, BETA).solve_certified(materialize_final=True)
        assert path(old) == path(new) == path(exact)
        assert old['final_attributes'] == new['final_attributes'] == exact['final_attributes']
        assert old['final_decisions'] == new['final_decisions'] == exact['final_decisions'] == baseline
        truth = ref.generate(new['final_attributes'])
        assert API.signature(new['state'], True) == API.signature(truth, True)
        assert API.signature(exact['state'], True) == API.signature(truth, True)
        counts['complete_algorithm_cases'] += 1
        if not name.startswith('random'):
            details.append(dict(name=name, final_attributes=new['final_attributes'], metrics=new['metrics']))
    result = dict(all_passed=True, mismatches=0, version=M.VERSION, counts=counts,
                  coarse_failure_exact_success_witness=rescue_witness, examples=details,
                  elapsed_seconds=perf_counter()-start,
                  source_sha256=hashlib.sha256((OUT/'151_粗细两级认证算法.py').read_bytes()).hexdigest(),
                  test_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (OUT/'153_正确性核验结果.json').write_text(json.dumps(API.encode(result), ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(all_passed=True, counts=counts)), flush=True)


if __name__ == '__main__':
    main()
