"""Assemble results only after all predeclared datasets finished. No cherry-picking."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
KEYS = ('banknote', 'climate', 'ionosphere', 'sonar')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    correctness = json.loads((OUT/'153_正确性核验结果.json').read_text(encoding='utf-8'))
    assert correctness['all_passed'] and correctness['source_sha256'] == sha(OUT/'151_粗细两级认证算法.py')
    interface = json.loads((OUT/'163_定版接口核验结果.json').read_text(encoding='utf-8'))
    assert interface['all_passed'] and interface['interface_sha256'] == sha(OUT/'162_主算法接口.py')
    assert interface['kernel_sha256'] == sha(OUT/'151_粗细两级认证算法.py')
    rows = []
    for key in KEYS:
        r = json.loads((OUT/'真实数据结果'/(key+'_pilot.json')).read_text(encoding='utf-8'))
        assert r['all_passed'] and r['mismatches'] == 0
        assert r['source_sha256'] == sha(OUT/'151_粗细两级认证算法.py')
        assert r['driver_sha256'] == sha(OUT/'154_真实数据核验与计时.py')
        assert r['protocol_sha256'] == sha(OUT/'150_本轮实施与验证方案.md')
        rows.append(r)
    prior = json.loads((ROOT/'第13步_真实数据可用性核验'/'128_闭包独立核验结果.json').read_text(encoding='utf-8'))
    assert sha(ROOT/'第13步_真实数据可用性核验'/'126_最小成员包络.py') == prior['source_sha256']
    old12 = json.loads((ROOT/'第12步_成员变化下的决定认证'/'104_核验结果.json').read_text(encoding='utf-8'))
    assert sha(ROOT/'第12步_成员变化下的决定认证'/'102_精确判据原型.py') == old12['source_sha256']
    assert sha(ROOT/'第12步_成员变化下的决定认证'/'112_局部复用结合决定认证.py') == old12['combined_sha256']
    c = correctness['counts']
    text = ['# 本轮结果与采用结论', '',
        '本轮已把粗细两级优化真正实现，并完成三种实现的预定比较。**最终主实现选择 TailCert-L-IE-v0.4（增量精确版）**：维护核心统计量、共用排序、只算必要距离界，直接使用原精确箱判据。粗细两级版 TailCert-L-CF-v0.4 完整保留作对照。', '',
        '**选择说明：** 原方案 150 拟以粗细两级版为主；小试发现粗查本身的成本不可忽略，增量精确版更简洁且在这些计时中表现更好，因此在完整小试后调整主实现。没有改写原预设，也没有根据单个数据集切换算法。此次选择与评价使用同一批小试，后续正式性能结论须用另行固定的实验确认。', '',
        '## 1. 正确性与输出一致性', '',
        f"- 枚举 {c['optional_sets']} 个可变成员集合，其中 {c['valid_core_sets']} 个满足核心人数约束，枚举 {c['enumerated_real_means']} 个真实成员均值，验证粗箱包含精确箱。",
        f"- {c['closure_comparisons']} 次新旧闭包比较逐轮一致；{c['complete_algorithm_cases']} 个完整约简例子路径一致；另做 {c['random_subset_checks']} 次随机属性子集的独立决定核验。",
        f"- 枚举中出现 {c['refinement_rescues']} 次粗查不通过而精查通过，精查兜底按预期生效。",
        f"- 真实数据共 {sum(r['candidate_count'] for r in rows)} 个候选删属性步骤、{sum(len(r['closure_equivalence_records']) for r in rows)} 次实际闭包调用，新旧逐轮 U、违规名单及结束状态一致。",
        '- 三个实现的认证结果、删除路径、当前/最终属性、全部样本各观察层决定、最终物化树轨迹一致，检测到的不一致为 0。',
        '- Banknote、Climate、Ionosphere 为完整路径。Sonar 严格只核验前 20 个候选；不能把它说成已完成的 Sonar 全程实验。',
        '- 独立参照来自冻结的另外一套真实树重构程序：无抽象节点时核对既存独立树轨迹哈希；有抽象节点时重新生成独立决定；末态物化后再核对真实树。', '',
        '## 2. 实际计时：三次重复的中位数', '',
        '单机串行运行，每方法每数据集预热一次，随后按循环轮换顺序各运行三次。下表为完整决定保持约简（Sonar 为固定前缀）的算法时间，计入失败认证开销，排除独立核验、导入与文件写入。最终物化与几何输出另列。未锁定整个操作系统，因此不将小幅差异解释为显著优势。', '',
        '| 数据 | 范围 | 原 v0.3 /秒 | 增量精确（最终主实现）/秒 | 粗细两级 /秒 | 主实现相对原版耗时变化 | 粗细版相对原版耗时变化 |',
        '|---|---|---:|---:|---:|---:|---:|']
    changes = []; exact_changes = []
    for r in rows:
        s = r['summary']
        old, exact, cf = [s[k]['decision_only_seconds']['median'] for k in ('v03', 'incremental_exact', 'coarse_fine')]
        change = (cf/old-1)*100; changes.append(change)
        exact_changes.append((exact/old-1)*100)
        text.append(f"| {r['dataset']} | {'前20个候选' if r['capped_candidates'] else '完整约简'} | {old:.4f} | {exact:.4f} | {cf:.4f} | {(exact/old-1)*100:+.2f}% | {change:+.2f}% |")
    text += ['', '负号表示耗时减少，正号表示耗时增加。小试只有三次重复，不能凭此做显著性或跨机器结论。', '',
        '| 数据 | 原版含最终物化及几何输出 /秒 | 增量精确对照 /秒 | 粗细两级 /秒 |',
        '|---|---:|---:|---:|']
    for r in rows:
        v = [r['summary'][k]['total_with_geometry_seconds']['median'] for k in ('v03','incremental_exact','coarse_fine')]
        text.append(f"| {r['dataset']} | {v[0]:.4f} | {v[1]:.4f} | {v[2]:.4f} |")
    text += ['', '各次原始时间、最小/最大值、预热记录、各项成本均保存在 `真实数据结果/*_pilot.json`，没有只保留最快一次。', '',
        '## 3. 收益来自哪里', '',
        '| 数据 | 总认证尝试 | 认证通过 | U 非空时粗查数 | 其中粗查直接通过 | 进入精查 | 精查救回 |',
        '|---|---:|---:|---:|---:|---:|---:|']
    exact_wins = []
    for r in rows:
        m = r['summary']['coarse_fine']['metrics']
        nonempty = m['cf_coarse_checks']-m['cf_singleton_box_checks']
        direct = nonempty-m['cf_refinements']
        text.append(f"| {r['dataset']} | {m['certificate_attempts']} | {m['certificate_passes']} | {nonempty} | {direct} | {m['cf_refinements']} | {m['cf_refinement_rescues']} |")
        if r['summary']['incremental_exact']['decision_only_seconds']['median'] < r['summary']['coarse_fine']['decision_only_seconds']['median']:
            exact_wins.append(r['dataset'])
    text += ['', '空名单时粗箱和精确箱完全相同，表中把这部分检查排除，避免夸大新增粗查的贡献。',
        'Banknote 因节点基准决定不一致，未进入几何闭包；其小幅时间变化主要是运行波动，不能归功于新粗筛。',
        'Climate 的通过节点仍来自原来全体基准末层为 R 的情形，证明了实现可用，但不代表已经覆盖丰富的三支决定分布。', '',
        '## 4. 本轮采用决定与论文表述边界', '',
        '1. **实现采用**：主实现统一采用增量精确版 TailCert-L-IE-v0.4；原版和已实现的粗细两级版保留。此选择在预定小试后作出，不针对不同数据临时切换策略。',
        '2. **数学结论采用**：外包箱包含性、粗通过的安全性、新旧闭包逐轮等价，以及相同删属性结果的证明，可以作为实现依据。',
        '3. **速度结论谨慎采用**：完整耗时存在收益有限或变慢的情况，因此本轮不支持“在各类数据上稳定加速”的结论。']
    if exact_wins:
        text.append('4. **不能把全部收益归给粗查**：在 '+ '、'.join(exact_wins) +' 上，增量精确版的中位耗时低于粗细两级版。这是本轮选择更简单精确实现的依据；Banknote 未进入几何闭包，其小幅差异只按波动处理。不能用这一小试宣称统计显著或普遍优于。')
    text += ['5. **主贡献仍集中于一个问题**：允许成员变化的最小包络与决定保持证书；粗查、增量统计和共用排序是其实现优化，单独不足以宣称新的理论突破。',
        '6. 本轮没有完成最近相关论文的全文差异确认、完整 Sonar 正式实验、跨参数/跨数据正式统计及投稿会议适配。它们不能因实现定版而省略。', '',
        '## 5. 文件与复现', '',
        '- 151：增量精确内核与粗细两级内核（计时前固定，未在计时后改写）。',
        '- 152、153：正确性程序与结果。',
        '- 154、真实数据结果：真实数据对照和逐次计时。',
        '- 155：数学定义、完整流程与关键证明。',
        '- 156：不用先看代码也能理解的说明。',
        '- 158、159：运行前逐个校验文件哈希的入口与版本清单。',
        '- 162、163、164：最终主接口、接口核验结果与程序。主接口只为已测的增量精确内核设置正式版本和证明标签；不更改其数学计算。',
        '- 第 9、12、13 步的被依赖源文件未修改，并核对先前锁定的哈希。', '',
        '校验命令：`python 158_冻结版本运行入口.py`。新运行示例：`python 158_冻结版本运行入口.py --dataset banknote --materialize-final --output 新运行_banknote.json`。必须使用正常 Python 模式，不能加 `-O`；输出必须选新文件名。', '']
    (OUT/'157_本轮结果与采用结论.md').write_text('\n'.join(text), encoding='utf-8')

    paths = list(OUT.glob('*.py')) + list(OUT.glob('*.md')) + [OUT/'153_正确性核验结果.json', OUT/'163_定版接口核验结果.json']
    paths += list((OUT/'真实数据结果').glob('*.json'))
    for directory, names in [
        ('第9步_论文算法定版与关键证明', ['73_冻结版本清单.json','78_运行冻结版本.py']),
        ('第12步_成员变化下的决定认证', ['102_精确判据原型.py','112_局部复用结合决定认证.py','104_核验结果.json']),
        ('第13步_真实数据可用性核验', ['126_最小成员包络.py','128_闭包独立核验结果.json'])]:
        paths += [ROOT/directory/n for n in names]
    oldlock = json.loads((ROOT/'第9步_论文算法定版与关键证明'/'73_冻结版本清单.json').read_text(encoding='utf-8'))
    snap = ROOT/'第9步_论文算法定版与关键证明'/oldlock['snapshot_root']
    for name, value in oldlock['snapshots'].items():
        file = snap/name
        assert sha(file) == value['sha256']
        paths.append(file)
    paths += [ROOT/'第11步_正式实验'/'独立核验'/(key+'_audit.json') for key in KEYS]
    entries = {p.relative_to(ROOT).as_posix():dict(sha256=sha(p), bytes=p.stat().st_size) for p in sorted(set(paths))}
    lock = dict(version='TailCert-L-IE-v0.4', frozen_utc=datetime.now(timezone.utc).isoformat(),
                primary_method='FinalEvaluator.solve_certified', primary_interface='162_主算法接口.py',
                baseline='TailCert-L-closure-v0.3-exploratory',
                implemented_comparison='TailCert-L-CF-v0.4 / CoarseFineEvaluator', relative_root='parent research directory',
                preserved_outputs='closure steps, certificate outcome, deletion path, observed decisions; optional exact tree',
                limitations='Research implementation freeze; no universal speedup or completed novelty claim.', files=entries)
    (OUT/'159_冻结版本清单.json').write_text(json.dumps(lock, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(all_passed=True, locked_files=len(entries), real_candidates=sum(r['candidate_count'] for r in rows),
                         closure_calls=sum(len(r['closure_equivalence_records']) for r in rows), cf_changes_percent=changes,
                         exact_vs_original_changes_percent=exact_changes, exact_ablation_faster=exact_wins), ensure_ascii=False))


if __name__ == '__main__':
    main()
